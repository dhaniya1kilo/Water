package com.textcover.app

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.Closeable
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Finds where the target word is inside one frame using on-device OCR (ML Kit).
 * Returns bounding boxes in the bitmap's own pixel coordinates.
 */
class WatermarkFinder(
    target: String,
    private val fuzzy: Boolean,
    devanagari: Boolean
) : Closeable {

    private val recognizer: TextRecognizer =
        if (devanagari) TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        else TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val tokens: List<String> =
        target.trim().split(Regex("\\s+")).map { normalize(it) }.filter { it.isNotEmpty() }
    private val joined: String = tokens.joinToString("")

    /** All text OCR saw in the last frame (shown to the user when nothing matches). */
    var lastSeenText: String = ""
        private set

    fun find(bitmap: Bitmap): List<Rect> {
        if (tokens.isEmpty()) return emptyList()

        val longSide = max(bitmap.width, bitmap.height)
        val scale = if (longSide > MAX_OCR_SIDE) MAX_OCR_SIDE.toFloat() / longSide else 1f
        val input = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).roundToInt().coerceAtLeast(1),
                (bitmap.height * scale).roundToInt().coerceAtLeast(1),
                true
            )
        } else bitmap

        val found = try {
            findIn(InputImage.fromBitmap(input, 0))
        } finally {
            if (input !== bitmap) input.recycle()
        }

        if (scale < 1f) {
            val inv = 1f / scale
            for (r in found) {
                r.set(
                    (r.left * inv).roundToInt(), (r.top * inv).roundToInt(),
                    (r.right * inv).roundToInt(), (r.bottom * inv).roundToInt()
                )
            }
        }
        return found
    }

    /** Runs OCR on any ML Kit image (bitmap or raw camera/decoder bytes) and matches the word. */
    fun findIn(image: InputImage): List<Rect> {
        if (tokens.isEmpty()) return emptyList()
        return match(Tasks.await(recognizer.process(image)))
    }

    /** Starts OCR without waiting, so decoding can continue while text is being read. */
    fun submit(image: InputImage): com.google.android.gms.tasks.Task<com.google.mlkit.vision.text.Text> =
        recognizer.process(image)

    /** Finds the target word in an OCR result. */
    fun match(result: com.google.mlkit.vision.text.Text): List<Rect> {
        if (tokens.isEmpty()) return emptyList()
        lastSeenText = result.text

        val found = ArrayList<Rect>()
        val n = tokens.size
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val elements = line.elements.filter { it.boundingBox != null }
                if (elements.isEmpty()) continue
                val words = elements.map { normalize(it.text) }
                val used = BooleanArray(elements.size)

                // Multi-word target: look for consecutive words in the line.
                if (n > 1) {
                    var i = 0
                    while (i + n <= elements.size) {
                        val hit = (0 until n).all { k -> tokenMatches(words[i + k], tokens[k]) }
                        if (hit) {
                            val r = Rect(elements[i].boundingBox!!)
                            for (k in 1 until n) r.union(elements[i + k].boundingBox!!)
                            found.add(r)
                            for (k in 0 until n) used[i + k] = true
                            i += n
                        } else i++
                    }
                }
                // Single word (or OCR glued the words together).
                for (e in elements.indices) {
                    if (!used[e] && tokenMatches(words[e], joined)) {
                        found.add(Rect(elements[e].boundingBox!!))
                    }
                }
            }
        }

        return found
    }

    private fun tokenMatches(word: String, t: String): Boolean {
        if (word.isEmpty() || t.isEmpty()) return false
        if (word == t) return true
        if (t.length >= 3 && word.contains(t)) return true
        if (!fuzzy || t.length < 4) return false

        val maxDist = if (t.length <= 6) 1 else 2
        if (abs(word.length - t.length) <= maxDist && levenshtein(word, t) <= maxDist) return true
        if (word.length > t.length) {
            for (s in 0..word.length - t.length) {
                if (levenshtein(word.substring(s, s + t.length), t) <= maxDist) return true
            }
        }
        return false
    }

    override fun close() {
        recognizer.close()
    }

    companion object {
        private const val MAX_OCR_SIDE = 2048

        fun normalize(s: String): String = buildString {
            for (c in s.lowercase()) {
                val type = Character.getType(c)
                if (c.isLetterOrDigit() ||
                    type == Character.NON_SPACING_MARK.toInt() ||
                    type == Character.COMBINING_SPACING_MARK.toInt()
                ) append(c)
            }
        }

        fun levenshtein(a: String, b: String): Int {
            var prev = IntArray(b.length + 1) { it }
            var cur = IntArray(b.length + 1)
            for (i in 1..a.length) {
                cur[0] = i
                for (j in 1..b.length) {
                    val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                    cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost)
                }
                val tmp = prev; prev = cur; cur = tmp
            }
            return prev[b.length]
        }
    }
}

/**
 * Keeps the last known position for a few frames when OCR briefly misses the watermark,
 * and steadies small frame-to-frame jitter so the box doesn't wobble.
 */
class BoxTracker(private val holdFrames: Int) {
    private var last: List<Rect> = emptyList()
    private var missed = 0

    /** [found] == null means "this frame was not scanned" -> reuse last boxes. */
    fun update(found: List<Rect>?): List<Rect> {
        if (found == null) return last
        if (found.isNotEmpty()) {
            last = found.map { stabilize(it) }
            missed = 0
        } else {
            missed++
            if (missed > holdFrames) last = emptyList()
        }
        return last
    }

    private fun stabilize(cur: Rect): Rect {
        val prev = last.minByOrNull { dist(it, cur) } ?: return cur
        val h = max(prev.height(), 1).toFloat()
        val d = dist(prev, cur)
        return when {
            d < 0.2f * h -> Rect(prev)                  // tiny jitter: keep it still
            d < 1.0f * h -> {                           // small move: follow smoothly
                val dx = ((cur.exactCenterX() - prev.exactCenterX()) * 0.5f).roundToInt()
                val dy = ((cur.exactCenterY() - prev.exactCenterY()) * 0.5f).roundToInt()
                Rect(prev).apply { offset(dx, dy) }
            }
            else -> cur                                 // watermark jumped: snap to it
        }
    }

    private fun dist(a: Rect, b: Rect): Float {
        val dx = a.exactCenterX() - b.exactCenterX()
        val dy = a.exactCenterY() - b.exactCenterY()
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }
}
