package com.textcover.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.util.Log
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Gets the audio ready for the MP4: AAC is copied untouched; anything else
 * (Opus, Vorbis, AC3, FLAC, ... common in MKV) is converted to AAC stereo.
 */
object AudioPrep {

    /** Where to copy the audio from: the original file ([uri]) or a converted file ([path]). */
    class Source(val uri: Uri?, val path: String?, val track: Int, val note: String?)

    @Volatile
    var lastNote: String? = null

    private val COPYABLE = setOf(
        MediaFormat.MIMETYPE_AUDIO_AAC, MediaFormat.MIMETYPE_AUDIO_AMR_NB, MediaFormat.MIMETYPE_AUDIO_AMR_WB
    )

    fun prepare(ctx: Context, uri: Uri, workDir: File, isCancelled: () -> Boolean): Source? {
        lastNote = null
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            var mime = ""
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("audio/")) { track = i; mime = m; break }
            }
            if (track < 0) return null
            if (mime in COPYABLE) return Source(uri, null, track, null)
            val out = File(workDir, "audio.m4a")
            return try {
                convertToAac(ex, track, out, isCancelled)
                Source(null, out.absolutePath, 0, "(Audio was converted to AAC for MP4.)")
            } catch (e: ProcessingCancelled) {
                throw e
            } catch (e: Throwable) {
                Log.w("WatermarkCover", "audio conversion failed", e)
                lastNote = "(The audio couldn't be converted, so the video has no sound.)"
                null
            }
        } finally {
            runCatching { ex.release() }
        }
    }

    private fun convertToAac(ex: MediaExtractor, track: Int, out: File, isCancelled: () -> Boolean) {
        val inFmt = ex.getTrackFormat(track)
        ex.selectTrack(track)
        val dec = MediaCodec.createDecoderByType(inFmt.getString(MediaFormat.KEY_MIME)!!)
        var enc: MediaCodec? = null
        val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var muxStarted = false
        var muxTrack = -1
        try {
            dec.configure(inFmt, null, null, 0)
            dec.start()

            var sampleRate = inFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var inChannels = inFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var isFloat = false
            var outChannels = 2
            var framesWritten = 0L          // PCM frames sent to the encoder
            var firstPts = -1L
            val pending = java.io.ByteArrayOutputStream()   // converted 16-bit PCM waiting for the encoder

            val decInfo = MediaCodec.BufferInfo()
            val encInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var decDone = false
            var encInputDone = false

            fun startEncoder() {
                outChannels = if (inChannels >= 2) 2 else 1
                val f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, outChannels).apply {
                    setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    setInteger(MediaFormat.KEY_BIT_RATE, if (outChannels == 2) 192_000 else 128_000)
                    setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 shl 16)
                }
                val e = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
                e.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                e.start()
                enc = e
            }

            fun drainEnc(final: Boolean) {
                val e = enc ?: return
                var waits = 0
                while (true) {
                    val idx = e.dequeueOutputBuffer(encInfo, if (final) 10_000L else 0L)
                    if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!final) return
                        if (++waits > 500) return
                    } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        muxTrack = mux.addTrack(e.outputFormat)
                        mux.start()
                        muxStarted = true
                    } else if (idx >= 0) {
                        val b = e.getOutputBuffer(idx)
                        if ((encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) encInfo.size = 0
                        if (encInfo.size > 0 && b != null && muxStarted) {
                            b.position(encInfo.offset)
                            b.limit(encInfo.offset + encInfo.size)
                            mux.writeSampleData(muxTrack, b, encInfo)
                        }
                        e.releaseOutputBuffer(idx, false)
                        if ((encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }

            /** Sends buffered PCM to the encoder (whole input buffers only, unless [flush]). */
            fun feedEnc(flush: Boolean) {
                val e = enc ?: return
                val bytesPerFrame = 2 * outChannels
                while (true) {
                    val avail = pending.size()
                    if (avail == 0 && !flush) return
                    if (avail < 4096 * bytesPerFrame && !flush) return
                    val idx = e.dequeueInputBuffer(5_000L)
                    if (idx < 0) { drainEnc(false); continue }
                    val ib = e.getInputBuffer(idx)!!
                    ib.clear()
                    val all = pending.toByteArray()
                    var n = min(all.size, ib.capacity())
                    n -= n % bytesPerFrame
                    val pts = (if (firstPts < 0) 0L else firstPts) + framesWritten * 1_000_000L / sampleRate
                    if (n == 0 && flush) {
                        e.queueInputBuffer(idx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        encInputDone = true
                        pending.reset()
                        return
                    }
                    ib.put(all, 0, n)
                    e.queueInputBuffer(idx, 0, n, pts, 0)
                    framesWritten += n / bytesPerFrame
                    pending.reset()
                    if (n < all.size) pending.write(all, n, all.size - n)
                    drainEnc(false)
                }
            }

            while (!decDone) {
                if (isCancelled()) throw ProcessingCancelled()
                if (!inputDone) {
                    val idx = dec.dequeueInputBuffer(5_000L)
                    if (idx >= 0) {
                        val b = dec.getInputBuffer(idx)!!
                        val size = ex.readSampleData(b, 0)
                        if (size < 0) {
                            dec.queueInputBuffer(idx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(idx, 0, size, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val idx = dec.dequeueOutputBuffer(decInfo, 5_000L)
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = dec.outputFormat
                    sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    inChannels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    isFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        of.getInteger(MediaFormat.KEY_PCM_ENCODING) == android.media.AudioFormat.ENCODING_PCM_FLOAT
                    continue
                }
                if (idx < 0) continue
                if (decInfo.size > 0) {
                    if (enc == null) startEncoder()
                    if (firstPts < 0) firstPts = decInfo.presentationTimeUs
                    val b = dec.getOutputBuffer(idx)!!
                    b.position(decInfo.offset)
                    b.limit(decInfo.offset + decInfo.size)
                    pending.write(toStereo16(b.slice().order(ByteOrder.nativeOrder()), inChannels, outChannels, isFloat))
                    feedEnc(false)
                }
                dec.releaseOutputBuffer(idx, false)
                if ((decInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) decDone = true
            }
            if (enc == null) throw IllegalStateException("No audio decoded")
            while (!encInputDone) feedEnc(true)
            drainEnc(true)
            if (!muxStarted) throw IllegalStateException("No audio encoded")
            mux.stop()
            muxStarted = false
        } finally {
            runCatching { dec.stop() }; runCatching { dec.release() }
            enc?.let { runCatching { it.stop() }; runCatching { it.release() } }
            if (muxStarted) runCatching { mux.stop() }
            runCatching { mux.release() }
        }
    }

    /** Converts decoded PCM (16-bit or float, any channel count) to 16-bit mono/stereo. */
    private fun toStereo16(src: ByteBuffer, inCh: Int, outCh: Int, isFloat: Boolean): ByteArray {
        val bytesPerSample = if (isFloat) 4 else 2
        val frames = src.remaining() / (bytesPerSample * inCh)
        val out = ByteBuffer.allocate(frames * outCh * 2).order(ByteOrder.LITTLE_ENDIAN)
        val s = FloatArray(inCh)
        for (f in 0 until frames) {
            for (c in 0 until inCh) {
                s[c] = if (isFloat) src.float else src.short / 32768f
            }
            if (outCh == 1) {
                out.putShort(clamp(s[0]))
            } else if (inCh == 1) {
                val v = clamp(s[0]); out.putShort(v); out.putShort(v)
            } else if (inCh == 2) {
                out.putShort(clamp(s[0])); out.putShort(clamp(s[1]))
            } else if (inCh >= 6) {
                // 5.1: FL FR FC LFE BL BR
                val l = s[0] + 0.707f * s[2] + 0.707f * s[4]
                val r = s[1] + 0.707f * s[2] + 0.707f * s[5]
                out.putShort(clamp(l / 2.414f)); out.putShort(clamp(r / 2.414f))
            } else {
                var l = 0f; var r = 0f; var nl = 0; var nr = 0
                for (c in 0 until inCh) if (c % 2 == 0) { l += s[c]; nl++ } else { r += s[c]; nr++ }
                out.putShort(clamp(l / maxOf(1, nl))); out.putShort(clamp(r / maxOf(1, nr)))
            }
        }
        return out.array()
    }

    private fun clamp(v: Float): Short = (v.coerceIn(-1f, 1f) * 32767f).toInt().toShort()

    private fun min(a: Int, b: Int) = if (a < b) a else b
}
