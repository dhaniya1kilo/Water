package com.textcover.app

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.max
import kotlin.math.min

/** Draws a rounded box with the user's text over each detected watermark. */
class OverlayPainter(private val style: OverlayStyle) {

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = style.bgColor
        this.style = Paint.Style.FILL
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = style.textColor
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    fun draw(canvas: Canvas, boxes: List<Rect>, frameW: Int, frameH: Int) {
        for (b in boxes) drawOne(canvas, b, frameW, frameH)
    }

    private fun drawOne(canvas: Canvas, box: Rect, frameW: Int, frameH: Int) {
        val wordH = max(box.height(), 6).toFloat()
        val pad = wordH * style.paddingPercent / 100f
        val text = style.replacementText

        var textW = 0f
        if (text.isNotEmpty()) {
            textPaint.textSize = wordH * style.textScalePercent / 100f
            textW = textPaint.measureText(text)
            val maxTextW = frameW * 0.95f - 2 * pad
            if (textW > maxTextW && maxTextW > 0) {
                textPaint.textSize *= maxTextW / textW
                textW = textPaint.measureText(text)
            }
        }

        // The box always covers the whole watermark, and grows if the user's text is longer.
        val rectW = max(box.width() + 2 * pad, textW + 2 * pad + wordH * 0.3f)
        val rectH = max(wordH + 2 * pad, textPaint.textSize * 1.2f)
        var left = box.exactCenterX() - rectW / 2f
        var top = box.exactCenterY() - rectH / 2f
        if (rectW <= frameW) left = left.coerceIn(0f, frameW - rectW)
        if (rectH <= frameH) top = top.coerceIn(0f, frameH - rectH)
        rect.set(left, top, left + rectW, top + rectH)

        val radius = (style.cornerPercent / 100f) * min(rectW, rectH) / 2f
        canvas.drawRoundRect(rect, radius, radius, bgPaint)

        if (text.isNotEmpty()) {
            val fm = textPaint.fontMetrics
            val baseline = rect.centerY() - (fm.ascent + fm.descent) / 2f
            canvas.drawText(text, rect.centerX(), baseline, textPaint)
        }
    }
}
