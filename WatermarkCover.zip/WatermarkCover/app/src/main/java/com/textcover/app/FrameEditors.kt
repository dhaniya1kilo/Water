package com.textcover.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import java.util.Random
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Feature 1: finds the word in every frame and covers it. */
class CoverEditor(style: OverlayStyle) : FrameEditor {
    private val finder = WatermarkFinder(style.targetText, style.fuzzy, style.devanagari)
    private val tracker = BoxTracker(if (style.holdWhenMissing) 12 else 0)
    private val painter = OverlayPainter(style)
    private val scanEvery = max(1, style.scanEvery)
    private val heights = ArrayList<Int>()
    private val widths = ArrayList<Int>()

    override val wantsSamples: Boolean get() = true

    override fun onSample(frame: Bitmap) {
        for (b in finder.find(frame)) {
            heights.add(b.height())
            widths.add(b.width())
        }
    }

    /** Median size across the video -> one fixed text/box size. */
    override fun onSamplesDone() {
        if (heights.isEmpty()) return
        heights.sort()
        widths.sort()
        painter.fixedWordH = max(heights[heights.size / 2], 6).toFloat()
        painter.fixedWordW = max(widths[widths.size / 2], 6).toFloat()
    }

    override fun edit(canvas: Canvas, frame: Bitmap, index: Int, ptsUs: Long, w: Int, h: Int): Boolean {
        val found = if (index % scanEvery == 0) finder.find(frame) else null
        val boxes = tracker.update(found)
        painter.draw(canvas, boxes, w, h)
        return boxes.isNotEmpty()
    }

    override fun close() {
        finder.close()
    }
}

// ---------------------------------------------------------------------------------------------

enum class WatermarkEffect { PLAIN, SHADOW, BACKGROUND }
enum class WatermarkMotion { GLIDE, JUMP }

data class WatermarkStyle(
    val text: String,
    val textColor: Int,
    val effect: WatermarkEffect,
    val effectColor: Int,     // shadow color or background color
    val sizePercent: Float,   // text height as % of the video's shorter side
    val opacityPercent: Float,
    val cornerPercent: Float, // background roundness
    val motion: WatermarkMotion,
    val speed: Float,         // 1..10 (glide)
    val jumpSeconds: Float    // jump mode: seconds between jumps
)

/** Feature 2: draws a text watermark that wanders randomly around the video. */
class MovingWatermarkEditor(
    private val s: WatermarkStyle,
    seed: Long = System.nanoTime()
) : FrameEditor {

    private val rnd = Random(seed)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        color = s.textColor
        textAlign = Paint.Align.LEFT
    }
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = s.effectColor
        style = Paint.Style.FILL
    }
    private val rect = RectF()

    private var ready = false
    private var boxW = 0f
    private var boxH = 0f
    private var padX = 0f
    private var padY = 0f
    private var shadowMargin = 0f
    private var marginX = 0f
    private var marginY = 0f
    private var alpha = 255

    // motion state (all positions are the box's top-left corner)
    private var fromX = 0f
    private var fromY = 0f
    private var toX = 0f
    private var toY = 0f
    private var segStartUs = 0L
    private var segDurUs = 1L
    private var lastJumpSlot = Long.MIN_VALUE
    private var curX = 0f
    private var curY = 0f
    private var started = false

    private fun setup(w: Int, h: Int) {
        val shortSide = min(w, h).toFloat()
        textPaint.textSize = max(8f, shortSide * s.sizePercent / 100f)
        measure()
        // never wider than the video
        if (boxW > w * 0.95f) {
            textPaint.textSize *= (w * 0.95f) / boxW
            measure()
        }
        if (s.effect == WatermarkEffect.SHADOW) {
            val ts = textPaint.textSize
            textPaint.setShadowLayer(max(2f, ts * 0.12f), ts * 0.06f, ts * 0.06f, s.effectColor)
        }
        alpha = (s.opacityPercent / 100f * 255f).toInt().coerceIn(10, 255)
        marginX = w * 0.02f
        marginY = h * 0.02f
        ready = true
    }

    private fun measure() {
        val ts = textPaint.textSize
        val fm = textPaint.fontMetrics
        val textW = textPaint.measureText(s.text)
        val textH = fm.descent - fm.ascent
        padX = if (s.effect == WatermarkEffect.BACKGROUND) ts * 0.45f else ts * 0.1f
        padY = if (s.effect == WatermarkEffect.BACKGROUND) ts * 0.25f else ts * 0.05f
        shadowMargin = if (s.effect == WatermarkEffect.SHADOW) ts * 0.25f else 0f
        boxW = textW + 2 * padX
        boxH = textH + 2 * padY
    }

    private fun randomX(w: Int): Float {
        val maxX = w - boxW - marginX
        return if (maxX <= marginX) max(0f, (w - boxW) / 2f) else marginX + rnd.nextFloat() * (maxX - marginX)
    }

    private fun randomY(h: Int): Float {
        val maxY = h - boxH - marginY
        return if (maxY <= marginY) max(0f, (h - boxH) / 2f) else marginY + rnd.nextFloat() * (maxY - marginY)
    }

    private fun updatePosition(ptsUs: Long, w: Int, h: Int) {
        if (!started) {
            curX = randomX(w); curY = randomY(h)
            fromX = curX; fromY = curY
            toX = randomX(w); toY = randomY(h)
            segStartUs = ptsUs
            segDurUs = segmentDuration(w, h)
            started = true
        }
        when (s.motion) {
            WatermarkMotion.JUMP -> {
                val periodUs = (s.jumpSeconds * 1_000_000f).toLong().coerceAtLeast(200_000L)
                val slot = (ptsUs - segStartUs) / periodUs
                if (slot != lastJumpSlot) {
                    if (lastJumpSlot != Long.MIN_VALUE) {
                        curX = randomX(w); curY = randomY(h)
                    }
                    lastJumpSlot = slot
                }
            }
            WatermarkMotion.GLIDE -> {
                var guard = 0
                while (ptsUs >= segStartUs + segDurUs && guard++ < 10_000) {
                    segStartUs += segDurUs
                    fromX = toX; fromY = toY
                    toX = randomX(w); toY = randomY(h)
                    segDurUs = segmentDuration(w, h)
                }
                val t = ((ptsUs - segStartUs).toFloat() / segDurUs).coerceIn(0f, 1f)
                val e = t * t * (3 - 2 * t) // smooth start and stop
                curX = fromX + (toX - fromX) * e
                curY = fromY + (toY - fromY) * e
            }
        }
    }

    /** Time to travel to the next random point at the chosen speed. */
    private fun segmentDuration(w: Int, h: Int): Long {
        val dx = toX - fromX
        val dy = toY - fromY
        val dist = sqrt(dx * dx + dy * dy)
        val diag = sqrt(w.toFloat() * w + h.toFloat() * h)
        val pxPerSec = diag * 0.03f * s.speed.coerceIn(1f, 10f)
        return ((dist / pxPerSec) * 1_000_000f).toLong().coerceAtLeast(500_000L)
    }

    override fun edit(canvas: Canvas, frame: Bitmap, index: Int, ptsUs: Long, w: Int, h: Int): Boolean {
        if (s.text.isBlank()) return false
        if (!ready) setup(w, h)
        updatePosition(ptsUs, w, h)

        val x = curX
        val y = curY
        val layer = canvas.saveLayerAlpha(
            x - shadowMargin, y - shadowMargin,
            x + boxW + shadowMargin * 2, y + boxH + shadowMargin * 2, alpha
        )
        if (s.effect == WatermarkEffect.BACKGROUND) {
            rect.set(x, y, x + boxW, y + boxH)
            val r = s.cornerPercent / 100f * min(boxW, boxH) / 2f
            canvas.drawRoundRect(rect, r, r, bgPaint)
        }
        val baseline = y + padY - textPaint.fontMetrics.ascent
        canvas.drawText(s.text, x + padX, baseline, textPaint)
        canvas.restoreToCount(layer)
        return true
    }
}
