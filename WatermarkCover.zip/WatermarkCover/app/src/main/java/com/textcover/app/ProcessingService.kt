package com.textcover.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/** Foreground service: keeps processing while the app is closed or the screen is off. */
class ProcessingService : Service(), JobManager.Listener {

    private var wakeLock: PowerManager.WakeLock? = null
    private var lastUpdate = 0L
    private var running = false
    private var kind = JobManager.Kind.COVER

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannels()
        if (intent?.action == ACTION_CANCEL) {
            JobManager.cancel()
            if (!running) stopSelf()
            return START_NOT_STICKY
        }
        if (running) return START_NOT_STICKY

        val job = JobManager.takePending()
        ServiceCompat.startForeground(
            this, NOTIF_PROGRESS,
            progressNotification("Starting…", 0, 0),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        )
        if (job == null) {
            stopEverything()
            return START_NOT_STICKY
        }
        kind = job.kind
        running = true
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WatermarkCover:job")
            .apply { acquire(6 * 60 * 60 * 1000L) }
        JobManager.addListener(this)
        Thread({ JobManager.execute(applicationContext, job) }, "video-job").start()
        return START_NOT_STICKY
    }

    override fun onState(state: JobManager.State) {
        if (!running) return
        when (state) {
            is JobManager.State.Running -> {
                val now = System.currentTimeMillis()
                if (now - lastUpdate < 1000) return
                lastUpdate = now
                nm().notify(NOTIF_PROGRESS, progressNotification(state.message, state.done, state.total))
            }
            is JobManager.State.Done -> {
                val view = Intent(Intent.ACTION_VIEW).setDataAndType(state.uri, state.mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                val pi = PendingIntent.getActivity(
                    this, 1, view, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                finish(resultNotification("Video ready – tap to open", state.summary, pi))
            }
            is JobManager.State.Failed -> {
                finish(resultNotification(title(), state.message, openAppIntent()))
            }
            JobManager.State.Idle -> Unit
        }
    }

    private fun finish(n: Notification) {
        running = false
        JobManager.removeListener(this)
        nm().notify(NOTIF_RESULT, n)
        stopEverything()
    }

    private fun stopEverything() {
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        wakeLock = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        JobManager.removeListener(this)
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- notifications

    private fun title() = if (kind == JobManager.Kind.COVER) "Covering watermark" else "Adding watermark"

    private fun openAppIntent(): PendingIntent {
        val cls = if (kind == JobManager.Kind.COVER) MainActivity::class.java else WatermarkActivity::class.java
        val i = Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun progressNotification(text: String, done: Int, total: Int): Notification {
        val cancel = PendingIntent.getService(
            this, 2, Intent(this, ProcessingService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(this, CHANNEL_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title())
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(openAppIntent())
            .addAction(0, "Cancel", cancel)
        if (total > 0) b.setProgress(1000, (done * 1000L / total).toInt(), false)
        else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun resultNotification(title: String, text: String, pi: PendingIntent): Notification =
        NotificationCompat.Builder(this, CHANNEL_RESULT)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text.lineSequence().firstOrNull() ?: text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

    private fun nm() = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

    private fun createChannels() {
        val m = nm()
        m.createNotificationChannel(
            NotificationChannel(CHANNEL_PROGRESS, "Processing progress", NotificationManager.IMPORTANCE_LOW)
        )
        m.createNotificationChannel(
            NotificationChannel(CHANNEL_RESULT, "Finished videos", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    companion object {
        const val ACTION_CANCEL = "com.textcover.app.CANCEL"
        private const val CHANNEL_PROGRESS = "progress"
        private const val CHANNEL_RESULT = "result"
        private const val NOTIF_PROGRESS = 1
        private const val NOTIF_RESULT = 2
    }
}
