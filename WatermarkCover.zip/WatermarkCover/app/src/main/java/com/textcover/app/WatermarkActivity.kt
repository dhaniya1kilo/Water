package com.textcover.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

/** Page 2: add a moving text watermark to a video. */
class WatermarkActivity : AppCompatActivity(), JobManager.Listener {

    private lateinit var pickButton: Button
    private lateinit var fileLabel: TextView
    private lateinit var preview: ImageView
    private lateinit var textInput: TextInputEditText
    private lateinit var textColorInput: TextInputEditText
    private lateinit var effectColorInput: TextInputEditText
    private lateinit var effectGroup: RadioGroup
    private lateinit var effectColorLabel: TextView
    private lateinit var effectColorLayout: View
    private lateinit var effectSwatchScroll: View
    private lateinit var motionGroup: RadioGroup
    private lateinit var sample: TextView
    private lateinit var sizeSlider: Slider
    private lateinit var opacitySlider: Slider
    private lateinit var cornerSlider: Slider
    private lateinit var speedSlider: Slider
    private lateinit var jumpSlider: Slider
    private lateinit var sizeLabel: TextView
    private lateinit var opacityLabel: TextView
    private lateinit var cornerLabel: TextView
    private lateinit var speedLabel: TextView
    private lateinit var jumpLabel: TextView
    private lateinit var qualitySwitch: MaterialSwitch
    private lateinit var previewButton: Button
    private lateinit var startButton: Button
    private lateinit var cancelButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var resultRow: LinearLayout

    private var sourceUri: Uri? = null
    private var resultUri: Uri? = null
    private var previewing = false

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) onPicked(uri)
    }

    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) onStartClicked() else toast("Storage permission is needed to save the result")
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_watermark)

        pickButton = findViewById(R.id.pickButton)
        fileLabel = findViewById(R.id.fileLabel)
        preview = findViewById(R.id.preview)
        textInput = findViewById(R.id.textInput)
        textColorInput = findViewById(R.id.textColorInput)
        effectColorInput = findViewById(R.id.effectColorInput)
        effectGroup = findViewById(R.id.effectGroup)
        effectColorLabel = findViewById(R.id.effectColorLabel)
        effectColorLayout = findViewById(R.id.effectColorLayout)
        effectSwatchScroll = findViewById(R.id.effectSwatchScroll)
        motionGroup = findViewById(R.id.motionGroup)
        sample = findViewById(R.id.sample)
        sizeSlider = findViewById(R.id.sizeSlider)
        opacitySlider = findViewById(R.id.opacitySlider)
        cornerSlider = findViewById(R.id.cornerSlider)
        speedSlider = findViewById(R.id.speedSlider)
        jumpSlider = findViewById(R.id.jumpSlider)
        sizeLabel = findViewById(R.id.sizeLabel)
        opacityLabel = findViewById(R.id.opacityLabel)
        cornerLabel = findViewById(R.id.cornerLabel)
        speedLabel = findViewById(R.id.speedLabel)
        jumpLabel = findViewById(R.id.jumpLabel)
        qualitySwitch = findViewById(R.id.qualitySwitch)
        previewButton = findViewById(R.id.previewButton)
        startButton = findViewById(R.id.startButton)
        cancelButton = findViewById(R.id.cancelButton)
        progressBar = findViewById(R.id.progressBar)
        statusText = findViewById(R.id.statusText)
        resultRow = findViewById(R.id.resultRow)

        Ui.buildSwatches(findViewById(R.id.textSwatches), textColorInput)
        Ui.buildSwatches(findViewById(R.id.effectSwatches), effectColorInput)
        loadPrefs()

        textInput.doAfterTextChanged { updateUi() }
        textColorInput.doAfterTextChanged { updateUi() }
        effectColorInput.doAfterTextChanged { updateUi() }
        effectGroup.setOnCheckedChangeListener { _, _ -> updateUi() }
        motionGroup.setOnCheckedChangeListener { _, _ -> updateUi() }
        for (s in listOf(sizeSlider, opacitySlider, cornerSlider, speedSlider, jumpSlider)) {
            s.addOnChangeListener { _, _, _ -> updateUi() }
        }
        updateUi()

        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }
        pickButton.setOnClickListener {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
        }
        previewButton.setOnClickListener { runPreview() }
        startButton.setOnClickListener { onStartClicked() }
        cancelButton.setOnClickListener {
            JobManager.cancel()
            statusText.text = "Cancelling…"
        }
        findViewById<Button>(R.id.openButton).setOnClickListener { openResult() }
        findViewById<Button>(R.id.shareButton).setOnClickListener { shareResult() }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onStart() {
        super.onStart()
        JobManager.addListener(this)
    }

    override fun onStop() {
        JobManager.removeListener(this)
        super.onStop()
    }

    // ---------------------------------------------------------------- background job state

    override fun onState(state: JobManager.State) {
        when (state) {
            JobManager.State.Idle -> setBusy(false)
            is JobManager.State.Running -> {
                if (state.kind == JobManager.Kind.WATERMARK) {
                    setBusy(true, showProgress = true)
                    resultRow.visibility = View.GONE
                    progressBar.isIndeterminate = state.total == 0
                    if (state.total > 0) progressBar.progress = (state.done * 1000L / state.total).toInt()
                    statusText.text = state.message + "\nYou can leave the app, it keeps working in the background."
                } else {
                    setBusy(true, showProgress = false)
                    statusText.text = "A cover job is running in the background. Please wait for it to finish."
                }
            }
            is JobManager.State.Done -> {
                setBusy(false)
                if (state.kind == JobManager.Kind.WATERMARK) {
                    resultUri = state.uri
                    statusText.text = state.summary
                    resultRow.visibility = View.VISIBLE
                }
            }
            is JobManager.State.Failed -> {
                setBusy(false)
                if (state.kind == JobManager.Kind.WATERMARK) statusText.text = state.message
            }
        }
    }

    override fun onPreview(kind: JobManager.Kind, frame: Bitmap) {
        if (kind == JobManager.Kind.WATERMARK) preview.setImageBitmap(frame)
    }

    // ---------------------------------------------------------------- picking

    private fun onPicked(uri: Uri) {
        sourceUri = uri
        fileLabel.text = "Video: " + (Ui.displayName(this, uri) ?: uri.lastPathSegment ?: "file")
        resultRow.visibility = View.GONE
        JobManager.clearFinished()
        statusText.text = "Tap Preview to see the watermark on a frame."
        lifecycleScope.launch {
            val thumb = withContext(Dispatchers.IO) { grabFrame(uri, 0L, 720) }
            if (thumb != null) preview.setImageBitmap(thumb) else preview.setImageDrawable(null)
        }
    }

    private fun grabFrame(uri: Uri, timeUs: Long, maxSide: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            val f = r.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
            val long = max(f.width, f.height)
            if (long > maxSide) {
                val s = maxSide.toFloat() / long
                Bitmap.createScaledBitmap(f, (f.width * s).toInt(), (f.height * s).toInt(), true)
            } else f
        } catch (e: Exception) {
            null
        } finally {
            runCatching { r.release() }
        }
    }

    // ---------------------------------------------------------------- style

    private fun selectedEffect(): WatermarkEffect = when (effectGroup.checkedRadioButtonId) {
        R.id.effectPlain -> WatermarkEffect.PLAIN
        R.id.effectBackground -> WatermarkEffect.BACKGROUND
        else -> WatermarkEffect.SHADOW
    }

    private fun selectedMotion(): WatermarkMotion =
        if (motionGroup.checkedRadioButtonId == R.id.motionJump) WatermarkMotion.JUMP else WatermarkMotion.GLIDE

    private fun readStyle(): WatermarkStyle? {
        val text = textInput.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) {
            textInput.error = "Type the watermark text"
            textInput.requestFocus()
            return null
        }
        val tc = Ui.parseColor(textColorInput.text?.toString())
        if (tc == null) {
            textColorInput.error = "Invalid color"; return null
        }
        val effect = selectedEffect()
        val ec = Ui.parseColor(effectColorInput.text?.toString())
        if (ec == null && effect != WatermarkEffect.PLAIN) {
            effectColorInput.error = "Invalid color"; return null
        }
        return WatermarkStyle(
            text = text,
            textColor = tc,
            effect = effect,
            effectColor = ec ?: Color.BLACK,
            sizePercent = sizeSlider.value,
            opacityPercent = opacitySlider.value,
            cornerPercent = cornerSlider.value,
            motion = selectedMotion(),
            speed = speedSlider.value,
            jumpSeconds = jumpSlider.value
        )
    }

    private fun updateUi() {
        val effect = selectedEffect()
        val motion = selectedMotion()
        textColorInput.error = null
        effectColorInput.error = null

        val showEffectColor = effect != WatermarkEffect.PLAIN
        effectColorLabel.visibility = if (showEffectColor) View.VISIBLE else View.GONE
        effectColorLayout.visibility = if (showEffectColor) View.VISIBLE else View.GONE
        effectSwatchScroll.visibility = if (showEffectColor) View.VISIBLE else View.GONE
        effectColorLabel.text = if (effect == WatermarkEffect.BACKGROUND) "Background color" else "Shadow color"
        val bgOnly = if (effect == WatermarkEffect.BACKGROUND) View.VISIBLE else View.GONE
        cornerLabel.visibility = bgOnly
        cornerSlider.visibility = bgOnly

        val glide = motion == WatermarkMotion.GLIDE
        speedLabel.visibility = if (glide) View.VISIBLE else View.GONE
        speedSlider.visibility = if (glide) View.VISIBLE else View.GONE
        jumpLabel.visibility = if (glide) View.GONE else View.VISIBLE
        jumpSlider.visibility = if (glide) View.GONE else View.VISIBLE

        sizeLabel.text = "Text size: ${sizeSlider.value.toInt()}% of the video"
        opacityLabel.text = "Opacity: ${opacitySlider.value.toInt()}%"
        cornerLabel.text = "Background corner roundness: ${cornerSlider.value.toInt()}%"
        speedLabel.text = "Speed: ${speedSlider.value.toInt()}"
        jumpLabel.text = "Jump every ${jumpSlider.value.toInt()} second(s)"

        // live sample
        val tc = Ui.parseColor(textColorInput.text?.toString()) ?: Color.WHITE
        val ec = Ui.parseColor(effectColorInput.text?.toString()) ?: Color.BLACK
        sample.text = textInput.text?.toString().orEmpty().ifEmpty { "Sample" }
        sample.setTextColor(tc)
        sample.alpha = opacitySlider.value / 100f
        sample.setShadowLayer(0f, 0f, 0f, 0)
        sample.background = null
        when (effect) {
            WatermarkEffect.SHADOW -> sample.setShadowLayer(6f, 3f, 3f, ec)
            WatermarkEffect.BACKGROUND -> sample.background = GradientDrawable().apply {
                setColor(ec)
                cornerRadius = cornerSlider.value / 100f * Ui.dp(this@WatermarkActivity, 20)
            }
            WatermarkEffect.PLAIN -> Unit
        }
    }

    // ---------------------------------------------------------------- preview

    private fun runPreview() {
        val uri = sourceUri ?: return toast("Pick a video first")
        val style = readStyle() ?: return
        previewing = true
        setBusy(JobManager.isRunning)
        statusText.text = "Making preview…"
        lifecycleScope.launch {
            try {
                val bmp = withContext(Dispatchers.Default) {
                    val r = MediaMetadataRetriever()
                    val durMs = try {
                        r.setDataSource(this@WatermarkActivity, uri)
                        r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    } finally {
                        runCatching { r.release() }
                    }
                    val frame = grabFrame(uri, min(1000L, durMs / 2) * 1000L, 1920)
                        ?: throw IllegalStateException("Could not read a frame")
                    val work = frame.copy(Bitmap.Config.ARGB_8888, true)
                    val editor = MovingWatermarkEditor(style)
                    editor.edit(Canvas(work), work, 0, 0L, work.width, work.height)
                    work
                }
                preview.setImageBitmap(bmp)
                statusText.text = "This is one random position. In the video the watermark keeps moving."
            } catch (e: Exception) {
                Log.e("WatermarkCover", "preview", e)
                statusText.text = "Preview failed: ${e.message}"
            } finally {
                previewing = false
                setBusy(JobManager.isRunning)
            }
        }
    }

    // ---------------------------------------------------------------- start

    private fun onStartClicked() {
        if (JobManager.isRunning) return toast("Another job is still running")
        val uri = sourceUri ?: return toast("Pick a video first")
        val style = readStyle() ?: return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        savePrefs()
        JobManager.start(
            this,
            JobManager.Job(
                kind = JobManager.Kind.WATERMARK,
                uri = uri,
                isVideo = true,
                watermark = style,
                extraQuality = qualitySwitch.isChecked
            )
        )
    }

    // ---------------------------------------------------------------- result

    private fun openResult() {
        val uri = resultUri ?: return
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            toast("No app found to open it")
        }
    }

    private fun shareResult() {
        val uri = resultUri ?: return
        val i = Intent(Intent.ACTION_SEND).setType("video/mp4")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Share"))
    }

    // ---------------------------------------------------------------- helpers

    private fun setBusy(b: Boolean, showProgress: Boolean = false) {
        val locked = b || previewing
        pickButton.isEnabled = !locked
        startButton.isEnabled = !locked
        previewButton.isEnabled = !locked
        cancelButton.visibility = if (b && showProgress) View.VISIBLE else View.GONE
        progressBar.visibility = if (b && showProgress) View.VISIBLE else View.GONE
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun loadPrefs() {
        val p = getSharedPreferences("watermark", MODE_PRIVATE)
        textInput.setText(p.getString("text", ""))
        textColorInput.setText(p.getString("tc", "#FFFFFF"))
        effectColorInput.setText(p.getString("ec", "#000000"))
        when (p.getString("effect", "SHADOW")) {
            "PLAIN" -> effectGroup.check(R.id.effectPlain)
            "BACKGROUND" -> effectGroup.check(R.id.effectBackground)
            else -> effectGroup.check(R.id.effectShadow)
        }
        if (p.getString("motion", "GLIDE") == "JUMP") motionGroup.check(R.id.motionJump)
        else motionGroup.check(R.id.motionGlide)
        sizeSlider.value = p.getFloat("size", 5f).coerceIn(2f, 20f)
        opacitySlider.value = p.getFloat("opacity", 80f).coerceIn(10f, 100f)
        cornerSlider.value = p.getFloat("corner", 60f).coerceIn(0f, 100f)
        speedSlider.value = p.getFloat("speed", 4f).coerceIn(1f, 10f)
        jumpSlider.value = p.getFloat("jump", 3f).coerceIn(1f, 15f)
        qualitySwitch.isChecked = p.getBoolean("quality", true)
    }

    private fun savePrefs() {
        getSharedPreferences("watermark", MODE_PRIVATE).edit()
            .putString("text", textInput.text?.toString())
            .putString("tc", textColorInput.text?.toString())
            .putString("ec", effectColorInput.text?.toString())
            .putString("effect", selectedEffect().name)
            .putString("motion", selectedMotion().name)
            .putFloat("size", sizeSlider.value)
            .putFloat("opacity", opacitySlider.value)
            .putFloat("corner", cornerSlider.value)
            .putFloat("speed", speedSlider.value)
            .putFloat("jump", jumpSlider.value)
            .putBoolean("quality", qualitySwitch.isChecked)
            .apply()
    }
}
