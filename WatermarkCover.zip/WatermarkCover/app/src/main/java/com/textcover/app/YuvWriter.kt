package com.textcover.app

import android.media.Image

/** Converts ARGB pixels into the encoder's YUV 4:2:0 input image (any plane layout). */
object YuvWriter {

    fun write(argb: IntArray, w: Int, h: Int, image: Image) {
        val planes = image.planes
        val yPlane = planes[0]
        val uPlane = planes[1]
        val vPlane = planes[2]

        // ---- Y plane ----
        val yBuf = yPlane.buffer
        val yRow = yPlane.rowStride
        val yPix = yPlane.pixelStride
        val row = ByteArray(w)
        for (j in 0 until h) {
            val off = j * w
            for (i in 0 until w) {
                val c = argb[off + i]
                val r = (c shr 16) and 0xff
                val g = (c shr 8) and 0xff
                val b = c and 0xff
                row[i] = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).toByte()
            }
            if (yPix == 1) {
                yBuf.position(j * yRow)
                yBuf.put(row, 0, w)
            } else {
                val base = j * yRow
                for (i in 0 until w) yBuf.put(base + i * yPix, row[i])
            }
        }

        // ---- U / V planes (2x2 averaged) ----
        val uBuf = uPlane.buffer
        val vBuf = vPlane.buffer
        val uRow = uPlane.rowStride
        val vRow = vPlane.rowStride
        val uPix = uPlane.pixelStride
        val vPix = vPlane.pixelStride
        val cw = w / 2
        val ch = h / 2
        for (j in 0 until ch) {
            val r0 = (2 * j) * w
            val r1 = r0 + w
            for (i in 0 until cw) {
                val x = 2 * i
                val p0 = argb[r0 + x]
                val p1 = argb[r0 + x + 1]
                val p2 = argb[r1 + x]
                val p3 = argb[r1 + x + 1]
                val r = (((p0 shr 16) and 0xff) + ((p1 shr 16) and 0xff) +
                        ((p2 shr 16) and 0xff) + ((p3 shr 16) and 0xff)) shr 2
                val g = (((p0 shr 8) and 0xff) + ((p1 shr 8) and 0xff) +
                        ((p2 shr 8) and 0xff) + ((p3 shr 8) and 0xff)) shr 2
                val b = ((p0 and 0xff) + (p1 and 0xff) + (p2 and 0xff) + (p3 and 0xff)) shr 2
                val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                uBuf.put(j * uRow + i * uPix, u.toByte())
                vBuf.put(j * vRow + i * vPix, v.toByte())
            }
        }
    }
}
