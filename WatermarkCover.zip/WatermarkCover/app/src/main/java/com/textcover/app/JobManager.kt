package com.textcover.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Holds the one running job. The work itself runs inside [ProcessingService]
 * (a foreground service), so it keeps going when the app is closed or the screen is off.
 */
class WatermarkNotFound(message: String) : Exception(message)

object JobManager {

    enum class Kind { COVER, WATERMARK }

    class Job(
        val kind: Kind,
        val uri: Uri,
        val isVideo: Boolean,
        val cover: OverlayStyle? = null,
        val watermark: WatermarkStyle? = null,
        val extraQuality: Boolean = false
    )

    sealed class State {
        object Idle : State()
        data class Running(val kind: Kind, val done: Int, val total: Int, val message: String) : State()
        data class Done(val kind: Kind, val uri: Uri, val mime: String, val summary: String) : State()
        data class Failed(val kind: Kind, val message: String) : State()
    }

    interface Listener {
        fun onState(state: State)
        fun onPreview(kind: Kind, frame: Bitmap) {}
    }

    @Volatile
    var state: State = State.Idle
        private set

    val isRunning: Boolean get() = state is State.Running

    private val main = Handler(Looper.getMainLooper())
    private val listeners = LinkedHashSet<Listener>()
    @Volatile private var pending: Job? = null
    @Volatile private var processor: VideoProcessor? = null
    @Volatile private var cancelRequested = false

    fun addListener(l: Listener) {
        listeners.add(l)
        l.onState(state)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    /** Starts the job in the background service. Returns false if another job is running. */
    fun start(ctx: Context, job: Job): Boolean {
        if (isRunning) return false
        pending = job
        cancelRequested = false
        setState(State.Running(job.kind, 0, 0, "Starting…"))
        ContextCompat.startForegroundService(ctx, Intent(ctx, ProcessingService::class.java))
        return true
    }

    fun cancel() {
        cancelRequested = true
        processor?.cancelled = true
    }

    fun takePending(): Job? {
        val j = pending
        pending = null
        return j
    }

    /** Dismiss a finished result so the screen goes back to normal. */
    fun clearFinished() {
        if (!isRunning) setState(State.Idle)
    }

    private fun setState(s: State) {
        state = s
        main.post { for (l in listeners.toList()) l.onState(s) }
    }

    private fun postPreview(kind: Kind, b: Bitmap) {
        main.post { for (l in listeners.toList()) l.onPreview(kind, b) }
    }

    /** Runs on the service's worker thread. */
    fun execute(ctx: Context, job: Job) {
        try {
            val done = if (job.isVideo) runVideo(ctx, job) else runImage(ctx, job)
            setState(done)
        } catch (e: ProcessingCancelled) {
            setState(State.Failed(job.kind, "Cancelled."))
        } catch (e: WatermarkNotFound) {
            setState(State.Failed(job.kind, e.message ?: "Watermark not found"))
        } catch (e: Throwable) {
            Log.e("WatermarkCover", "job failed", e)
            setState(State.Failed(job.kind, "Error: ${e.message ?: e.javaClass.simpleName}"))
        } finally {
            processor = null
        }
    }

    private fun runVideo(ctx: Context, job: Job): State.Done {
        try {
            return runVideoFast(ctx, job)
        } catch (e: ProcessingCancelled) {
            throw e
        } catch (e: WatermarkNotFound) {
            throw e
        } catch (e: Throwable) {
            Log.w("WatermarkCover", "fast mode failed, using compatible mode", e)
            if (cancelRequested) throw ProcessingCancelled()
            setState(State.Running(job.kind, 0, 0, "Fast mode not supported for this video, using compatible mode…"))
        }
        return runVideoClassic(ctx, job)
    }

    /** GPU + hardware encoder path (Media3). Many times faster than the classic path. */
    private fun runVideoFast(ctx: Context, job: Job): State.Done {
        val probe = MediaProbe.of(ctx, job.uri)
        val dispW = probe.displayWidth
        val dispH = probe.displayHeight
        val overlays = ArrayList<androidx.media3.effect.TextureOverlay>()
        var summary: String
        val startMs = System.currentTimeMillis()

        if (job.kind == Kind.COVER) {
            val style = job.cover!!
            val scanner = CoverScanner(ctx, style)
            var lastPost = 0L
            val watcher = Thread {
                while (!Thread.currentThread().isInterrupted) {
                    if (cancelRequested) scanner.cancelled = true
                    try { Thread.sleep(200) } catch (e: InterruptedException) { return@Thread }
                }
            }.apply { isDaemon = true; start() }
            val scan = try {
                scanner.scan(job.uri, probe.rotation, probe.durationUs) { p ->
                    val now = System.currentTimeMillis()
                    if (now - lastPost > 300) {
                        lastPost = now
                        setState(State.Running(job.kind, (p * 500).toInt(), 1000,
                            "Step 1/2: finding the watermark… ${(p * 100).toInt()}%"))
                    }
                }
            } finally {
                watcher.interrupt()
            }
            if (scan.track.isEmpty) {
                throw WatermarkNotFound("\"${style.targetText}\" was not found in this video. Try Preview to see what text the app can read.")
            }
            val painter = OverlayPainter(style)
            val bmp = painter.renderBox(scan.wordWFrac * dispW, scan.wordHFrac * dispH, dispW)
            val fw = bmp.width.toFloat() / dispW
            val fh = bmp.height.toFloat() / dispH
            for (k in 0 until min(3, max(1, scan.track.maxBoxes))) {
                overlays.add(CoverBoxOverlay(scan.track, k, bmp, fw, fh))
            }
            summary = "Done! Watermark found and covered."
        } else {
            val style = job.watermark!!
            val bmp = renderWatermarkBitmap(style, min(dispW, dispH), dispW)
            overlays.add(MovingTextOverlay(style, bmp))
            summary = "Done! Moving watermark added."
        }

        val tmp = File(ctx.cacheDir, "job_${System.currentTimeMillis()}.mp4")
        try {
            val base = if (job.kind == Kind.COVER) 500 else 0
            val span = 1000 - base
            val stepText = if (job.kind == Kind.COVER) "Step 2/2: " else ""
            setState(State.Running(job.kind, base, 1000, "${stepText}Encoding…"))
            val bitrate = probe.targetBitrate(job.extraQuality)
            FastExporter.export(ctx, job.uri, tmp.absolutePath, overlays, bitrate, { cancelRequested }) { pct ->
                val elapsed = (System.currentTimeMillis() - startMs) / 1000
                setState(State.Running(job.kind, base + span * pct / 100, 1000,
                    "${stepText}Encoding… $pct%  •  ${formatTime(elapsed.toInt())} elapsed"))
            }
            if (cancelRequested) throw ProcessingCancelled()
            if (!tmp.exists() || tmp.length() == 0L) throw IllegalStateException("No output produced")
            setState(State.Running(job.kind, 1000, 1000, "Saving…"))
            val prefix = if (job.kind == Kind.COVER) "WatermarkCover" else "Watermarked"
            val saved = MediaIO.saveVideo(ctx, tmp, "${prefix}_${stamp()}.mp4")
            val secs = ((System.currentTimeMillis() - startMs) / 1000).toInt()
            val mb = tmp.length() / (1024.0 * 1024.0)
            summary += String.format(
                Locale.US, "\n%dx%d, %.1f Mbps, %.1f MB, took %s. Saved to Movies/WatermarkCover.",
                dispW, dispH, bitrate / 1_000_000.0, mb, formatTime(secs)
            )
            return State.Done(job.kind, saved, "video/mp4", summary)
        } finally {
            tmp.delete()
        }
    }

    /** Original CPU frame-by-frame path, used when fast mode isn't supported. */
    private fun runVideoClassic(ctx: Context, job: Job): State.Done {
        val editor: FrameEditor = when (job.kind) {
            Kind.COVER -> CoverEditor(job.cover!!)
            Kind.WATERMARK -> MovingWatermarkEditor(job.watermark!!)
        }
        val tmp = File(ctx.cacheDir, "job_${System.currentTimeMillis()}.mp4")
        val vp = VideoProcessor(ctx, editor, job.extraQuality)
        processor = vp
        if (cancelRequested) vp.cancelled = true
        try {
            val startMs = System.currentTimeMillis()
            var lastPost = 0L
            val res = vp.process(job.uri, tmp, object : VideoProcessor.Listener {
                override fun onStage(text: String) {
                    setState(State.Running(job.kind, 0, 0, text))
                }

                override fun onProgress(done: Int, total: Int, edited: Int) {
                    val now = System.currentTimeMillis()
                    if (now - lastPost < 150 && done < total) return
                    lastPost = now
                    val elapsed = (now - startMs) / 1000.0
                    val eta = if (done > 0) ((total - done) * elapsed / done).toInt() else 0
                    val extra = if (job.kind == Kind.COVER) "  •  covered in $edited" else ""
                    setState(
                        State.Running(
                            job.kind, done, total,
                            "Frame $done / $total$extra  •  ~${formatTime(eta)} left"
                        )
                    )
                }

                override fun onPreview(frame: Bitmap) = postPreview(job.kind, frame)
            })
            setState(State.Running(job.kind, res.frames, res.frames, "Saving…"))
            val prefix = if (job.kind == Kind.COVER) "WatermarkCover" else "Watermarked"
            val saved = MediaIO.saveVideo(ctx, tmp, "${prefix}_${stamp()}.mp4")
            val mb = tmp.length() / (1024.0 * 1024.0)
            var summary = if (job.kind == Kind.COVER)
                "Done! ${res.frames} frames, watermark covered in ${res.edited}."
            else "Done! Watermark added to all ${res.frames} frames."
            summary += String.format(
                Locale.US, "\n%dx%d %s, %.1f Mbps, %.1f MB. Saved to Movies/WatermarkCover.",
                res.width, res.height, res.codec, res.bitrate / 1_000_000.0, mb
            )
            if (res.audioSkipped) summary += "\n(Audio format not supported in MP4, saved without sound.)"
            return State.Done(job.kind, saved, "video/mp4", summary)
        } finally {
            tmp.delete()
        }
    }

    private fun runImage(ctx: Context, job: Job): State.Done {
        setState(State.Running(job.kind, 0, 0, "Processing image…"))
        val bmp = MediaIO.loadImage(ctx, job.uri, 6000)
        val canvas = Canvas(bmp)
        val editor: FrameEditor = when (job.kind) {
            Kind.COVER -> CoverEditor(job.cover!!)
            Kind.WATERMARK -> MovingWatermarkEditor(job.watermark!!)
        }
        val hit = try {
            editor.edit(canvas, bmp, 0, 0L, bmp.width, bmp.height)
        } finally {
            editor.close()
        }
        val prefix = if (job.kind == Kind.COVER) "WatermarkCover" else "Watermarked"
        val saved = MediaIO.saveImage(ctx, bmp, "${prefix}_${stamp()}.jpg")

        val long = max(bmp.width, bmp.height)
        val shown = if (long > 1600) {
            val f = 1600f / long
            Bitmap.createScaledBitmap(bmp, (bmp.width * f).toInt(), (bmp.height * f).toInt(), true)
        } else bmp
        postPreview(job.kind, shown)

        val summary = when {
            job.kind == Kind.WATERMARK -> "Done! Saved to Pictures/WatermarkCover."
            hit -> "Done! Watermark covered. Saved to Pictures/WatermarkCover."
            else -> "\"${job.cover?.targetText}\" was not found, image saved unchanged to Pictures/WatermarkCover."
        }
        return State.Done(job.kind, saved, "image/jpeg", summary)
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun formatTime(sec: Int): String =
        if (sec >= 60) "${sec / 60}m ${sec % 60}s" else "${sec}s"
}
