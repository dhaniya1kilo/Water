package com.textcover.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Holds the one running job. The work itself runs inside [ProcessingService]
 * (a foreground service), so it keeps going when the app is closed or the screen is off.
 */
class WatermarkNotFound(message: String) : Exception(message)
class FastModeFailed(message: String, cause: Throwable?) : Exception(message, cause)

object JobManager {

    enum class Kind { COVER, WATERMARK }

    class Job(
        val kind: Kind,
        val uri: Uri,
        val isVideo: Boolean,
        val cover: OverlayStyle? = null,
        val watermark: WatermarkStyle? = null,
        val extraQuality: Boolean = false,
        val forceSlow: Boolean = false
    )

    sealed class State {
        object Idle : State()
        data class Running(val kind: Kind, val done: Int, val total: Int, val message: String) : State()
        data class Done(val kind: Kind, val uri: Uri, val mime: String, val summary: String) : State()
        /** [canUseSlow] = fast mode failed; the screen offers a "Use slow mode" button. */
        data class Failed(val kind: Kind, val message: String, val canUseSlow: Boolean = false) : State()
    }

    interface Listener {
        fun onState(state: State)
        fun onPreview(kind: Kind, frame: Bitmap) {}
    }

    @Volatile
    var state: State = State.Idle
        private set

    val isRunning: Boolean get() = state is State.Running

    private val main = Handler(Looper.getMainLooper())
    private val listeners = LinkedHashSet<Listener>()
    @Volatile private var pending: Job? = null
    @Volatile private var processor: VideoProcessor? = null
    @Volatile private var cancelRequested = false
    @Volatile private var lastJob: Job? = null
    @Volatile private var processorCancel: (() -> Unit)? = null

    fun addListener(l: Listener) {
        listeners.add(l)
        l.onState(state)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    /** Starts the job in the background service. Returns false if another job is running. */
    fun start(ctx: Context, job: Job): Boolean {
        if (isRunning) return false
        pending = job
        lastJob = job
        cancelRequested = false
        setState(State.Running(job.kind, 0, 0, "Starting…"))
        ContextCompat.startForegroundService(ctx, Intent(ctx, ProcessingService::class.java))
        return true
    }

    /** Re-runs the last job with the slow (CPU) method after fast mode failed. */
    fun retrySlow(ctx: Context): Boolean {
        val j = lastJob ?: return false
        return start(ctx, Job(j.kind, j.uri, j.isVideo, j.cover, j.watermark, j.extraQuality, forceSlow = true))
    }

    fun cancel() {
        cancelRequested = true
        processor?.cancelled = true
        processorCancel?.invoke()
    }

    fun takePending(): Job? {
        val j = pending
        pending = null
        return j
    }

    /** Dismiss a finished result so the screen goes back to normal. */
    fun clearFinished() {
        if (!isRunning) setState(State.Idle)
    }

    private fun setState(s: State) {
        state = s
        main.post { for (l in listeners.toList()) l.onState(s) }
    }

    private fun postPreview(kind: Kind, b: Bitmap) {
        main.post { for (l in listeners.toList()) l.onPreview(kind, b) }
    }

    /** Runs on the service's worker thread. */
    fun execute(ctx: Context, job: Job) {
        try {
            val done = if (job.isVideo) runVideo(ctx, job) else runImage(ctx, job)
            setState(done)
        } catch (e: ProcessingCancelled) {
            setState(State.Failed(job.kind, "Cancelled."))
        } catch (e: WatermarkNotFound) {
            setState(State.Failed(job.kind, e.message ?: "Watermark not found"))
        } catch (e: FastModeFailed) {
            Log.e("WatermarkCover", "fast mode failed", e)
            setState(State.Failed(job.kind, e.message ?: "Fast mode failed", canUseSlow = true))
        } catch (e: Throwable) {
            Log.e("WatermarkCover", "job failed", e)
            setState(State.Failed(job.kind, "Error: ${e.message ?: e.javaClass.simpleName}"))
        } finally {
            processor = null
        }
    }

    private fun runVideo(ctx: Context, job: Job): State.Done {
        if (job.forceSlow) return runVideoClassic(ctx, job)
        try {
            return runVideoFast(ctx, job)
        } catch (e: ProcessingCancelled) {
            throw e
        } catch (e: WatermarkNotFound) {
            throw e
        } catch (e: FastModeFailed) {
            throw e
        } catch (e: Throwable) {
            if (cancelRequested) throw ProcessingCancelled()
            throw FastModeFailed(
                "Fast mode failed on this video.\nReason: ${describe(e)}" +
                    "\n\nPlease send this message to the developer. You can also use slow mode (much slower).",
                e
            )
        }
    }

    /** Short readable description of an error and its causes. */
    private fun describe(e: Throwable): String {
        val parts = ArrayList<String>()
        var t: Throwable? = e
        var n = 0
        while (t != null && n < 4) {
            parts.add("${t.javaClass.simpleName}: ${t.message ?: ""}".trim())
            t = t.cause
            n++
        }
        return parts.joinToString(" ← ").take(600)
    }

    /** Hardware decoder -> GPU -> hardware encoder. Many times faster than the classic path. */
    private fun runVideoFast(ctx: Context, job: Job): State.Done {
        val probe = MediaProbe.of(ctx, job.uri)
        val dispW = probe.displayWidth
        val dispH = probe.displayHeight
        // built fresh for every attempt (the moving watermark keeps its own motion state)
        val makePlan: () -> OverlayPlan
        var summary: String
        val startMs = System.currentTimeMillis()

        if (job.kind == Kind.COVER) {
            val style = job.cover!!
            var lastPost = 0L
            fun scanOnce(): CoverScanner.Result {
                val scanner = CoverScanner(ctx, style)
                val watcher = Thread {
                    while (!Thread.currentThread().isInterrupted) {
                        if (cancelRequested) scanner.cancelled = true
                        try { Thread.sleep(200) } catch (e: InterruptedException) { return@Thread }
                    }
                }.apply { isDaemon = true; start() }
                try {
                    return scanner.scan(job.uri, probe.rotation, probe.durationUs) { p ->
                        val now = System.currentTimeMillis()
                        if (now - lastPost > 300) {
                            lastPost = now
                            val elapsed = ((now - startMs) / 1000).toInt()
                            setState(State.Running(job.kind, (p * 400).toInt(), 1000,
                                "Step 1/2: finding the watermark… ${(p * 100).toInt()}%  •  ${formatTime(elapsed)} elapsed"))
                        }
                    }
                } finally {
                    watcher.interrupt()
                }
            }
            var scanResult: CoverScanner.Result? = null
            var tries = 0
            while (scanResult == null) {
                try {
                    scanResult = scanOnce()
                } catch (e: ProcessingCancelled) {
                    throw e
                } catch (e: Throwable) {
                    Log.w("WatermarkCover", "scan interrupted", e)
                    if (cancelRequested) throw ProcessingCancelled()
                    if (++tries >= 5) throw e
                    setState(State.Running(job.kind, 0, 1000,
                        "Video hardware was busy (another app may be using it). Retrying…"))
                    Thread.sleep(1000L * tries)
                }
            }
            val scan = scanResult!!
            if (scan.track.isEmpty) {
                throw WatermarkNotFound("\"${style.targetText}\" was not found in this video. Try Preview to see what text the app can read.")
            }
            val bmp = OverlayPainter(style).renderBox(scan.wordWFrac * dispW, scan.wordHFrac * dispH, dispW)
            val fw = bmp.width.toFloat() / dispW
            val fh = bmp.height.toFloat() / dispH
            val count = min(3, max(1, scan.track.maxBoxes))
            makePlan = { CoverPlan(scan.track, count, bmp, fw, fh) }
            summary = "Done! Watermark found and covered."
        } else {
            val style = job.watermark!!
            val bmp = renderWatermarkBitmap(style, min(dispW, dispH), dispW)
            val fw = bmp.width.toFloat() / dispW
            val fh = bmp.height.toFloat() / dispH
            makePlan = { MovingTextPlan(style, bmp, fw, fh) }
            summary = "Done! Moving watermark added."
        }

        val tmp = File(ctx.cacheDir, "job_${System.currentTimeMillis()}.mp4")
        try {
            val base = if (job.kind == Kind.COVER) 400 else 0
            val span = 1000 - base
            val stepText = if (job.kind == Kind.COVER) "Step 2/2: " else ""
            setState(State.Running(job.kind, base, 1000, "${stepText}Encoding…"))
            val bitrate = probe.targetBitrate(job.extraQuality)

            val tr = GlTranscoder(ctx)
            processorCancel = { tr.cancelled = true }
            if (cancelRequested) tr.cancelled = true
            var status = "${stepText}Encoding…"
            val res = try {
                tr.run(job.uri, tmp.absolutePath, probe, makePlan(), bitrate,
                    onProgress = { p ->
                        val elapsed = ((System.currentTimeMillis() - startMs) / 1000).toInt()
                        val pct = (p * 100).toInt()
                        status = "${stepText}Encoding…"
                        setState(State.Running(job.kind, base + (span * p).toInt(), 1000,
                            "$status $pct%  •  ${formatTime(elapsed)} elapsed"))
                    },
                    onStatus = { msg ->
                        setState(State.Running(job.kind, (state as? State.Running)?.done ?: base, 1000, msg))
                    }
                )
            } catch (e: ProcessingCancelled) {
                throw e
            } catch (e: Throwable) {
                if (cancelRequested) throw ProcessingCancelled()
                throw FastModeFailed(
                    "Fast mode failed on this video.\nReason: ${describe(e)}" +
                        "\n\nPlease send this message to the developer. You can also use slow mode (much slower).",
                    e
                )
            } finally {
                processorCancel = null
            }
            if (cancelRequested) throw ProcessingCancelled()
            if (!tmp.exists() || tmp.length() == 0L) throw IllegalStateException("No output produced")
            setState(State.Running(job.kind, 1000, 1000, "Saving…"))
            val prefix = if (job.kind == Kind.COVER) "WatermarkCover" else "Watermarked"
            val saved = MediaIO.saveVideo(ctx, tmp, "${prefix}_${stamp()}.mp4")
            val secs = ((System.currentTimeMillis() - startMs) / 1000).toInt()
            val mb = tmp.length() / (1024.0 * 1024.0)
            summary += String.format(
                Locale.US, "\n%dx%d %s, %.1f Mbps, %.1f MB, took %s. Saved to Movies/WatermarkCover.",
                res.width, res.height, res.codec, res.bitrate / 1_000_000.0, mb, formatTime(secs)
            )
            res.audioNote?.let { summary += "\n$it" }
            if (res.interruptions > 0) summary += "\n(Resumed ${res.interruptions} time(s) after the video hardware was busy.)"
            return State.Done(job.kind, saved, "video/mp4", summary)
        } finally {
            tmp.delete()
        }
    }

    /** Original CPU frame-by-frame path, used when fast mode isn't supported. */
    private fun runVideoClassic(ctx: Context, job: Job): State.Done {
        val fps = try { MediaProbe.of(ctx, job.uri).fps } catch (e: Exception) { 30f }
        val editor: FrameEditor = when (job.kind) {
            Kind.COVER -> {
                val c = job.cover!!
                CoverEditor(c.copy(scanEvery = max(1, (fps / c.scansPerSecond.coerceAtLeast(1)).toInt())))
            }
            Kind.WATERMARK -> MovingWatermarkEditor(job.watermark!!)
        }
        val tmp = File(ctx.cacheDir, "job_${System.currentTimeMillis()}.mp4")
        val vp = VideoProcessor(ctx, editor, job.extraQuality)
        processor = vp
        if (cancelRequested) vp.cancelled = true
        try {
            val startMs = System.currentTimeMillis()
            var lastPost = 0L
            val res = vp.process(job.uri, tmp, object : VideoProcessor.Listener {
                override fun onStage(text: String) {
                    setState(State.Running(job.kind, 0, 0, text))
                }

                override fun onProgress(done: Int, total: Int, edited: Int) {
                    val now = System.currentTimeMillis()
                    if (now - lastPost < 150 && done < total) return
                    lastPost = now
                    val elapsed = (now - startMs) / 1000.0
                    val eta = if (done > 0) ((total - done) * elapsed / done).toInt() else 0
                    val extra = if (job.kind == Kind.COVER) "  •  covered in $edited" else ""
                    setState(
                        State.Running(
                            job.kind, done, total,
                            "Frame $done / $total$extra  •  ~${formatTime(eta)} left"
                        )
                    )
                }

                override fun onPreview(frame: Bitmap) = postPreview(job.kind, frame)
            })
            setState(State.Running(job.kind, res.frames, res.frames, "Saving…"))
            val prefix = if (job.kind == Kind.COVER) "WatermarkCover" else "Watermarked"
            val saved = MediaIO.saveVideo(ctx, tmp, "${prefix}_${stamp()}.mp4")
            val mb = tmp.length() / (1024.0 * 1024.0)
            var summary = if (job.kind == Kind.COVER)
                "Done! ${res.frames} frames, watermark covered in ${res.edited}."
            else "Done! Watermark added to all ${res.frames} frames."
            summary += String.format(
                Locale.US, "\n%dx%d %s, %.1f Mbps, %.1f MB. Saved to Movies/WatermarkCover.",
                res.width, res.height, res.codec, res.bitrate / 1_000_000.0, mb
            )
            if (res.audioSkipped) summary += "\n(Audio format not supported in MP4, saved without sound.)"
            return State.Done(job.kind, saved, "video/mp4", summary)
        } finally {
            tmp.delete()
        }
    }

    private fun runImage(ctx: Context, job: Job): State.Done {
        setState(State.Running(job.kind, 0, 0, "Processing image…"))
        val bmp = MediaIO.loadImage(ctx, job.uri, 6000)
        val canvas = Canvas(bmp)
        val editor: FrameEditor = when (job.kind) {
            Kind.COVER -> CoverEditor(job.cover!!)
            Kind.WATERMARK -> MovingWatermarkEditor(job.watermark!!)
        }
        val hit = try {
            editor.edit(canvas, bmp, 0, 0L, bmp.width, bmp.height)
        } finally {
            editor.close()
        }
        val prefix = if (job.kind == Kind.COVER) "WatermarkCover" else "Watermarked"
        val saved = MediaIO.saveImage(ctx, bmp, "${prefix}_${stamp()}.jpg")

        val long = max(bmp.width, bmp.height)
        val shown = if (long > 1600) {
            val f = 1600f / long
            Bitmap.createScaledBitmap(bmp, (bmp.width * f).toInt(), (bmp.height * f).toInt(), true)
        } else bmp
        postPreview(job.kind, shown)

        val summary = when {
            job.kind == Kind.WATERMARK -> "Done! Saved to Pictures/WatermarkCover."
            hit -> "Done! Watermark covered. Saved to Pictures/WatermarkCover."
            else -> "\"${job.cover?.targetText}\" was not found, image saved unchanged to Pictures/WatermarkCover."
        }
        return State.Done(job.kind, saved, "image/jpeg", summary)
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun formatTime(sec: Int): String =
        if (sec >= 60) "${sec / 60}m ${sec % 60}s" else "${sec}s"
}
