package com.textcover.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Fast path: hardware decoder -> GPU (draws the overlay) -> hardware encoder.
 * No per-frame CPU pixel work. Codecs run at background priority so Android
 * doesn't reclaim them. Audio is copied untouched.
 */
class GlTranscoder(private val ctx: Context) {

    @Volatile
    var cancelled = false

    class Result(val width: Int, val height: Int, val codec: String, val bitrate: Int, val audioSkipped: Boolean)

    // codec / muxer state
    private var muxer: MediaMuxer? = null
    private var muxerStarted = false
    private var videoTrackOut = -1
    private var audioTrackOut = -1
    private var audioFormat: MediaFormat? = null
    private var audioSkipped = false
    private val encInfo = MediaCodec.BufferInfo()

    fun run(
        uri: Uri,
        outPath: String,
        probe: MediaProbe,
        plan: OverlayPlan?,
        bitrate: Int,
        boostSpeed: Boolean,
        onProgress: (Float) -> Unit
    ): Result {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        var gl: GlContext? = null
        var inputSurface: Surface? = null
        try {
            extractor.setDataSource(ctx, uri, null)
            var videoIn = -1
            var audioIn = -1
            for (i in 0 until extractor.trackCount) {
                val m = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (videoIn < 0 && m.startsWith("video/")) videoIn = i
                else if (audioIn < 0 && m.startsWith("audio/")) audioIn = i
            }
            if (videoIn < 0) throw IllegalArgumentException("This file has no video track")
            val inFormat = extractor.getTrackFormat(videoIn)
            audioFormat = if (audioIn >= 0) extractor.getTrackFormat(audioIn) else null
            val inMime = inFormat.getString(MediaFormat.KEY_MIME)!!
            val codedW = inFormat.getInteger(MediaFormat.KEY_WIDTH)
            val codedH = inFormat.getInteger(MediaFormat.KEY_HEIGHT)
            val rotation = probe.rotation
            val fps = probe.fps

            // ---- encoder: same codec + size as the source when possible ----
            val choice = chooseEncoder(inMime, codedW, codedH)
            val outW = choice.width
            val outH = choice.height
            var br = bitrate
            if (outW * outH < codedW * codedH) br = (br.toLong() * outW * outH / (codedW.toLong() * codedH)).toInt()
            choice.caps?.let { br = it.bitrateRange.clamp(br) }

            val encFormat = MediaFormat.createVideoFormat(choice.mime, outW, outH).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, br)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps.roundToInt().coerceAtLeast(1))
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                setInteger(MediaFormat.KEY_PRIORITY, 1)
                if (boostSpeed) setInteger(MediaFormat.KEY_OPERATING_RATE, operatingRate(fps))
                if (choice.enc?.isBitrateModeSupported(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR) == true) {
                    setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                }
            }
            val enc = if (choice.name != null) MediaCodec.createByCodecName(choice.name)
            else MediaCodec.createEncoderByType(choice.mime)
            encoder = enc
            enc.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val encSurface = enc.createInputSurface()
            inputSurface = encSurface
            enc.start()

            // ---- GL: renders into the encoder's input surface ----
            val g = GlContext(encSurface, outW, outH)
            gl = g
            if (plan != null) g.setOverlay(rotateForBuffer(plan.bitmap, rotation))

            // ---- decoder: outputs into the GL texture ----
            val decFormat = inFormat
            decFormat.setInteger(MediaFormat.KEY_PRIORITY, 1)
            if (boostSpeed) decFormat.setInteger(MediaFormat.KEY_OPERATING_RATE, operatingRate(fps))
            val dec = MediaCodec.createDecoderByType(inMime)
            decoder = dec
            dec.configure(decFormat, g.decoderSurface, null, 0)
            dec.start()
            extractor.selectTrack(videoIn)

            val m = MediaMuxer(outPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            if (rotation != 0) m.setOrientationHint(rotation)

            // ---- main loop ----
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var decoderDone = false
            var lastPts = -1L
            val durationUs = probe.durationUs
            var lastProgress = 0L
            while (!decoderDone) {
                if (cancelled) throw ProcessingCancelled()
                if (!inputDone) {
                    val inIdx = dec.dequeueInputBuffer(2_000L)
                    if (inIdx >= 0) {
                        val buf = dec.getInputBuffer(inIdx)!!
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            dec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                drainEncoder(enc, false)

                val outIdx = dec.dequeueOutputBuffer(info, 2_000L)
                if (outIdx < 0) continue
                val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                val render = info.size > 0
                dec.releaseOutputBuffer(outIdx, render)
                if (render) {
                    g.awaitFrame()
                    var pts = info.presentationTimeUs
                    if (pts <= lastPts) pts = lastPts + 1
                    lastPts = pts
                    g.drawFrame(plan?.placements(pts), plan, rotation)
                    g.swap(pts * 1000L)
                    val now = System.currentTimeMillis()
                    if (durationUs > 0 && now - lastProgress > 250) {
                        lastProgress = now
                        onProgress((pts.toFloat() / durationUs).coerceIn(0f, 1f))
                    }
                }
                if (eos) {
                    enc.signalEndOfInputStream()
                    decoderDone = true
                }
            }
            drainEncoder(enc, true)
            if (!muxerStarted) throw IllegalStateException("Encoder produced no output")

            // ---- copy audio unchanged ----
            if (audioTrackOut >= 0 && audioIn >= 0) {
                extractor.unselectTrack(videoIn)
                extractor.selectTrack(audioIn)
                extractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                val buf = ByteBuffer.allocateDirect(1 shl 20)
                val ai = MediaCodec.BufferInfo()
                while (true) {
                    val size = extractor.readSampleData(buf, 0)
                    if (size < 0) break
                    val flags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                        MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    ai.set(0, size, extractor.sampleTime, flags)
                    m.writeSampleData(audioTrackOut, buf, ai)
                    if (!extractor.advance()) break
                }
            }
            m.stop()
            muxerStarted = false
            onProgress(1f)
            val codecName = if (choice.mime == MediaFormat.MIMETYPE_VIDEO_HEVC) "HEVC" else "H.264"
            val dispW = if (rotation == 90 || rotation == 270) outH else outW
            val dispH = if (rotation == 90 || rotation == 270) outW else outH
            return Result(dispW, dispH, codecName, br, audioSkipped)
        } finally {
            decoder?.let { runCatching { it.stop() }; runCatching { it.release() } }
            encoder?.let { runCatching { it.stop() }; runCatching { it.release() } }
            gl?.let { runCatching { it.release() } }
            inputSurface?.let { runCatching { it.release() } }
            muxer?.let {
                if (muxerStarted) runCatching { it.stop() }
                runCatching { it.release() }
            }
            runCatching { extractor.release() }
        }
    }

    private fun operatingRate(fps: Float): Int = min(240, max(60, (fps * 3).roundToInt()))

    private fun drainEncoder(enc: MediaCodec, endOfStream: Boolean) {
        var waits = 0
        while (true) {
            val idx = enc.dequeueOutputBuffer(encInfo, if (endOfStream) 10_000L else 0L)
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) return
                if (++waits > 1500) throw IllegalStateException("Encoder did not finish")
            } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                startMuxer(enc.outputFormat)
            } else if (idx >= 0) {
                val buf = enc.getOutputBuffer(idx)
                if ((encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) encInfo.size = 0
                if (encInfo.size > 0 && buf != null) {
                    if (!muxerStarted) throw IllegalStateException("Muxer not started")
                    buf.position(encInfo.offset)
                    buf.limit(encInfo.offset + encInfo.size)
                    muxer!!.writeSampleData(videoTrackOut, buf, encInfo)
                }
                enc.releaseOutputBuffer(idx, false)
                if ((encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }
    }

    private fun startMuxer(videoOutFormat: MediaFormat) {
        if (muxerStarted) return
        val m = muxer ?: throw IllegalStateException("No muxer")
        videoTrackOut = m.addTrack(videoOutFormat)
        audioFormat?.let { af ->
            try {
                audioTrackOut = m.addTrack(af)
            } catch (e: Exception) {
                audioTrackOut = -1
                audioSkipped = true
            }
        }
        m.start()
        muxerStarted = true
    }

    /** The video buffer is stored un-rotated, so the overlay image is rotated the opposite way. */
    private fun rotateForBuffer(b: Bitmap, rotation: Int): Bitmap {
        if (rotation == 0) return b
        val mtx = Matrix().apply { postRotate(-rotation.toFloat()) }
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, mtx, true)
    }

    private class EncoderChoice(
        val name: String?, val mime: String, val width: Int, val height: Int,
        val caps: MediaCodecInfo.VideoCapabilities?, val enc: MediaCodecInfo.EncoderCapabilities?
    )

    private fun chooseEncoder(srcMime: String, w: Int, h: Int): EncoderChoice {
        val infos = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { it.isEncoder }
        fun find(mime: String, allowScale: Boolean): EncoderChoice? {
            val cands = infos.filter { i -> i.supportedTypes.any { it.equals(mime, true) } }.mapNotNull { i ->
                try {
                    val cc = i.getCapabilitiesForType(mime)
                    Triple(i.name, cc.videoCapabilities, cc.encoderCapabilities)
                } catch (e: Exception) {
                    null
                }
            }
            if (cands.isEmpty()) return null
            var scale = 1.0
            repeat(if (allowScale) 40 else 1) {
                val ow = even(w * scale)
                val oh = even(h * scale)
                for ((name, vc, ec) in cands) {
                    if (vc != null && vc.isSizeSupported(ow, oh)) return EncoderChoice(name, mime, ow, oh, vc, ec)
                }
                scale *= 0.9
            }
            return null
        }
        val same = if (srcMime.equals(MediaFormat.MIMETYPE_VIDEO_HEVC, true)) find(MediaFormat.MIMETYPE_VIDEO_HEVC, false) else null
        val avc = find(MediaFormat.MIMETYPE_VIDEO_AVC, true)
        val fallback = EncoderChoice(null, MediaFormat.MIMETYPE_VIDEO_AVC, even(w.toDouble()), even(h.toDouble()), null, null)
        return same ?: avc ?: fallback
    }

    private fun even(v: Double): Int {
        val i = v.toInt().coerceAtLeast(16)
        return i - (i % 2)
    }
}

/** EGL + GLES2 setup that draws decoded frames (and the overlay) into the encoder surface. */
private class GlContext(encoderSurface: Surface, private val width: Int, private val height: Int) {
    private val display: EGLDisplay
    private val context: EGLContext
    private val eglSurface: EGLSurface
    private val oesTex: Int
    private val surfaceTexture: SurfaceTexture
    val decoderSurface: Surface
    private val thread = HandlerThread("frame-listener").apply { start() }
    private val lock = Object()
    private var frameAvailable = false
    private val stMatrix = FloatArray(16)

    private val oesProg: Int
    private val oesPos: Int
    private val oesTexCoord: Int
    private val oesSt: Int
    private val texProg: Int
    private val texPos: Int
    private val texCoord: Int
    private val texAlpha: Int
    private var overlayTex = 0
    private val fullQuad: FloatBuffer = floats(
        // x, y, u, v  (for the decoded frame; uv transformed by the SurfaceTexture matrix)
        -1f, -1f, 0f, 0f,
        1f, -1f, 1f, 0f,
        -1f, 1f, 0f, 1f,
        1f, 1f, 1f, 1f
    )
    private val quad: FloatBuffer = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

    init {
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (display == EGL14.EGL_NO_DISPLAY) throw IllegalStateException("No EGL display")
        val ver = IntArray(2)
        if (!EGL14.eglInitialize(display, ver, 0, ver, 1)) throw IllegalStateException("EGL init failed")
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        if (!EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, num, 0) || num[0] == 0) {
            throw IllegalStateException("No suitable EGL config")
        }
        context = EGL14.eglCreateContext(
            display, configs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
        )
        if (context == EGL14.EGL_NO_CONTEXT) throw IllegalStateException("EGL context failed")
        eglSurface = EGL14.eglCreateWindowSurface(display, configs[0], encoderSurface, intArrayOf(EGL14.EGL_NONE), 0)
        if (eglSurface == EGL14.EGL_NO_SURFACE) throw IllegalStateException("EGL surface failed")
        if (!EGL14.eglMakeCurrent(display, eglSurface, eglSurface, context)) throw IllegalStateException("eglMakeCurrent failed")

        oesProg = program(
            """
            uniform mat4 uSt;
            attribute vec4 aPos;
            attribute vec4 aTex;
            varying vec2 vTex;
            void main() { gl_Position = aPos; vTex = (uSt * aTex).xy; }
            """,
            """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vTex;
            uniform samplerExternalOES sTex;
            void main() { gl_FragColor = texture2D(sTex, vTex); }
            """
        )
        oesPos = GLES20.glGetAttribLocation(oesProg, "aPos")
        oesTexCoord = GLES20.glGetAttribLocation(oesProg, "aTex")
        oesSt = GLES20.glGetUniformLocation(oesProg, "uSt")

        texProg = program(
            """
            attribute vec4 aPos;
            attribute vec2 aTex;
            varying vec2 vTex;
            void main() { gl_Position = aPos; vTex = aTex; }
            """,
            """
            precision mediump float;
            varying vec2 vTex;
            uniform sampler2D sTex;
            uniform float uAlpha;
            void main() { gl_FragColor = texture2D(sTex, vTex) * uAlpha; }
            """
        )
        texPos = GLES20.glGetAttribLocation(texProg, "aPos")
        texCoord = GLES20.glGetAttribLocation(texProg, "aTex")
        texAlpha = GLES20.glGetUniformLocation(texProg, "uAlpha")

        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        oesTex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        surfaceTexture = SurfaceTexture(oesTex)
        surfaceTexture.setOnFrameAvailableListener({
            synchronized(lock) {
                frameAvailable = true
                lock.notifyAll()
            }
        }, Handler(thread.looper))
        decoderSurface = Surface(surfaceTexture)
    }

    fun setOverlay(bmp: Bitmap) {
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        overlayTex = t[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTex)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
    }

    fun awaitFrame() {
        synchronized(lock) {
            val deadline = System.currentTimeMillis() + 5000
            while (!frameAvailable) {
                lock.wait(100)
                if (!frameAvailable && System.currentTimeMillis() > deadline) {
                    throw IllegalStateException("Timed out waiting for a decoded frame")
                }
            }
            frameAvailable = false
        }
        surfaceTexture.updateTexImage()
    }

    fun drawFrame(placements: List<Placement>?, plan: OverlayPlan?, rotation: Int) {
        GLES20.glViewport(0, 0, width, height)
        GLES20.glDisable(GLES20.GL_BLEND)

        // decoded frame
        surfaceTexture.getTransformMatrix(stMatrix)
        GLES20.glUseProgram(oesProg)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES20.glUniformMatrix4fv(oesSt, 1, false, stMatrix, 0)
        bindQuad(fullQuad, oesPos, oesTexCoord)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        // overlay (premultiplied alpha)
        if (plan == null || placements.isNullOrEmpty() || overlayTex == 0) return
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glUseProgram(texProg)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTex)
        val sideways = rotation == 90 || rotation == 270
        // overlay size as a fraction of the stored (un-rotated) buffer
        val bw = if (sideways) plan.fracH else plan.fracW
        val bh = if (sideways) plan.fracW else plan.fracH
        for (p in placements) {
            // display position -> stored buffer position
            val (bx, by) = when (rotation) {
                90 -> Pair(p.cy, 1f - p.cx)
                180 -> Pair(1f - p.cx, 1f - p.cy)
                270 -> Pair(1f - p.cy, p.cx)
                else -> Pair(p.cx, p.cy)
            }
            val l = (bx - bw / 2f) * 2f - 1f
            val r = (bx + bw / 2f) * 2f - 1f
            val t = 1f - (by - bh / 2f) * 2f
            val b = 1f - (by + bh / 2f) * 2f
            quad.clear()
            quad.put(floatArrayOf(
                l, b, 0f, 1f,
                r, b, 1f, 1f,
                l, t, 0f, 0f,
                r, t, 1f, 0f
            ))
            quad.position(0)
            GLES20.glUniform1f(texAlpha, p.alpha)
            bindQuad(quad, texPos, texCoord)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        }
    }

    fun swap(ptsNs: Long) {
        EGLExt.eglPresentationTimeANDROID(display, eglSurface, ptsNs)
        if (!EGL14.eglSwapBuffers(display, eglSurface)) throw IllegalStateException("eglSwapBuffers failed")
    }

    fun release() {
        runCatching { decoderSurface.release() }
        runCatching { surfaceTexture.release() }
        thread.quitSafely()
        EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        EGL14.eglDestroySurface(display, eglSurface)
        EGL14.eglDestroyContext(display, context)
        EGL14.eglReleaseThread()
        EGL14.eglTerminate(display)
    }

    private fun bindQuad(buf: FloatBuffer, posLoc: Int, texLoc: Int) {
        buf.position(0)
        GLES20.glVertexAttribPointer(posLoc, 2, GLES20.GL_FLOAT, false, 16, buf)
        GLES20.glEnableVertexAttribArray(posLoc)
        buf.position(2)
        GLES20.glVertexAttribPointer(texLoc, 2, GLES20.GL_FLOAT, false, 16, buf)
        GLES20.glEnableVertexAttribArray(texLoc)
        buf.position(0)
    }

    private fun program(vs: String, fs: String): Int {
        fun shader(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src.trimIndent())
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw IllegalStateException("Shader error: " + GLES20.glGetShaderInfoLog(s))
            return s
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw IllegalStateException("Program error: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    companion object {
        private const val EGL_RECORDABLE_ANDROID = 0x3142

        private fun floats(vararg v: Float): FloatBuffer =
            ByteBuffer.allocateDirect(v.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                put(v); position(0)
            }
    }
}
