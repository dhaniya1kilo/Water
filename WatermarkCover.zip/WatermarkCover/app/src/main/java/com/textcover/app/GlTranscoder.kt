package com.textcover.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Frame list of a video: timestamps, count and how the frame images are oriented. */
class FrameIndex private constructor(
    private val times: LongArray,
    val total: Int,
    private val frameDurUs: Long,
    /** Rotation needed to turn a frame image (from the media service) into stored orientation. */
    val frameRotation: Int
) {
    fun timeOf(i: Int): Long = when {
        i < times.size -> times[i]
        times.isNotEmpty() -> times.last() + (i - times.size + 1) * frameDurUs
        else -> i * frameDurUs
    }

    fun firstIndexAfter(pts: Long): Int {
        if (pts == Long.MIN_VALUE) return 0
        var i = 0
        while (i < total && timeOf(i) <= pts) i++
        return i
    }

    companion object {
        fun build(ctx: Context, uri: Uri, probe: MediaProbe): FrameIndex {
            val ex = MediaExtractor()
            val times = ArrayList<Long>()
            try {
                ex.setDataSource(ctx, uri, null)
                for (i in 0 until ex.trackCount) {
                    val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                    if (m.startsWith("video/")) {
                        ex.selectTrack(i)
                        while (true) {
                            val t = ex.sampleTime
                            if (t < 0) break
                            times.add(t)
                            if (!ex.advance()) break
                        }
                        break
                    }
                }
            } finally {
                runCatching { ex.release() }
            }
            times.sort()
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                val metaCount = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toIntOrNull()
                val total = when {
                    metaCount != null && times.isNotEmpty() -> min(metaCount, times.size)
                    metaCount != null -> metaCount
                    else -> times.size
                }
                if (total <= 0) throw IllegalStateException("Could not read the video frames")
                // Are frame images already turned upright, or stored-orientation?
                val f = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                val rot = probe.rotation
                val unrotated = f != null && (rot == 90 || rot == 270) && probe.width != probe.height &&
                    f.width == probe.width && f.height == probe.height
                f?.recycle()
                val frameRotation = if (unrotated) 0 else rot
                val dur = (1_000_000f / probe.fps).toLong().coerceAtLeast(1L)
                return FrameIndex(times.toLongArray(), total, dur, frameRotation)
            } finally {
                runCatching { r.release() }
            }
        }
    }
}

/**
 * Fast + reliable path:
 *   Android's media service reads the frames (it is never interrupted by other apps),
 *   a second thread reads ahead, the GPU draws frame + overlay, the hardware encoder saves.
 * If the encoder is ever interrupted, we resume after the last saved frame.
 * At the end the video and audio are joined into one MP4.
 */
class GlTranscoder(private val ctx: Context) {

    @Volatile
    var cancelled = false

    /** True if the job had to switch from the hardware decoder to the safe reader. */
    var usedSafeReader = false
        private set

    class Result(
        val width: Int, val height: Int, val codec: String, val bitrate: Int,
        val audioNote: String?, val interruptions: Int
    )

    private class SegmentFailed(val lastPts: Long, val wroteSamples: Boolean, cause: Throwable) :
        Exception(cause.message, cause)

    private class SegmentInfo(
        val width: Int, val height: Int, val codec: String, val bitrate: Int, val wroteSamples: Boolean
    )

    fun run(
        uri: Uri,
        outPath: String,
        probe: MediaProbe,
        plan: OverlayPlan?,
        bitrate: Int,
        onProgress: (Float) -> Unit,
        onStatus: (String) -> Unit
    ): Result {
        val work = File(ctx.cacheDir, "segments_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            val index by lazy {
                onStatus("Preparing safe frame reading…")
                FrameIndex.build(ctx, uri, probe)
            }
            val segments = ArrayList<File>()
            var resumeAfter = Long.MIN_VALUE
            var interruptions = 0
            var failsWithoutProgress = 0
            var info: SegmentInfo? = null
            var useHardwareDecoder = true
            while (true) {
                if (cancelled) throw ProcessingCancelled()
                val seg = File(work, "seg_${segments.size}_$interruptions.mp4")
                try {
                    info = if (useHardwareDecoder) {
                        onStatus("Starting hardware encoding…")
                        encodeSegmentHw(uri, seg, probe, plan, bitrate, resumeAfter, onProgress)
                    } else {
                        encodeSegment(uri, seg, probe, index, plan, bitrate, resumeAfter, onProgress)
                    }
                    if (info.wroteSamples) segments.add(seg)
                    break
                } catch (e: ProcessingCancelled) {
                    throw e
                } catch (e: SegmentFailed) {
                    Log.w("WatermarkCover", "segment interrupted at ${e.lastPts}", e.cause)
                    interruptions++
                    if (e.wroteSamples && e.lastPts > resumeAfter) {
                        segments.add(seg)
                        resumeAfter = e.lastPts
                        failsWithoutProgress = 0
                    } else {
                        seg.delete()
                        failsWithoutProgress++
                    }
                    if (useHardwareDecoder) {
                        // Android took the hardware decoder away: continue with the safe reader
                        useHardwareDecoder = false
                        failsWithoutProgress = 0
                        onStatus("Hardware decoder was taken by the system, continuing with safe reading…")
                        continue
                    }
                    if (failsWithoutProgress >= 4) throw (e.cause ?: e)
                    onStatus("Encoder was interrupted, resuming…")
                    val until = System.currentTimeMillis() + 800L * failsWithoutProgress
                    while (System.currentTimeMillis() < until) {
                        if (cancelled) throw ProcessingCancelled()
                        Thread.sleep(100)
                    }
                }
            }
            if (segments.isEmpty()) throw IllegalStateException("Encoder produced no video")

            onStatus("Adding audio…")
            val audio = AudioPrep.prepare(ctx, uri, work) { cancelled }
            onStatus("Saving…")
            merge(segments, audio, probe.rotation, outPath)

            val i = info!!
            usedSafeReader = !useHardwareDecoder
            val dispW = if (probe.rotation == 90 || probe.rotation == 270) i.height else i.width
            val dispH = if (probe.rotation == 90 || probe.rotation == 270) i.width else i.height
            return Result(dispW, dispH, i.codec, i.bitrate, audio?.note ?: AudioPrep.lastNote, interruptions)
        } finally {
            work.deleteRecursively()
        }
    }

    /** Reads frames in the background (media service), keeping a few ready. */
    private class Prefetcher(
        private val ctx: Context, private val uri: Uri, private val index: FrameIndex, private val start: Int
    ) : Thread("frame-reader") {
        class Frame(val i: Int, val bmp: Bitmap)
        object End

        val queue = ArrayBlockingQueue<Any>(12)
        @Volatile var stopRequested = false

        private fun offer(x: Any) {
            while (!stopRequested) {
                if (queue.offer(x, 100, TimeUnit.MILLISECONDS)) return
            }
            if (x is Frame) x.bmp.recycle()
        }

        override fun run() {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                val params = MediaMetadataRetriever.BitmapParams()
                params.setPreferredConfig(Bitmap.Config.ARGB_8888)
                var useIndexApi = true
                var i = start
                while (i < index.total && !stopRequested) {
                    val n = min(4, index.total - i)
                    var list: List<Bitmap>? = null
                    if (useIndexApi) {
                        try {
                            val l = r.getFramesAtIndex(i, n, params)
                            if (l.size == n) list = l else l.forEach { it.recycle() }
                        } catch (e: Exception) {
                            Log.w("WatermarkCover", "getFramesAtIndex failed, using time-based reading", e)
                        }
                        if (list == null) useIndexApi = false
                    }
                    if (list == null) {
                        list = (i until i + n).map { k ->
                            r.getFrameAtTime(index.timeOf(k), MediaMetadataRetriever.OPTION_CLOSEST)
                                ?: throw IllegalStateException("Could not read frame ${k + 1}")
                        }
                    }
                    for ((k, b) in list.withIndex()) {
                        if (stopRequested) { b.recycle(); continue }
                        offer(Frame(i + k, b))
                    }
                    i += n
                }
                offer(End)
            } catch (t: Throwable) {
                offer(t)
            } finally {
                runCatching { r.release() }
            }
        }

        fun shutdown() {
            stopRequested = true
            interrupt()
            while (true) {
                val x = queue.poll() ?: break
                if (x is Frame) x.bmp.recycle()
            }
        }
    }

    private class EncoderSetup(val codec: MediaCodec, val surface: Surface, val width: Int, val height: Int, val bitrate: Int, val mime: String)

    /** Same encoder settings for both paths, so the pieces join cleanly. */
    private fun createEncoder(probe: MediaProbe, bitrate: Int): EncoderSetup {
        val codedW = probe.width
        val codedH = probe.height
        val choice = chooseEncoder(probe.videoMime, codedW, codedH)
        val outW = choice.width
        val outH = choice.height
        var br = bitrate
        if (outW * outH < codedW * codedH) br = (br.toLong() * outW * outH / (codedW.toLong() * codedH)).toInt()
        choice.caps?.let { br = it.bitrateRange.clamp(br) }
        val encFormat = MediaFormat.createVideoFormat(choice.mime, outW, outH).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, br)
            setInteger(MediaFormat.KEY_FRAME_RATE, probe.fps.roundToInt().coerceAtLeast(1))
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
            setInteger(MediaFormat.KEY_PRIORITY, 1)
            if (Build.VERSION.SDK_INT >= 29) setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)
            if (choice.enc?.isBitrateModeSupported(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR) == true) {
                setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
            }
        }
        val enc = if (choice.name != null) MediaCodec.createByCodecName(choice.name)
        else MediaCodec.createEncoderByType(choice.mime)
        try {
            enc.configure(encFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val surf = enc.createInputSurface()
            enc.start()
            return EncoderSetup(enc, surf, outW, outH, br, choice.mime)
        } catch (e: Throwable) {
            runCatching { enc.release() }
            throw e
        }
    }

    /**
     * FASTEST PATH: MediaExtractor -> MediaCodec hardware decoder -> OpenGL ES (frame + watermark)
     * -> MediaCodec hardware encoder -> MediaMuxer. No CPU pixel work at all.
     */
    private fun encodeSegmentHw(
        uri: Uri, seg: File, probe: MediaProbe, plan: OverlayPlan?, bitrate: Int,
        resumeAfter: Long, onProgress: (Float) -> Unit
    ): SegmentInfo {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var setup: EncoderSetup? = null
        var gl: GlContext? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var videoTrack = -1
        var lastMuxedPts = Long.MIN_VALUE
        var wrote = false
        val encInfo = MediaCodec.BufferInfo()

        fun drainEncoder(enc: MediaCodec, endOfStream: Boolean) {
            var waits = 0
            while (true) {
                val idx = enc.dequeueOutputBuffer(encInfo, if (endOfStream) 10_000L else 0L)
                if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!endOfStream) return
                    if (++waits > 1500) throw IllegalStateException("Encoder did not finish")
                } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (!muxerStarted) {
                        videoTrack = muxer!!.addTrack(enc.outputFormat)
                        muxer!!.start()
                        muxerStarted = true
                    }
                } else if (idx >= 0) {
                    val buf = enc.getOutputBuffer(idx)
                    if ((encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) encInfo.size = 0
                    if (encInfo.size > 0 && buf != null && muxerStarted) {
                        buf.position(encInfo.offset)
                        buf.limit(encInfo.offset + encInfo.size)
                        muxer!!.writeSampleData(videoTrack, buf, encInfo)
                        wrote = true
                        if (encInfo.presentationTimeUs > lastMuxedPts) lastMuxedPts = encInfo.presentationTimeUs
                    }
                    enc.releaseOutputBuffer(idx, false)
                    if ((encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }

        try {
            extractor.setDataSource(ctx, uri, null)
            var videoIn = -1
            for (i in 0 until extractor.trackCount) {
                val m = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("video/")) { videoIn = i; break }
            }
            if (videoIn < 0) throw IllegalArgumentException("This file has no video track")
            val inFormat = extractor.getTrackFormat(videoIn)
            val inMime = inFormat.getString(MediaFormat.KEY_MIME)!!
            val rotation = probe.rotation

            val es = createEncoder(probe, bitrate)
            setup = es
            val enc = es.codec
            val g = GlContext(es.surface, es.width, es.height)
            gl = g
            if (plan != null) g.setOverlay(rotateForBuffer(plan.bitmap, rotation))

            inFormat.setInteger(MediaFormat.KEY_PRIORITY, 1)
            val dec = MediaCodec.createDecoderByType(inMime)
            decoder = dec
            dec.configure(inFormat, g.decoderSurface, null, 0)
            dec.start()
            extractor.selectTrack(videoIn)
            if (resumeAfter != Long.MIN_VALUE) extractor.seekTo(resumeAfter, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            muxer = MediaMuxer(seg.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var decoderDone = false
            var lastPts = if (resumeAfter == Long.MIN_VALUE) -1L else resumeAfter
            val durationUs = probe.durationUs
            var lastProgress = 0L
            var lastFrameMs = System.currentTimeMillis()
            while (!decoderDone) {
                if (cancelled) throw ProcessingCancelled()
                // watchdog: if the hardware decoder silently stops, switch to the safe reader
                if (System.currentTimeMillis() - lastFrameMs > 15_000L) {
                    throw IllegalStateException("Hardware decoder stopped delivering frames")
                }
                if (!inputDone) {
                    val inIdx = dec.dequeueInputBuffer(2_000L)
                    if (inIdx >= 0) {
                        val buf = dec.getInputBuffer(inIdx)!!
                        val size = extractor.readSampleData(buf, 0)
                        if (size < 0) {
                            dec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                drainEncoder(enc, false)
                val outIdx = dec.dequeueOutputBuffer(info, 2_000L)
                if (outIdx < 0) continue
                val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                // frames already saved (when resuming) are decoded but not drawn
                val render = info.size > 0 && info.presentationTimeUs > lastPts
                dec.releaseOutputBuffer(outIdx, render)
                if (info.size > 0) lastFrameMs = System.currentTimeMillis()
                if (render) {
                    g.awaitFrame()
                    val pts = info.presentationTimeUs
                    lastPts = pts
                    // motion engine: position for THIS frame's time, smoothly interpolated
                    g.drawFrame(plan?.placements(pts), plan, rotation)
                    g.swap(pts * 1000L)
                    val now = System.currentTimeMillis()
                    if (durationUs > 0 && now - lastProgress > 250) {
                        lastProgress = now
                        onProgress((pts.toFloat() / durationUs).coerceIn(0f, 1f))
                    }
                }
                if (eos) {
                    enc.signalEndOfInputStream()
                    decoderDone = true
                }
            }
            drainEncoder(enc, true)
            muxer!!.stop()
            muxerStarted = false
            val codecName = if (es.mime == MediaFormat.MIMETYPE_VIDEO_HEVC) "HEVC" else "H.264"
            return SegmentInfo(es.width, es.height, codecName, es.bitrate, wrote)
        } catch (e: ProcessingCancelled) {
            throw e
        } catch (e: Throwable) {
            var saved = false
            if (muxerStarted && wrote) {
                saved = runCatching { muxer?.stop() }.isSuccess
                muxerStarted = false
            }
            throw SegmentFailed(lastMuxedPts, saved, e)
        } finally {
            decoder?.let { runCatching { it.stop() }; runCatching { it.release() } }
            setup?.let { runCatching { it.codec.stop() }; runCatching { it.codec.release() } }
            gl?.let { runCatching { it.release() } }
            setup?.let { runCatching { it.surface.release() } }
            muxer?.let {
                if (muxerStarted) runCatching { it.stop() }
                runCatching { it.release() }
            }
            runCatching { extractor.release() }
        }
    }

    /** SAFE PATH: frames read by Android's media service (never taken away), then GPU + encoder. */
    private fun encodeSegment(
        uri: Uri, seg: File, probe: MediaProbe, index: FrameIndex, plan: OverlayPlan?, bitrate: Int,
        resumeAfter: Long, onProgress: (Float) -> Unit
    ): SegmentInfo {
        var encoder: MediaCodec? = null
        var gl: GlContext? = null
        var inputSurface: Surface? = null
        var muxer: MediaMuxer? = null
        var prefetch: Prefetcher? = null
        var muxerStarted = false
        var videoTrack = -1
        var lastMuxedPts = Long.MIN_VALUE
        var wrote = false
        val encInfo = MediaCodec.BufferInfo()

        fun drainEncoder(enc: MediaCodec, endOfStream: Boolean) {
            var waits = 0
            while (true) {
                val idx = enc.dequeueOutputBuffer(encInfo, if (endOfStream) 10_000L else 0L)
                if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!endOfStream) return
                    if (++waits > 1500) throw IllegalStateException("Encoder did not finish")
                } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (!muxerStarted) {
                        videoTrack = muxer!!.addTrack(enc.outputFormat)
                        muxer!!.start()
                        muxerStarted = true
                    }
                } else if (idx >= 0) {
                    val buf = enc.getOutputBuffer(idx)
                    if ((encInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) encInfo.size = 0
                    if (encInfo.size > 0 && buf != null && muxerStarted) {
                        buf.position(encInfo.offset)
                        buf.limit(encInfo.offset + encInfo.size)
                        muxer!!.writeSampleData(videoTrack, buf, encInfo)
                        wrote = true
                        if (encInfo.presentationTimeUs > lastMuxedPts) lastMuxedPts = encInfo.presentationTimeUs
                    }
                    enc.releaseOutputBuffer(idx, false)
                    if ((encInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }

        try {
            val rotation = probe.rotation
            val fps = probe.fps
            val codedW = probe.width
            val codedH = probe.height

            // ---- encoder (stored orientation, same as the source) ----
            val es = createEncoder(probe, bitrate)
            encoder = es.codec
            inputSurface = es.surface
            val enc = es.codec
            val outW = es.width
            val outH = es.height
            val br = es.bitrate
            // ---- GL ----
            val g = GlContext(es.surface, outW, outH)
            gl = g
            if (plan != null) g.setOverlay(rotateForBuffer(plan.bitmap, rotation))

            muxer = MediaMuxer(seg.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            // ---- frames ----
            val startIndex = index.firstIndexAfter(resumeAfter)
            val pf = Prefetcher(ctx, uri, index, startIndex)
            prefetch = pf
            pf.start()

            var lastPts = if (resumeAfter == Long.MIN_VALUE) -1L else resumeAfter
            val durationUs = probe.durationUs
            var lastProgress = 0L
            while (true) {
                if (cancelled) throw ProcessingCancelled()
                val item = pf.queue.poll(30, TimeUnit.SECONDS)
                    ?: throw IllegalStateException("Reading frames timed out")
                if (item === Prefetcher.End) break
                if (item is Throwable) throw item
                val fr = item as Prefetcher.Frame
                var pts = index.timeOf(fr.i)
                if (pts <= lastPts) pts = lastPts + 1
                lastPts = pts
                val bmp = if (fr.bmp.config == Bitmap.Config.ARGB_8888) fr.bmp
                else fr.bmp.copy(Bitmap.Config.ARGB_8888, false).also { fr.bmp.recycle() }
                g.uploadFrame(bmp)
                bmp.recycle()
                g.drawBitmapFrame(plan?.placements(pts), plan, rotation, index.frameRotation)
                g.swap(pts * 1000L)
                drainEncoder(enc, false)
                val now = System.currentTimeMillis()
                if (durationUs > 0 && now - lastProgress > 250) {
                    lastProgress = now
                    onProgress((pts.toFloat() / durationUs).coerceIn(0f, 1f))
                }
            }
            enc.signalEndOfInputStream()
            drainEncoder(enc, true)
            muxer!!.stop()
            muxerStarted = false
            val codecName = if (es.mime == MediaFormat.MIMETYPE_VIDEO_HEVC) "HEVC" else "H.264"
            return SegmentInfo(outW, outH, codecName, br, wrote)
        } catch (e: ProcessingCancelled) {
            throw e
        } catch (e: Throwable) {
            var saved = false
            if (muxerStarted && wrote) {
                saved = runCatching { muxer?.stop() }.isSuccess
                muxerStarted = false
            }
            throw SegmentFailed(lastMuxedPts, saved, e)
        } finally {
            prefetch?.let { runCatching { it.shutdown() } }
            encoder?.let { runCatching { it.stop() }; runCatching { it.release() } }
            gl?.let { runCatching { it.release() } }
            inputSurface?.let { runCatching { it.release() } }
            muxer?.let {
                if (muxerStarted) runCatching { it.stop() }
                runCatching { it.release() }
            }
        }
    }

    /** Joins the video pieces and the audio into the final MP4. */
    private fun merge(segments: List<File>, audio: AudioPrep.Source?, rotation: Int, outPath: String) {
        val mux = MediaMuxer(outPath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var started = false
        val extractors = ArrayList<MediaExtractor>()
        try {
            if (rotation != 0) mux.setOrientationHint(rotation)
            val first = MediaExtractor().also { extractors.add(it) }
            first.setDataSource(segments[0].absolutePath)
            val vTrack = mux.addTrack(first.getTrackFormat(0))

            var aTrack = -1
            var aEx: MediaExtractor? = null
            if (audio != null) {
                val ex = MediaExtractor().also { extractors.add(it) }
                if (audio.path != null) ex.setDataSource(audio.path) else ex.setDataSource(ctx, audio.uri!!, null)
                try {
                    aTrack = mux.addTrack(ex.getTrackFormat(audio.track))
                    ex.selectTrack(audio.track)
                    aEx = ex
                } catch (e: Exception) {
                    Log.w("WatermarkCover", "audio track rejected", e)
                    AudioPrep.lastNote = "(This audio format can't be saved in MP4, so the video has no sound.)"
                }
            }
            mux.start()
            started = true

            val buf = ByteBuffer.allocateDirect(4 shl 20)
            val bi = MediaCodec.BufferInfo()
            var lastV = Long.MIN_VALUE
            for ((n, f) in segments.withIndex()) {
                val ex = if (n == 0) first else MediaExtractor().also { extractors.add(it); it.setDataSource(f.absolutePath) }
                ex.selectTrack(0)
                while (true) {
                    if (cancelled) throw ProcessingCancelled()
                    val size = ex.readSampleData(buf, 0)
                    if (size < 0) break
                    val t = ex.sampleTime
                    if (t > lastV) {
                        val flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                            MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                        bi.set(0, size, t, flags)
                        mux.writeSampleData(vTrack, buf, bi)
                        lastV = t
                    }
                    if (!ex.advance()) break
                }
            }
            aEx?.let { ex ->
                while (true) {
                    val size = ex.readSampleData(buf, 0)
                    if (size < 0) break
                    val flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                        MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    bi.set(0, size, ex.sampleTime, flags)
                    mux.writeSampleData(aTrack, buf, bi)
                    if (!ex.advance()) break
                }
            }
            mux.stop()
            started = false
        } finally {
            if (started) runCatching { mux.stop() }
            runCatching { mux.release() }
            for (e in extractors) runCatching { e.release() }
        }
    }

    /** The video buffer is stored un-rotated, so the overlay image is rotated the opposite way. */
    private fun rotateForBuffer(b: Bitmap, rotation: Int): Bitmap {
        if (rotation == 0) return b
        val mtx = Matrix().apply { postRotate(-rotation.toFloat()) }
        return Bitmap.createBitmap(b, 0, 0, b.width, b.height, mtx, true)
    }

    private class EncoderChoice(
        val name: String?, val mime: String, val width: Int, val height: Int,
        val caps: MediaCodecInfo.VideoCapabilities?, val enc: MediaCodecInfo.EncoderCapabilities?
    )

    private fun chooseEncoder(srcMime: String, w: Int, h: Int): EncoderChoice {
        val infos = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { it.isEncoder }
        fun find(mime: String, allowScale: Boolean): EncoderChoice? {
            val cands = infos.filter { i -> i.supportedTypes.any { it.equals(mime, true) } }.mapNotNull { i ->
                try {
                    val cc = i.getCapabilitiesForType(mime)
                    Triple(i.name, cc.videoCapabilities, cc.encoderCapabilities)
                } catch (e: Exception) {
                    null
                }
            }
            if (cands.isEmpty()) return null
            var scale = 1.0
            repeat(if (allowScale) 40 else 1) {
                val ow = even(w * scale)
                val oh = even(h * scale)
                for ((name, vc, ec) in cands) {
                    if (vc != null && vc.isSizeSupported(ow, oh)) return EncoderChoice(name, mime, ow, oh, vc, ec)
                }
                scale *= 0.9
            }
            return null
        }
        val same = if (srcMime.equals(MediaFormat.MIMETYPE_VIDEO_HEVC, true)) find(MediaFormat.MIMETYPE_VIDEO_HEVC, false) else null
        val avc = find(MediaFormat.MIMETYPE_VIDEO_AVC, true)
        val fallback = EncoderChoice(null, MediaFormat.MIMETYPE_VIDEO_AVC, even(w.toDouble()), even(h.toDouble()), null, null)
        return same ?: avc ?: fallback
    }

    private fun even(v: Double): Int {
        val i = v.toInt().coerceAtLeast(16)
        return i - (i % 2)
    }
}

private class GlContext(encoderSurface: Surface, private val width: Int, private val height: Int) {
    private val display: EGLDisplay
    private val context: EGLContext
    private val eglSurface: EGLSurface
    private val oesTex: Int
    private val surfaceTexture: SurfaceTexture
    val decoderSurface: Surface
    private val thread = HandlerThread("frame-listener").apply { start() }
    private val lock = Object()
    private var frameAvailable = false
    private val stMatrix = FloatArray(16)

    private val oesProg: Int
    private val oesPos: Int
    private val oesTexCoord: Int
    private val oesSt: Int
    private val texProg: Int
    private val texPos: Int
    private val texCoord: Int
    private val texAlpha: Int
    private var overlayTex = 0
    private var frameTex = 0
    private var frameTexW = 0
    private var frameTexH = 0
    private val fullQuad: FloatBuffer = floats(
        // x, y, u, v  (for the decoded frame; uv transformed by the SurfaceTexture matrix)
        -1f, -1f, 0f, 0f,
        1f, -1f, 1f, 0f,
        -1f, 1f, 0f, 1f,
        1f, 1f, 1f, 1f
    )
    private val quad: FloatBuffer = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

    init {
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (display == EGL14.EGL_NO_DISPLAY) throw IllegalStateException("No EGL display")
        val ver = IntArray(2)
        if (!EGL14.eglInitialize(display, ver, 0, ver, 1)) throw IllegalStateException("EGL init failed")
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        if (!EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, num, 0) || num[0] == 0) {
            throw IllegalStateException("No suitable EGL config")
        }
        context = EGL14.eglCreateContext(
            display, configs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0
        )
        if (context == EGL14.EGL_NO_CONTEXT) throw IllegalStateException("EGL context failed")
        eglSurface = EGL14.eglCreateWindowSurface(display, configs[0], encoderSurface, intArrayOf(EGL14.EGL_NONE), 0)
        if (eglSurface == EGL14.EGL_NO_SURFACE) throw IllegalStateException("EGL surface failed")
        if (!EGL14.eglMakeCurrent(display, eglSurface, eglSurface, context)) throw IllegalStateException("eglMakeCurrent failed")

        oesProg = program(
            """
            uniform mat4 uSt;
            attribute vec4 aPos;
            attribute vec4 aTex;
            varying vec2 vTex;
            void main() { gl_Position = aPos; vTex = (uSt * aTex).xy; }
            """,
            """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vTex;
            uniform samplerExternalOES sTex;
            void main() { gl_FragColor = texture2D(sTex, vTex); }
            """
        )
        oesPos = GLES20.glGetAttribLocation(oesProg, "aPos")
        oesTexCoord = GLES20.glGetAttribLocation(oesProg, "aTex")
        oesSt = GLES20.glGetUniformLocation(oesProg, "uSt")

        texProg = program(
            """
            attribute vec4 aPos;
            attribute vec2 aTex;
            varying vec2 vTex;
            void main() { gl_Position = aPos; vTex = aTex; }
            """,
            """
            precision mediump float;
            varying vec2 vTex;
            uniform sampler2D sTex;
            uniform float uAlpha;
            void main() { gl_FragColor = texture2D(sTex, vTex) * uAlpha; }
            """
        )
        texPos = GLES20.glGetAttribLocation(texProg, "aPos")
        texCoord = GLES20.glGetAttribLocation(texProg, "aTex")
        texAlpha = GLES20.glGetUniformLocation(texProg, "uAlpha")

        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        oesTex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        surfaceTexture = SurfaceTexture(oesTex)
        surfaceTexture.setOnFrameAvailableListener({
            synchronized(lock) {
                frameAvailable = true
                lock.notifyAll()
            }
        }, Handler(thread.looper))
        decoderSurface = Surface(surfaceTexture)
    }

    fun setOverlay(bmp: Bitmap) {
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        overlayTex = t[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTex)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
    }

    fun awaitFrame() {
        synchronized(lock) {
            val deadline = System.currentTimeMillis() + 5000
            while (!frameAvailable) {
                lock.wait(100)
                if (!frameAvailable && System.currentTimeMillis() > deadline) {
                    throw IllegalStateException("Timed out waiting for a decoded frame")
                }
            }
            frameAvailable = false
        }
        surfaceTexture.updateTexImage()
    }

    /** Uploads a frame image (from the media service) to the GPU. */
    fun uploadFrame(bmp: Bitmap) {
        if (frameTex == 0) {
            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            frameTex = t[0]
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, frameTex)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        } else {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, frameTex)
        }
        if (bmp.width == frameTexW && bmp.height == frameTexH) {
            GLUtils.texSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, bmp)
        } else {
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
            frameTexW = bmp.width
            frameTexH = bmp.height
        }
    }

    /**
     * Draws the uploaded frame plus the overlay. [frameRotation] is how the frame image is turned
     * relative to the stored video (0 if it is already stored-orientation).
     */
    fun drawBitmapFrame(placements: List<Placement>?, plan: OverlayPlan?, rotation: Int, frameRotation: Int) {
        GLES20.glViewport(0, 0, width, height)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glUseProgram(texProg)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, frameTex)
        // corners of the stored buffer -> where they are in the (display-oriented) frame image
        fun uv(bx: Float, by: Float): FloatArray = when (frameRotation) {
            90 -> floatArrayOf(1f - by, bx)
            180 -> floatArrayOf(1f - bx, 1f - by)
            270 -> floatArrayOf(by, 1f - bx)
            else -> floatArrayOf(bx, by)
        }
        val bl = uv(0f, 1f); val br = uv(1f, 1f); val tl = uv(0f, 0f); val tr = uv(1f, 0f)
        quad.clear()
        quad.put(floatArrayOf(
            -1f, -1f, bl[0], bl[1],
            1f, -1f, br[0], br[1],
            -1f, 1f, tl[0], tl[1],
            1f, 1f, tr[0], tr[1]
        ))
        quad.position(0)
        GLES20.glUniform1f(texAlpha, 1f)
        bindQuad(quad, texPos, texCoord)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        drawOverlay(placements, plan, rotation)
    }

    fun drawFrame(placements: List<Placement>?, plan: OverlayPlan?, rotation: Int) {
        GLES20.glViewport(0, 0, width, height)
        GLES20.glDisable(GLES20.GL_BLEND)

        // decoded frame
        surfaceTexture.getTransformMatrix(stMatrix)
        GLES20.glUseProgram(oesProg)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
        GLES20.glUniformMatrix4fv(oesSt, 1, false, stMatrix, 0)
        bindQuad(fullQuad, oesPos, oesTexCoord)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        drawOverlay(placements, plan, rotation)
    }

    private fun drawOverlay(placements: List<Placement>?, plan: OverlayPlan?, rotation: Int) {

        // overlay (premultiplied alpha)
        if (plan == null || placements.isNullOrEmpty() || overlayTex == 0) return
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glUseProgram(texProg)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTex)
        val sideways = rotation == 90 || rotation == 270
        // overlay size as a fraction of the stored (un-rotated) buffer
        val bw = if (sideways) plan.fracH else plan.fracW
        val bh = if (sideways) plan.fracW else plan.fracH
        for (p in placements) {
            // display position -> stored buffer position
            val (bx, by) = when (rotation) {
                90 -> Pair(p.cy, 1f - p.cx)
                180 -> Pair(1f - p.cx, 1f - p.cy)
                270 -> Pair(1f - p.cy, p.cx)
                else -> Pair(p.cx, p.cy)
            }
            val l = (bx - bw / 2f) * 2f - 1f
            val r = (bx + bw / 2f) * 2f - 1f
            val t = 1f - (by - bh / 2f) * 2f
            val b = 1f - (by + bh / 2f) * 2f
            quad.clear()
            quad.put(floatArrayOf(
                l, b, 0f, 1f,
                r, b, 1f, 1f,
                l, t, 0f, 0f,
                r, t, 1f, 0f
            ))
            quad.position(0)
            GLES20.glUniform1f(texAlpha, p.alpha)
            bindQuad(quad, texPos, texCoord)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        }
    }

    fun swap(ptsNs: Long) {
        EGLExt.eglPresentationTimeANDROID(display, eglSurface, ptsNs)
        if (!EGL14.eglSwapBuffers(display, eglSurface)) throw IllegalStateException("eglSwapBuffers failed")
    }

    fun release() {
        runCatching { decoderSurface.release() }
        runCatching { surfaceTexture.release() }
        thread.quitSafely()
        EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        EGL14.eglDestroySurface(display, eglSurface)
        EGL14.eglDestroyContext(display, context)
        EGL14.eglReleaseThread()
        EGL14.eglTerminate(display)
    }

    private fun bindQuad(buf: FloatBuffer, posLoc: Int, texLoc: Int) {
        buf.position(0)
        GLES20.glVertexAttribPointer(posLoc, 2, GLES20.GL_FLOAT, false, 16, buf)
        GLES20.glEnableVertexAttribArray(posLoc)
        buf.position(2)
        GLES20.glVertexAttribPointer(texLoc, 2, GLES20.GL_FLOAT, false, 16, buf)
        GLES20.glEnableVertexAttribArray(texLoc)
        buf.position(0)
    }

    private fun program(vs: String, fs: String): Int {
        fun shader(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src.trimIndent())
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw IllegalStateException("Shader error: " + GLES20.glGetShaderInfoLog(s))
            return s
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw IllegalStateException("Program error: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    companion object {
        private const val EGL_RECORDABLE_ANDROID = 0x3142

        private fun floats(vararg v: Float): FloatBuffer =
            ByteBuffer.allocateDirect(v.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                put(v); position(0)
            }
    }
}
