package com.textcover.app

/** Everything the user configured for the cover box. */
data class OverlayStyle(
    val targetText: String,        // the watermark word(s) to search for
    val replacementText: String,   // text drawn on top (can be empty = plain box)
    val textColor: Int,
    val bgColor: Int,
    val cornerPercent: Float,      // 0 = square, 100 = fully rounded pill
    val paddingPercent: Float,     // extra space around the word, % of word height
    val textScalePercent: Float,   // text height as % of the watermark word height
    val fuzzy: Boolean,            // tolerate small OCR mistakes
    val holdWhenMissing: Boolean,  // keep last box for a few frames if OCR misses
    val devanagari: Boolean,       // use the Hindi / Devanagari OCR model
    val scanEvery: Int = 1         // 1 = scan every single frame
)
