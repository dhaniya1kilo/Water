package com.textcover.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.IOException
import kotlin.math.max

object MediaIO {
    private const val FOLDER = "WatermarkCover"

    /** Loads an image (EXIF rotation applied), mutable ARGB, long side limited to [maxSide]. */
    fun loadImage(ctx: Context, uri: Uri, maxSide: Int): Bitmap {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            decoder.isMutableRequired = true
            val w = info.size.width
            val h = info.size.height
            val long = max(w, h)
            if (long > maxSide) {
                val f = maxSide.toFloat() / long
                decoder.setTargetSize((w * f).toInt().coerceAtLeast(1), (h * f).toInt().coerceAtLeast(1))
            }
        }
        if (bmp.config == Bitmap.Config.ARGB_8888 && bmp.isMutable) return bmp
        val copy = bmp.copy(Bitmap.Config.ARGB_8888, true)
        bmp.recycle()
        return copy
    }

    fun saveVideo(ctx: Context, file: File, name: String): Uri {
        val uri = insert(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, name, "video/mp4", Environment.DIRECTORY_MOVIES)
        try {
            val out = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("Cannot write output")
            out.use { o -> file.inputStream().use { it.copyTo(o) } }
            publish(ctx, uri)
            return uri
        } catch (e: Exception) {
            runCatching { ctx.contentResolver.delete(uri, null, null) }
            throw e
        }
    }

    fun saveImage(ctx: Context, bitmap: Bitmap, name: String): Uri {
        val uri = insert(ctx, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, name, "image/jpeg", Environment.DIRECTORY_PICTURES)
        try {
            val out = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("Cannot write output")
            out.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            publish(ctx, uri)
            return uri
        } catch (e: Exception) {
            runCatching { ctx.contentResolver.delete(uri, null, null) }
            throw e
        }
    }

    @Suppress("DEPRECATION")
    private fun insert(ctx: Context, collection: Uri, name: String, mime: String, dirType: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$dirType/$FOLDER")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(dirType), FOLDER)
                dir.mkdirs()
                put(MediaStore.MediaColumns.DATA, File(dir, name).absolutePath)
            }
        }
        return ctx.contentResolver.insert(collection, values)
            ?: throw IOException("Could not create the output file")
    }

    private fun publish(ctx: Context, uri: Uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val v = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            ctx.contentResolver.update(uri, v, null, null)
        }
    }
}
