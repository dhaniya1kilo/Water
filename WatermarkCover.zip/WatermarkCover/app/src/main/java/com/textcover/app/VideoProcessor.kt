package com.textcover.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class ProcessingCancelled : Exception("Cancelled")

/**
 * Re-encodes a video frame by frame:
 *   decode frame -> OCR search for the word -> draw rounded box + text -> encode (H.264).
 * The original audio track is copied unchanged.
 */
class VideoProcessor(private val context: Context, private val style: OverlayStyle) {

    interface Listener {
        fun onProgress(done: Int, total: Int, framesWithMatch: Int)
        fun onPreview(frame: Bitmap)
    }

    data class Result(
        val frames: Int,
        val framesWithMatch: Int,
        val audioCopied: Boolean,
        val audioSkipped: Boolean
    )

    @Volatile
    var cancelled = false

    private var muxer: MediaMuxer? = null
    private var muxerStarted = false
    private var videoTrackOut = -1
    private var audioTrackOut = -1
    private var audioFormat: MediaFormat? = null
    private var audioSkipped = false
    private var useIndexApi = true
    private val bufferInfo = MediaCodec.BufferInfo()

    fun process(uri: Uri, outFile: File, listener: Listener): Result {
        val retriever = MediaMetadataRetriever()
        val extractor = MediaExtractor()
        val finder = WatermarkFinder(style.targetText, style.fuzzy, style.devanagari)
        var encoder: MediaCodec? = null
        try {
            retriever.setDataSource(context, uri)
            extractor.setDataSource(context, uri, null)

            // ---- find tracks ----
            var videoIn = -1
            var audioIn = -1
            for (i in 0 until extractor.trackCount) {
                val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (videoIn < 0 && mime.startsWith("video/")) videoIn = i
                else if (audioIn < 0 && mime.startsWith("audio/")) audioIn = i
            }
            if (videoIn < 0) throw IllegalArgumentException("This file has no video track")
            val videoFormat = extractor.getTrackFormat(videoIn)
            audioFormat = if (audioIn >= 0) extractor.getTrackFormat(audioIn) else null

            // ---- frame timestamps (keeps original timing / variable frame rate) ----
            val times = ArrayList<Long>()
            extractor.selectTrack(videoIn)
            while (true) {
                val t = extractor.sampleTime
                if (t < 0) break
                times.add(t)
                if (!extractor.advance()) break
            }
            extractor.unselectTrack(videoIn)
            times.sort()

            val metaCount = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT
            )?.toIntOrNull()
            val total = when {
                metaCount != null && times.isNotEmpty() -> min(metaCount, times.size)
                metaCount != null -> metaCount
                else -> times.size
            }
            if (total <= 0) throw IllegalStateException("Could not read the video frames")

            val durationUs = (retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L) * 1000L
            val fps = (videoFormat.number(MediaFormat.KEY_FRAME_RATE)?.toFloat()
                ?: if (durationUs > 0) total * 1_000_000f / durationUs else 30f)
                .coerceIn(1f, 240f)
            val frameDurUs = (1_000_000f / fps).toLong().coerceAtLeast(1L)

            fun timeOf(i: Int): Long = when {
                i < times.size -> times[i]
                times.isNotEmpty() -> times.last() + (i - times.size + 1) * frameDurUs
                else -> i * frameDurUs
            }

            // ---- orientation ----
            val rotation = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION
            )?.toIntOrNull() ?: 0
            val metaW = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH
            )?.toIntOrNull() ?: 0
            val metaH = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT
            )?.toIntOrNull() ?: 0

            val first = grab(retriever, 0, 1) { timeOf(it) }.first()
            val srcW = first.width
            val srcH = first.height
            first.recycle()
            // If the decoder gave us an un-rotated frame, let the player rotate it via the hint.
            val framesUnrotated = (rotation == 90 || rotation == 270) &&
                    metaW != metaH && srcW == metaW && srcH == metaH
            val orientationHint = if (framesUnrotated) rotation else 0

            // ---- encoder ----
            val choice = chooseEncoder(srcW, srcH)
            val outW = choice.width
            val outH = choice.height
            val origBitrate = videoFormat.number(MediaFormat.KEY_BIT_RATE)?.toInt() ?: 0
            val heuristic = (outW.toDouble() * outH * fps * 0.12).toInt()
            var bitrate = max(origBitrate, heuristic).coerceIn(1_000_000, 50_000_000)
            choice.caps?.let { bitrate = it.bitrateRange.clamp(bitrate) }

            val format = MediaFormat.createVideoFormat(MIME, outW, outH).apply {
                setInteger(
                    MediaFormat.KEY_COLOR_FORMAT,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
                )
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps.roundToInt().coerceAtLeast(1))
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            val enc = if (choice.name != null) MediaCodec.createByCodecName(choice.name)
            else MediaCodec.createEncoderByType(MIME)
            encoder = enc
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()

            val mux = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux
            if (orientationHint != 0) mux.setOrientationHint(orientationHint)

            // ---- frame loop ----
            val work = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(work)
            val dst = Rect(0, 0, outW, outH)
            val scalePaint = Paint(Paint.FILTER_BITMAP_FLAG)
            val pixels = IntArray(outW * outH)
            val painter = OverlayPainter(style)
            val tracker = BoxTracker(if (style.holdWhenMissing) HOLD_FRAMES else 0)
            val batch = if (srcW.toLong() * srcH > 2_100_000L) 2 else 6
            val prevW = min(480, outW)
            val prevH = max(1, (outH * prevW.toFloat() / outW).roundToInt())

            var index = 0
            var matched = 0
            var lastPts = -1L
            while (index < total) {
                if (cancelled) throw ProcessingCancelled()
                val count = min(batch, total - index)
                val frames = grab(retriever, index, count) { timeOf(it) }
                for ((k, src) in frames.withIndex()) {
                    val i = index + k
                    canvas.drawBitmap(src, null, dst, scalePaint)
                    src.recycle()

                    // 1) search the watermark in THIS frame
                    val found = if (i % style.scanEvery == 0) finder.find(work) else null
                    val boxes = tracker.update(found)
                    if (boxes.isNotEmpty()) matched++

                    // 2) cover it
                    painter.draw(canvas, boxes, outW, outH)

                    // 3) encode it
                    work.getPixels(pixels, 0, outW, 0, 0, outW, outH)
                    var pts = timeOf(i)
                    if (pts <= lastPts) pts = lastPts + 1
                    lastPts = pts
                    feedFrame(enc, pixels, outW, outH, pts)

                    if (i % 15 == 0) listener.onPreview(Bitmap.createScaledBitmap(work, prevW, prevH, true))
                    listener.onProgress(i + 1, total, matched)
                    if (cancelled) throw ProcessingCancelled()
                }
                index += count
            }
            work.recycle()

            // ---- finish video ----
            while (true) {
                val idx = enc.dequeueInputBuffer(10_000L)
                if (idx >= 0) {
                    enc.queueInputBuffer(idx, 0, 0, lastPts + 1, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
                drain(enc, false)
            }
            drain(enc, true)
            if (!muxerStarted) throw IllegalStateException("Encoder produced no output")

            // ---- copy audio unchanged ----
            var audioCopied = false
            if (audioTrackOut >= 0 && audioIn >= 0) {
                extractor.selectTrack(audioIn)
                extractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                val maxIn = audioFormat?.number(MediaFormat.KEY_MAX_INPUT_SIZE)?.toInt() ?: 0
                val buf = ByteBuffer.allocateDirect(max(maxIn, 1 shl 20))
                val info = MediaCodec.BufferInfo()
                while (true) {
                    val size = extractor.readSampleData(buf, 0)
                    if (size < 0) break
                    val flags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                        MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    info.set(0, size, extractor.sampleTime, flags)
                    mux.writeSampleData(audioTrackOut, buf, info)
                    if (!extractor.advance()) break
                }
                audioCopied = true
            }

            mux.stop()
            muxerStarted = false
            return Result(total, matched, audioCopied, audioSkipped)
        } finally {
            encoder?.let { runCatching { it.stop() }; runCatching { it.release() } }
            muxer?.let {
                if (muxerStarted) runCatching { it.stop() }
                runCatching { it.release() }
            }
            runCatching { retriever.release() }
            runCatching { extractor.release() }
            runCatching { finder.close() }
        }
    }

    private fun feedFrame(enc: MediaCodec, pixels: IntArray, w: Int, h: Int, ptsUs: Long) {
        while (true) {
            val idx = enc.dequeueInputBuffer(10_000L)
            if (idx >= 0) {
                val image = enc.getInputImage(idx)
                    ?: throw IllegalStateException("This phone's encoder does not accept image input")
                YuvWriter.write(pixels, w, h, image)
                enc.queueInputBuffer(idx, 0, w * h * 3 / 2, ptsUs, 0)
                break
            }
            drain(enc, false)
            if (cancelled) throw ProcessingCancelled()
        }
        drain(enc, false)
    }

    private fun drain(enc: MediaCodec, endOfStream: Boolean) {
        var waits = 0
        while (true) {
            val idx = enc.dequeueOutputBuffer(bufferInfo, if (endOfStream) 10_000L else 0L)
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) return
                if (++waits > 1000) throw IllegalStateException("Encoder did not finish")
            } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                startMuxer(enc.outputFormat)
            } else if (idx >= 0) {
                val buf = enc.getOutputBuffer(idx)
                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) bufferInfo.size = 0
                if (bufferInfo.size > 0 && buf != null) {
                    if (!muxerStarted) throw IllegalStateException("Muxer not started")
                    buf.position(bufferInfo.offset)
                    buf.limit(bufferInfo.offset + bufferInfo.size)
                    muxer!!.writeSampleData(videoTrackOut, buf, bufferInfo)
                }
                enc.releaseOutputBuffer(idx, false)
                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }
    }

    private fun startMuxer(videoOutFormat: MediaFormat) {
        if (muxerStarted) return
        val m = muxer ?: throw IllegalStateException("No muxer")
        videoTrackOut = m.addTrack(videoOutFormat)
        audioFormat?.let { af ->
            try {
                audioTrackOut = m.addTrack(af)
            } catch (e: Exception) {
                audioTrackOut = -1
                audioSkipped = true
            }
        }
        m.start()
        muxerStarted = true
    }

    /** Batch-decodes frames by index; falls back to time-based seeking if the device can't. */
    private fun grab(
        r: MediaMetadataRetriever, start: Int, count: Int, timeOf: (Int) -> Long
    ): List<Bitmap> {
        if (useIndexApi) {
            try {
                val params = MediaMetadataRetriever.BitmapParams()
                params.setPreferredConfig(Bitmap.Config.ARGB_8888)
                val list = r.getFramesAtIndex(start, count, params)
                if (list.size == count) return list
                list.forEach { it.recycle() }
            } catch (e: Exception) {
                // fall through
            }
            useIndexApi = false
        }
        return (start until start + count).map { i ->
            r.getFrameAtTime(timeOf(i), MediaMetadataRetriever.OPTION_CLOSEST)
                ?: throw IllegalStateException("Could not decode frame ${i + 1}")
        }
    }

    private data class EncoderChoice(
        val name: String?, val width: Int, val height: Int,
        val caps: MediaCodecInfo.VideoCapabilities?
    )

    private fun chooseEncoder(w: Int, h: Int): EncoderChoice {
        val candidates = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .filter { info -> info.isEncoder && info.supportedTypes.any { it.equals(MIME, true) } }
            .mapNotNull { info ->
                try {
                    val cc = info.getCapabilitiesForType(MIME)
                    if (cc.colorFormats.contains(MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible))
                        Pair(info.name, cc.videoCapabilities)
                    else null
                } catch (e: Exception) {
                    null
                }
            }
        var scale = 1.0
        repeat(40) {
            val ow = even(w * scale)
            val oh = even(h * scale)
            if (candidates.isEmpty()) return EncoderChoice(null, ow, oh, null)
            for ((name, vc) in candidates) {
                if (vc != null && vc.isSizeSupported(ow, oh)) return EncoderChoice(name, ow, oh, vc)
            }
            scale *= 0.9
        }
        return EncoderChoice(null, even(w * scale), even(h * scale), null)
    }

    private fun even(v: Double): Int {
        val i = v.toInt().coerceAtLeast(16)
        return i - (i % 2)
    }

    private fun MediaFormat.number(key: String): Number? {
        if (!containsKey(key)) return null
        return try {
            getInteger(key)
        } catch (e: Exception) {
            try {
                getFloat(key)
            } catch (e2: Exception) {
                null
            }
        }
    }

    companion object {
        private const val MIME = MediaFormat.MIMETYPE_VIDEO_AVC
        private const val HOLD_FRAMES = 12
    }
}
