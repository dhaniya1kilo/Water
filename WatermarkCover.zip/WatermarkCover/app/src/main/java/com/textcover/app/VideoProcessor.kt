package com.textcover.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import java.io.Closeable
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class ProcessingCancelled : Exception("Cancelled")

/** Something that changes each video frame (cover a watermark, add a watermark, ...). */
interface FrameEditor : Closeable {
    /** True if the editor wants to look at a few frames from across the video before starting. */
    val wantsSamples: Boolean get() = false
    fun onSample(frame: Bitmap) {}
    fun onSamplesDone() {}

    /** Draw onto [canvas] (which paints into [frame]). Return true if something was drawn. */
    fun edit(canvas: Canvas, frame: Bitmap, index: Int, ptsUs: Long, w: Int, h: Int): Boolean

    override fun close() {}
}

/**
 * Re-encodes a video frame by frame: decode -> edit -> encode.
 * Keeps resolution, frame timing and codec (HEVC stays HEVC when possible), and targets the
 * source bitrate so quality and file size stay about the same. Audio is copied untouched.
 */
class VideoProcessor(
    private val context: Context,
    private val editor: FrameEditor,
    private val extraQuality: Boolean
) {

    interface Listener {
        fun onStage(text: String)
        fun onProgress(done: Int, total: Int, edited: Int)
        fun onPreview(frame: Bitmap)
    }

    data class Result(
        val frames: Int,
        val edited: Int,
        val audioSkipped: Boolean,
        val codec: String,
        val bitrate: Int,
        val width: Int,
        val height: Int
    )

    @Volatile
    var cancelled = false

    private var muxer: MediaMuxer? = null
    private var muxerStarted = false
    private var videoTrackOut = -1
    private var audioTrackOut = -1
    private var audioFormat: MediaFormat? = null
    private var audioSkipped = false
    private var useIndexApi = true
    private val bufferInfo = MediaCodec.BufferInfo()

    fun process(uri: Uri, outFile: File, listener: Listener): Result {
        val retriever = MediaMetadataRetriever()
        val extractor = MediaExtractor()
        var encoder: MediaCodec? = null
        try {
            listener.onStage("Reading video…")
            retriever.setDataSource(context, uri)
            extractor.setDataSource(context, uri, null)

            // ---- tracks ----
            var videoIn = -1
            var audioIn = -1
            for (i in 0 until extractor.trackCount) {
                val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (videoIn < 0 && mime.startsWith("video/")) videoIn = i
                else if (audioIn < 0 && mime.startsWith("audio/")) audioIn = i
            }
            if (videoIn < 0) throw IllegalArgumentException("This file has no video track")
            val videoFormat = extractor.getTrackFormat(videoIn)
            audioFormat = if (audioIn >= 0) extractor.getTrackFormat(audioIn) else null

            // ---- frame timestamps (keeps original timing) ----
            val times = ArrayList<Long>()
            extractor.selectTrack(videoIn)
            while (true) {
                val t = extractor.sampleTime
                if (t < 0) break
                times.add(t)
                if (!extractor.advance()) break
            }
            extractor.unselectTrack(videoIn)
            times.sort()

            val metaCount = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT
            )?.toIntOrNull()
            val total = when {
                metaCount != null && times.isNotEmpty() -> min(metaCount, times.size)
                metaCount != null -> metaCount
                else -> times.size
            }
            if (total <= 0) throw IllegalStateException("Could not read the video frames")

            val durationUs = (retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L) * 1000L
            val fps = (videoFormat.number(MediaFormat.KEY_FRAME_RATE)?.toFloat()
                ?: if (durationUs > 0) total * 1_000_000f / durationUs else 30f)
                .coerceIn(1f, 240f)
            val frameDurUs = (1_000_000f / fps).toLong().coerceAtLeast(1L)

            fun timeOf(i: Int): Long = when {
                i < times.size -> times[i]
                times.isNotEmpty() -> times.last() + (i - times.size + 1) * frameDurUs
                else -> i * frameDurUs
            }

            // ---- orientation ----
            val rotation = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION
            )?.toIntOrNull() ?: 0
            val metaW = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH
            )?.toIntOrNull() ?: 0
            val metaH = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT
            )?.toIntOrNull() ?: 0

            val first = grab(retriever, 0, 1) { timeOf(it) }.first()
            val srcW = first.width
            val srcH = first.height
            first.recycle()
            val framesUnrotated = (rotation == 90 || rotation == 270) &&
                    metaW != metaH && srcW == metaW && srcH == metaH
            val orientationHint = if (framesUnrotated) rotation else 0

            // ---- encoder: same codec + same size when possible ----
            val srcMime = videoFormat.getString(MediaFormat.KEY_MIME) ?: AVC
            val srcIsHevc = srcMime.equals(HEVC, ignoreCase = true)
            val choice = (if (srcIsHevc) chooseEncoder(HEVC, srcW, srcH, allowScale = false) else null)
                ?: chooseEncoder(AVC, srcW, srcH, allowScale = true)
                ?: EncoderChoice(null, AVC, even(srcW.toDouble()), even(srcH.toDouble()), null, null)
            val outW = choice.width
            val outH = choice.height

            // ---- bitrate: match the source so size & quality stay about the same ----
            val srcBitrate = sourceVideoBitrate(retriever, videoFormat, uri, durationUs)
                ?: (srcW.toDouble() * srcH * fps * 0.1).toInt()
            var factor = if (extraQuality) 1.3 else 1.05
            if (srcIsHevc && choice.mime == AVC) factor *= 1.5          // H.264 needs more bits than HEVC
            factor *= (outW.toDouble() * outH) / (srcW.toDouble() * srcH) // if we had to downscale
            var bitrate = (srcBitrate * factor).toLong().coerceIn(300_000L, 100_000_000L).toInt()
            choice.caps?.let { bitrate = it.bitrateRange.clamp(bitrate) }

            val format = MediaFormat.createVideoFormat(choice.mime, outW, outH).apply {
                setInteger(
                    MediaFormat.KEY_COLOR_FORMAT,
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
                )
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps.roundToInt().coerceAtLeast(1))
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                if (choice.enc?.isBitrateModeSupported(
                        MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
                    ) == true
                ) {
                    setInteger(
                        MediaFormat.KEY_BITRATE_MODE,
                        MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR
                    )
                }
            }
            val enc = if (choice.name != null) MediaCodec.createByCodecName(choice.name)
            else MediaCodec.createEncoderByType(choice.mime)
            encoder = enc
            enc.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()

            val mux = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux
            if (orientationHint != 0) mux.setOrientationHint(orientationHint)

            val work = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(work)
            val dst = Rect(0, 0, outW, outH)
            val scalePaint = Paint(Paint.FILTER_BITMAP_FLAG)

            // ---- let the editor look at the video first (e.g. measure watermark size) ----
            if (editor.wantsSamples && durationUs > 0) {
                listener.onStage("Measuring the watermark…")
                val samples = 12
                for (s in 0 until samples) {
                    if (cancelled) throw ProcessingCancelled()
                    val t = durationUs * (2 * s + 1) / (2 * samples)
                    val frame = try {
                        retriever.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    } catch (e: Exception) {
                        null
                    } ?: continue
                    if (frame.width != srcW || frame.height != srcH) {
                        frame.recycle(); continue
                    }
                    canvas.drawBitmap(frame, null, dst, scalePaint)
                    frame.recycle()
                    editor.onSample(work)
                }
            }
            editor.onSamplesDone()

            // ---- frame loop ----
            val pixels = IntArray(outW * outH)
            val batch = if (srcW.toLong() * srcH > 2_100_000L) 2 else 6
            val prevW = min(480, outW)
            val prevH = max(1, (outH * prevW.toFloat() / outW).roundToInt())

            var index = 0
            var edited = 0
            var lastPts = -1L
            listener.onStage("Processing frames…")
            while (index < total) {
                if (cancelled) throw ProcessingCancelled()
                val count = min(batch, total - index)
                val frames = grab(retriever, index, count) { timeOf(it) }
                for ((k, src) in frames.withIndex()) {
                    val i = index + k
                    canvas.drawBitmap(src, null, dst, scalePaint)
                    src.recycle()

                    var pts = timeOf(i)
                    if (pts <= lastPts) pts = lastPts + 1
                    lastPts = pts

                    if (editor.edit(canvas, work, i, pts, outW, outH)) edited++

                    work.getPixels(pixels, 0, outW, 0, 0, outW, outH)
                    feedFrame(enc, pixels, outW, outH, pts)

                    if (i % 15 == 0) listener.onPreview(Bitmap.createScaledBitmap(work, prevW, prevH, true))
                    listener.onProgress(i + 1, total, edited)
                    if (cancelled) throw ProcessingCancelled()
                }
                index += count
            }
            work.recycle()

            // ---- finish video ----
            listener.onStage("Finishing…")
            while (true) {
                val idx = enc.dequeueInputBuffer(10_000L)
                if (idx >= 0) {
                    enc.queueInputBuffer(idx, 0, 0, lastPts + 1, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    break
                }
                drain(enc, false)
            }
            drain(enc, true)
            if (!muxerStarted) throw IllegalStateException("Encoder produced no output")

            // ---- copy audio unchanged ----
            if (audioTrackOut >= 0 && audioIn >= 0) {
                extractor.selectTrack(audioIn)
                extractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
                val maxIn = audioFormat?.number(MediaFormat.KEY_MAX_INPUT_SIZE)?.toInt() ?: 0
                val buf = ByteBuffer.allocateDirect(max(maxIn, 1 shl 20))
                val info = MediaCodec.BufferInfo()
                while (true) {
                    val size = extractor.readSampleData(buf, 0)
                    if (size < 0) break
                    val flags = if ((extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0)
                        MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    info.set(0, size, extractor.sampleTime, flags)
                    mux.writeSampleData(audioTrackOut, buf, info)
                    if (!extractor.advance()) break
                }
            }

            mux.stop()
            muxerStarted = false
            val codecName = if (choice.mime == HEVC) "HEVC" else "H.264"
            return Result(total, edited, audioSkipped, codecName, bitrate, outW, outH)
        } finally {
            encoder?.let { runCatching { it.stop() }; runCatching { it.release() } }
            muxer?.let {
                if (muxerStarted) runCatching { it.stop() }
                runCatching { it.release() }
            }
            runCatching { retriever.release() }
            runCatching { extractor.release() }
            runCatching { editor.close() }
        }
    }

    /** Video bitrate of the source: from the track, the container, or file size / duration. */
    private fun sourceVideoBitrate(
        r: MediaMetadataRetriever, videoFormat: MediaFormat, uri: Uri, durationUs: Long
    ): Int? {
        videoFormat.number(MediaFormat.KEY_BIT_RATE)?.toInt()?.takeIf { it > 0 }?.let { return it }
        val audioBr = audioFormat?.let { it.number(MediaFormat.KEY_BIT_RATE)?.toInt() ?: 128_000 } ?: 0
        r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull()
            ?.takeIf { it > 0 }?.let { return max(it - audioBr, 100_000) }
        if (durationUs > 0) {
            val size = try {
                context.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize }
            } catch (e: Exception) {
                null
            }
            if (size != null && size > 0) {
                return max((size * 8L * 1_000_000L / durationUs - audioBr).toInt(), 100_000)
            }
        }
        return null
    }

    private fun feedFrame(enc: MediaCodec, pixels: IntArray, w: Int, h: Int, ptsUs: Long) {
        while (true) {
            val idx = enc.dequeueInputBuffer(10_000L)
            if (idx >= 0) {
                val image = enc.getInputImage(idx)
                    ?: throw IllegalStateException("This phone's encoder does not accept image input")
                YuvWriter.write(pixels, w, h, image)
                enc.queueInputBuffer(idx, 0, w * h * 3 / 2, ptsUs, 0)
                break
            }
            drain(enc, false)
            if (cancelled) throw ProcessingCancelled()
        }
        drain(enc, false)
    }

    private fun drain(enc: MediaCodec, endOfStream: Boolean) {
        var waits = 0
        while (true) {
            val idx = enc.dequeueOutputBuffer(bufferInfo, if (endOfStream) 10_000L else 0L)
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) return
                if (++waits > 1000) throw IllegalStateException("Encoder did not finish")
            } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                startMuxer(enc.outputFormat)
            } else if (idx >= 0) {
                val buf = enc.getOutputBuffer(idx)
                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) bufferInfo.size = 0
                if (bufferInfo.size > 0 && buf != null) {
                    if (!muxerStarted) throw IllegalStateException("Muxer not started")
                    buf.position(bufferInfo.offset)
                    buf.limit(bufferInfo.offset + bufferInfo.size)
                    muxer!!.writeSampleData(videoTrackOut, buf, bufferInfo)
                }
                enc.releaseOutputBuffer(idx, false)
                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }
    }

    private fun startMuxer(videoOutFormat: MediaFormat) {
        if (muxerStarted) return
        val m = muxer ?: throw IllegalStateException("No muxer")
        videoTrackOut = m.addTrack(videoOutFormat)
        audioFormat?.let { af ->
            try {
                audioTrackOut = m.addTrack(af)
            } catch (e: Exception) {
                audioTrackOut = -1
                audioSkipped = true
            }
        }
        m.start()
        muxerStarted = true
    }

    /** Batch-decodes frames by index; falls back to time-based seeking if the device can't. */
    private fun grab(
        r: MediaMetadataRetriever, start: Int, count: Int, timeOf: (Int) -> Long
    ): List<Bitmap> {
        if (useIndexApi) {
            try {
                val params = MediaMetadataRetriever.BitmapParams()
                params.setPreferredConfig(Bitmap.Config.ARGB_8888)
                val list = r.getFramesAtIndex(start, count, params)
                if (list.size == count) return list
                list.forEach { it.recycle() }
            } catch (e: Exception) {
                // fall through
            }
            useIndexApi = false
        }
        return (start until start + count).map { i ->
            r.getFrameAtTime(timeOf(i), MediaMetadataRetriever.OPTION_CLOSEST)
                ?: throw IllegalStateException("Could not decode frame ${i + 1}")
        }
    }

    private data class EncoderChoice(
        val name: String?,
        val mime: String,
        val width: Int,
        val height: Int,
        val caps: MediaCodecInfo.VideoCapabilities?,
        val enc: MediaCodecInfo.EncoderCapabilities?
    )

    private fun chooseEncoder(mime: String, w: Int, h: Int, allowScale: Boolean): EncoderChoice? {
        val candidates = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .filter { info -> info.isEncoder && info.supportedTypes.any { it.equals(mime, true) } }
            .mapNotNull { info ->
                try {
                    val cc = info.getCapabilitiesForType(mime)
                    if (cc.colorFormats.contains(MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible))
                        Triple(info.name, cc.videoCapabilities, cc.encoderCapabilities)
                    else null
                } catch (e: Exception) {
                    null
                }
            }
        if (candidates.isEmpty()) return null
        var scale = 1.0
        repeat(if (allowScale) 40 else 1) {
            val ow = even(w * scale)
            val oh = even(h * scale)
            for ((name, vc, ec) in candidates) {
                if (vc != null && vc.isSizeSupported(ow, oh)) return EncoderChoice(name, mime, ow, oh, vc, ec)
            }
            scale *= 0.9
        }
        return null
    }

    private fun even(v: Double): Int {
        val i = v.toInt().coerceAtLeast(16)
        return i - (i % 2)
    }

    private fun MediaFormat.number(key: String): Number? {
        if (!containsKey(key)) return null
        return try {
            getInteger(key)
        } catch (e: Exception) {
            try {
                getFloat(key)
            } catch (e2: Exception) {
                null
            }
        }
    }

    companion object {
        private const val AVC = MediaFormat.MIMETYPE_VIDEO_AVC
        private const val HEVC = MediaFormat.MIMETYPE_VIDEO_HEVC
    }
}
