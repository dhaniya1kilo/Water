package com.textcover.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.OpenableColumns
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout

/** Small shared UI helpers used by both screens. */
object Ui {
    val palette = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF1C1C1E.toInt(), 0xFFFF3B30.toInt(),
        0xFFFF9500.toInt(), 0xFFFFD60A.toInt(), 0xFF34C759.toInt(), 0xFF00C7BE.toInt(),
        0xFF007AFF.toInt(), 0xFF5856D6.toInt(), 0xFFFF2D55.toInt(), 0xFF8E8E93.toInt(),
        0x99000000.toInt(), 0x99FFFFFF.toInt()
    )

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun parseColor(s: String?): Int? {
        val t = s?.trim().orEmpty()
        if (t.isEmpty()) return null
        return try {
            Color.parseColor(if (t.startsWith("#")) t else "#$t")
        } catch (e: Exception) {
            null
        }
    }

    fun toHex(c: Int): String =
        if (Color.alpha(c) == 255) String.format("#%06X", c and 0xFFFFFF)
        else String.format("#%08X", c)

    fun buildSwatches(row: LinearLayout, input: EditText) {
        val ctx = row.context
        val size = dp(ctx, 34)
        for (c in palette) {
            val v = View(ctx)
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(dp(ctx, 1), 0xFF888888.toInt())
            }
            v.layoutParams = LinearLayout.LayoutParams(size, size).apply { marginEnd = dp(ctx, 8) }
            v.contentDescription = toHex(c)
            v.setOnClickListener { input.setText(toHex(c)) }
            row.addView(v)
        }
    }

    fun displayName(activity: Activity, uri: Uri): String? = try {
        activity.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }
}
