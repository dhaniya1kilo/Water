package com.textcover.app

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import kotlin.math.max

/** Basic facts about a video, used to pick bitrate and to size overlays. */
class MediaProbe private constructor(
    val durationUs: Long,
    val rotation: Int,
    val width: Int,          // as stored (before rotation)
    val height: Int,
    val videoBitrate: Int?,  // best estimate of the source video bitrate
    val fps: Float,
    val videoMime: String
) {
    /** Size as it is displayed (rotation applied). */
    val displayWidth: Int get() = if (rotation == 90 || rotation == 270) height else width
    val displayHeight: Int get() = if (rotation == 90 || rotation == 270) width else height

    /** Target bitrate for re-encoding so quality and size stay close to the original. */
    fun targetBitrate(extraQuality: Boolean): Int {
        val src = videoBitrate ?: (width.toDouble() * height * fps * 0.1).toInt()
        val factor = if (extraQuality) 1.3 else 1.05
        return (src * factor).toLong().coerceIn(300_000L, 100_000_000L).toInt()
    }

    companion object {
        fun of(ctx: Context, uri: Uri): MediaProbe {
            val r = MediaMetadataRetriever()
            val ex = MediaExtractor()
            try {
                r.setDataSource(ctx, uri)
                ex.setDataSource(ctx, uri, null)
                var vf: MediaFormat? = null
                var af: MediaFormat? = null
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (vf == null && mime.startsWith("video/")) vf = f
                    else if (af == null && mime.startsWith("audio/")) af = f
                }
                val videoFormat = vf ?: throw IllegalArgumentException("This file has no video track")

                fun meta(key: Int) = r.extractMetadata(key)
                var durationUs = (meta(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
                // some files (often MKV) don't report the length in metadata: use the track's
                if (durationUs <= 0 && videoFormat.containsKey(MediaFormat.KEY_DURATION)) {
                    durationUs = runCatching { videoFormat.getLong(MediaFormat.KEY_DURATION) }.getOrDefault(0L)
                }
                val rotation = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                val w = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
                    ?: videoFormat.getInteger(MediaFormat.KEY_WIDTH)
                val h = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
                    ?: videoFormat.getInteger(MediaFormat.KEY_HEIGHT)
                val frames = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toIntOrNull() ?: 0
                val fps = (num(videoFormat, MediaFormat.KEY_FRAME_RATE)?.toFloat()
                    ?: if (durationUs > 0 && frames > 0) frames * 1_000_000f / durationUs else 30f)
                    .coerceIn(1f, 240f)

                // bitrate: track -> container minus audio -> file size / duration
                var br: Int? = num(videoFormat, MediaFormat.KEY_BIT_RATE)?.toInt()?.takeIf { it > 0 }
                val audioBr = af?.let { num(it, MediaFormat.KEY_BIT_RATE)?.toInt() ?: 128_000 } ?: 0
                if (br == null) {
                    br = meta(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull()
                        ?.takeIf { it > 0 }?.let { max(it - audioBr, 100_000) }
                }
                if (br == null && durationUs > 0) {
                    val size = try {
                        ctx.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize }
                    } catch (e: Exception) {
                        null
                    }
                    if (size != null && size > 0) {
                        br = max((size * 8L * 1_000_000L / durationUs - audioBr).toInt(), 100_000)
                    }
                }
                val mime = videoFormat.getString(MediaFormat.KEY_MIME) ?: MediaFormat.MIMETYPE_VIDEO_AVC
                return MediaProbe(durationUs, rotation, w, h, br, fps, mime)
            } finally {
                runCatching { r.release() }
                runCatching { ex.release() }
            }
        }

        private fun num(f: MediaFormat, key: String): Number? {
            if (!f.containsKey(key)) return null
            return try {
                f.getInteger(key)
            } catch (e: Exception) {
                try {
                    f.getFloat(key)
                } catch (e2: Exception) {
                    null
                }
            }
        }
    }
}
