package com.textcover.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

/** Page 1: cover a watermark word with your own text. */
class MainActivity : AppCompatActivity(), JobManager.Listener {

    private lateinit var pickButton: Button
    private lateinit var fileLabel: TextView
    private lateinit var preview: ImageView
    private lateinit var targetInput: TextInputEditText
    private lateinit var replaceInput: TextInputEditText
    private lateinit var textColorInput: TextInputEditText
    private lateinit var bgColorInput: TextInputEditText
    private lateinit var sample: TextView
    private lateinit var cornerSlider: Slider
    private lateinit var paddingSlider: Slider
    private lateinit var sizeSlider: Slider
    private lateinit var cornerLabel: TextView
    private lateinit var paddingLabel: TextView
    private lateinit var sizeLabel: TextView
    private lateinit var fuzzySwitch: MaterialSwitch
    private lateinit var holdSwitch: MaterialSwitch
    private lateinit var hindiSwitch: MaterialSwitch
    private lateinit var qualitySwitch: MaterialSwitch
    private lateinit var previewButton: Button
    private lateinit var startButton: Button
    private lateinit var cancelButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var resultRow: LinearLayout

    private var sourceUri: Uri? = null
    private var sourceIsVideo = false
    private var resultUri: Uri? = null
    private var resultMime = "video/mp4"
    private var previewing = false

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) onPicked(uri)
    }

    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) onStartClicked() else toast("Storage permission is needed to save the result")
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pickButton = findViewById(R.id.pickButton)
        fileLabel = findViewById(R.id.fileLabel)
        preview = findViewById(R.id.preview)
        targetInput = findViewById(R.id.targetInput)
        replaceInput = findViewById(R.id.replaceInput)
        textColorInput = findViewById(R.id.textColorInput)
        bgColorInput = findViewById(R.id.bgColorInput)
        sample = findViewById(R.id.sample)
        cornerSlider = findViewById(R.id.cornerSlider)
        paddingSlider = findViewById(R.id.paddingSlider)
        sizeSlider = findViewById(R.id.sizeSlider)
        cornerLabel = findViewById(R.id.cornerLabel)
        paddingLabel = findViewById(R.id.paddingLabel)
        sizeLabel = findViewById(R.id.sizeLabel)
        fuzzySwitch = findViewById(R.id.fuzzySwitch)
        holdSwitch = findViewById(R.id.holdSwitch)
        hindiSwitch = findViewById(R.id.hindiSwitch)
        qualitySwitch = findViewById(R.id.qualitySwitch)
        previewButton = findViewById(R.id.previewButton)
        startButton = findViewById(R.id.startButton)
        cancelButton = findViewById(R.id.cancelButton)
        progressBar = findViewById(R.id.progressBar)
        statusText = findViewById(R.id.statusText)
        resultRow = findViewById(R.id.resultRow)

        Ui.buildSwatches(findViewById(R.id.textSwatches), textColorInput)
        Ui.buildSwatches(findViewById(R.id.bgSwatches), bgColorInput)
        loadPrefs()

        textColorInput.doAfterTextChanged { updateSample() }
        bgColorInput.doAfterTextChanged { updateSample() }
        replaceInput.doAfterTextChanged { updateSample() }
        cornerSlider.addOnChangeListener { _, _, _ -> updateSample() }
        paddingSlider.addOnChangeListener { _, _, _ -> updateSample() }
        sizeSlider.addOnChangeListener { _, _, _ -> updateSample() }
        updateSample()

        pickButton.setOnClickListener {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
        }
        previewButton.setOnClickListener { runPreview() }
        startButton.setOnClickListener { onStartClicked() }
        cancelButton.setOnClickListener {
            JobManager.cancel()
            statusText.text = "Cancelling…"
        }
        findViewById<Button>(R.id.openButton).setOnClickListener { openResult() }
        findViewById<Button>(R.id.shareButton).setOnClickListener { shareResult() }
        findViewById<Button>(R.id.openWatermarkButton).setOnClickListener {
            startActivity(Intent(this, WatermarkActivity::class.java))
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onStart() {
        super.onStart()
        JobManager.addListener(this)
    }

    override fun onStop() {
        JobManager.removeListener(this)
        super.onStop()
    }

    // ---------------------------------------------------------------- background job state

    override fun onState(state: JobManager.State) {
        when (state) {
            JobManager.State.Idle -> setBusy(false)
            is JobManager.State.Running -> {
                if (state.kind == JobManager.Kind.COVER) {
                    setBusy(true, showProgress = true)
                    resultRow.visibility = View.GONE
                    progressBar.isIndeterminate = state.total == 0
                    if (state.total > 0) progressBar.progress = (state.done * 1000L / state.total).toInt()
                    statusText.text = state.message + "\nYou can leave the app, it keeps working in the background."
                } else {
                    setBusy(true, showProgress = false)
                    statusText.text = "A watermark job is running in the background. Please wait for it to finish."
                }
            }
            is JobManager.State.Done -> {
                setBusy(false)
                if (state.kind == JobManager.Kind.COVER) {
                    resultUri = state.uri
                    resultMime = state.mime
                    statusText.text = state.summary
                    resultRow.visibility = View.VISIBLE
                }
            }
            is JobManager.State.Failed -> {
                setBusy(false)
                if (state.kind == JobManager.Kind.COVER) statusText.text = state.message
            }
        }
    }

    override fun onPreview(kind: JobManager.Kind, frame: Bitmap) {
        if (kind == JobManager.Kind.COVER) preview.setImageBitmap(frame)
    }

    // ---------------------------------------------------------------- picking

    private fun onPicked(uri: Uri) {
        sourceUri = uri
        val mime = contentResolver.getType(uri) ?: ""
        sourceIsVideo = mime.startsWith("video") || (mime.isEmpty() && hasVideo(uri))
        val name = Ui.displayName(this, uri) ?: uri.lastPathSegment ?: "file"
        fileLabel.text = (if (sourceIsVideo) "Video: " else "Image: ") + name
        resultRow.visibility = View.GONE
        JobManager.clearFinished()
        statusText.text = "Tip: tap Preview to check the word is found before starting."
        lifecycleScope.launch {
            val thumb = withContext(Dispatchers.IO) { loadThumb(uri, sourceIsVideo) }
            if (thumb != null) preview.setImageBitmap(thumb) else preview.setImageDrawable(null)
        }
    }

    private fun hasVideo(uri: Uri): Boolean {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
        } catch (e: Exception) {
            false
        } finally {
            runCatching { r.release() }
        }
    }

    private fun loadThumb(uri: Uri, video: Boolean): Bitmap? = try {
        if (video) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(this, uri)
                r.getScaledFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 720, 720)
            } finally {
                runCatching { r.release() }
            }
        } else MediaIO.loadImage(this, uri, 1280)
    } catch (e: Exception) {
        null
    }

    // ---------------------------------------------------------------- style

    private fun readStyle(): OverlayStyle? {
        val target = targetInput.text?.toString()?.trim().orEmpty()
        if (target.isEmpty()) {
            targetInput.error = "Type the watermark word"
            targetInput.requestFocus()
            return null
        }
        val textColor = Ui.parseColor(textColorInput.text?.toString())
        if (textColor == null) {
            textColorInput.error = "Invalid color"; return null
        }
        val bgColor = Ui.parseColor(bgColorInput.text?.toString())
        if (bgColor == null) {
            bgColorInput.error = "Invalid color"; return null
        }
        return OverlayStyle(
            targetText = target,
            replacementText = replaceInput.text?.toString().orEmpty(),
            textColor = textColor,
            bgColor = bgColor,
            cornerPercent = cornerSlider.value,
            paddingPercent = paddingSlider.value,
            textScalePercent = sizeSlider.value,
            fuzzy = fuzzySwitch.isChecked,
            holdWhenMissing = holdSwitch.isChecked,
            devanagari = hindiSwitch.isChecked
        )
    }

    private fun updateSample() {
        cornerLabel.text = "Corner roundness: ${cornerSlider.value.toInt()}%"
        paddingLabel.text = "Padding around the word: ${paddingSlider.value.toInt()}%"
        sizeLabel.text = "Text size: ${sizeSlider.value.toInt()}% of the word height"
        textColorInput.error = null
        bgColorInput.error = null
        val tc = Ui.parseColor(textColorInput.text?.toString()) ?: Color.WHITE
        val bg = Ui.parseColor(bgColorInput.text?.toString()) ?: Color.BLACK
        val text = replaceInput.text?.toString().orEmpty()
        sample.text = text.ifEmpty { " " }
        sample.setTextColor(tc)
        sample.background = GradientDrawable().apply {
            setColor(bg)
            cornerRadius = cornerSlider.value / 100f * Ui.dp(this@MainActivity, 24)
        }
    }

    // ---------------------------------------------------------------- preview

    private data class PreviewResult(val bitmap: Bitmap, val matches: Int, val seen: String)

    private fun runPreview() {
        val uri = sourceUri ?: return toast("Pick a video or image first")
        val style = readStyle() ?: return
        val video = sourceIsVideo
        previewing = true
        setBusy(true, showProgress = false)
        statusText.text = "Scanning the preview frame…"
        lifecycleScope.launch {
            try {
                val r = withContext(Dispatchers.Default) { makePreview(uri, style, video) }
                preview.setImageBitmap(r.bitmap)
                statusText.text = if (r.matches > 0) {
                    "Found \"${style.targetText}\" ${r.matches} time(s) in this frame — covered. Tap Start."
                } else {
                    val seen = r.seen.replace('\n', ' ').take(250).ifBlank { "(no readable text)" }
                    "\"${style.targetText}\" was not found in this frame.\nText the app can read here: $seen"
                }
            } catch (e: Exception) {
                Log.e(TAG, "preview", e)
                statusText.text = "Preview failed: ${e.message}"
            } finally {
                previewing = false
                setBusy(JobManager.isRunning)
            }
        }
    }

    private fun makePreview(uri: Uri, style: OverlayStyle, video: Boolean): PreviewResult {
        val base: Bitmap = if (video) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(this, uri)
                val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val tUs = min(1000L, durMs / 2) * 1000L
                r.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: throw IllegalStateException("Could not read a frame")
            } finally {
                runCatching { r.release() }
            }
        } else MediaIO.loadImage(this, uri, 4096)

        val long = max(base.width, base.height)
        val scaled = if (long > 1920) {
            val f = 1920f / long
            Bitmap.createScaledBitmap(base, (base.width * f).toInt(), (base.height * f).toInt(), true)
        } else base
        val work = scaled.copy(Bitmap.Config.ARGB_8888, true)

        val finder = WatermarkFinder(style.targetText, style.fuzzy, style.devanagari)
        val boxes = try { finder.find(work) } finally { finder.close() }
        OverlayPainter(style).draw(Canvas(work), boxes, work.width, work.height)
        return PreviewResult(work, boxes.size, finder.lastSeenText)
    }

    // ---------------------------------------------------------------- start

    private fun onStartClicked() {
        if (JobManager.isRunning) return toast("Another job is still running")
        val uri = sourceUri ?: return toast("Pick a video or image first")
        val style = readStyle() ?: return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        savePrefs()
        JobManager.start(
            this,
            JobManager.Job(
                kind = JobManager.Kind.COVER,
                uri = uri,
                isVideo = sourceIsVideo,
                cover = style,
                extraQuality = qualitySwitch.isChecked
            )
        )
    }

    // ---------------------------------------------------------------- result

    private fun openResult() {
        val uri = resultUri ?: return
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, resultMime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            toast("No app found to open it")
        }
    }

    private fun shareResult() {
        val uri = resultUri ?: return
        val i = Intent(Intent.ACTION_SEND).setType(resultMime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Share"))
    }

    // ---------------------------------------------------------------- helpers

    private fun setBusy(b: Boolean, showProgress: Boolean = false) {
        val locked = b || previewing
        pickButton.isEnabled = !locked
        startButton.isEnabled = !locked
        previewButton.isEnabled = !locked
        cancelButton.visibility = if (b && showProgress) View.VISIBLE else View.GONE
        progressBar.visibility = if (b && showProgress) View.VISIBLE else View.GONE
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun loadPrefs() {
        val p = getSharedPreferences("settings", MODE_PRIVATE)
        targetInput.setText(p.getString("target", ""))
        replaceInput.setText(p.getString("text", ""))
        textColorInput.setText(p.getString("tc", "#FFFFFF"))
        bgColorInput.setText(p.getString("bg", "#000000"))
        cornerSlider.value = p.getFloat("corner", 60f).coerceIn(0f, 100f)
        paddingSlider.value = p.getFloat("pad", 25f).coerceIn(0f, 100f)
        sizeSlider.value = p.getFloat("size", 80f).coerceIn(30f, 150f)
        fuzzySwitch.isChecked = p.getBoolean("fuzzy", true)
        holdSwitch.isChecked = p.getBoolean("hold", true)
        hindiSwitch.isChecked = p.getBoolean("hindi", false)
        qualitySwitch.isChecked = p.getBoolean("quality", true)
    }

    private fun savePrefs() {
        getSharedPreferences("settings", MODE_PRIVATE).edit()
            .putString("target", targetInput.text?.toString())
            .putString("text", replaceInput.text?.toString())
            .putString("tc", textColorInput.text?.toString())
            .putString("bg", bgColorInput.text?.toString())
            .putFloat("corner", cornerSlider.value)
            .putFloat("pad", paddingSlider.value)
            .putFloat("size", sizeSlider.value)
            .putBoolean("fuzzy", fuzzySwitch.isChecked)
            .putBoolean("hold", holdSwitch.isChecked)
            .putBoolean("hindi", hindiSwitch.isChecked)
            .putBoolean("quality", qualitySwitch.isChecked)
            .apply()
    }

    companion object {
        private const val TAG = "WatermarkCover"
    }
}
