package com.textcover.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private lateinit var pickButton: Button
    private lateinit var fileLabel: TextView
    private lateinit var preview: ImageView
    private lateinit var targetInput: TextInputEditText
    private lateinit var replaceInput: TextInputEditText
    private lateinit var textColorInput: TextInputEditText
    private lateinit var bgColorInput: TextInputEditText
    private lateinit var sample: TextView
    private lateinit var cornerSlider: Slider
    private lateinit var paddingSlider: Slider
    private lateinit var sizeSlider: Slider
    private lateinit var cornerLabel: TextView
    private lateinit var paddingLabel: TextView
    private lateinit var sizeLabel: TextView
    private lateinit var fuzzySwitch: MaterialSwitch
    private lateinit var holdSwitch: MaterialSwitch
    private lateinit var hindiSwitch: MaterialSwitch
    private lateinit var previewButton: Button
    private lateinit var startButton: Button
    private lateinit var cancelButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var resultRow: LinearLayout

    private var sourceUri: Uri? = null
    private var sourceIsVideo = false
    private var resultUri: Uri? = null
    private var resultMime = "video/mp4"
    private var busy = false
    @Volatile private var videoProcessor: VideoProcessor? = null

    private val palette = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFF1C1C1E.toInt(), 0xFFFF3B30.toInt(),
        0xFFFF9500.toInt(), 0xFFFFD60A.toInt(), 0xFF34C759.toInt(), 0xFF00C7BE.toInt(),
        0xFF007AFF.toInt(), 0xFF5856D6.toInt(), 0xFFFF2D55.toInt(), 0xFF8E8E93.toInt(),
        0x99000000.toInt(), 0x99FFFFFF.toInt()
    )

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) onPicked(uri)
    }

    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) onStartClicked() else toast("Storage permission is needed to save the result")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        pickButton = findViewById(R.id.pickButton)
        fileLabel = findViewById(R.id.fileLabel)
        preview = findViewById(R.id.preview)
        targetInput = findViewById(R.id.targetInput)
        replaceInput = findViewById(R.id.replaceInput)
        textColorInput = findViewById(R.id.textColorInput)
        bgColorInput = findViewById(R.id.bgColorInput)
        sample = findViewById(R.id.sample)
        cornerSlider = findViewById(R.id.cornerSlider)
        paddingSlider = findViewById(R.id.paddingSlider)
        sizeSlider = findViewById(R.id.sizeSlider)
        cornerLabel = findViewById(R.id.cornerLabel)
        paddingLabel = findViewById(R.id.paddingLabel)
        sizeLabel = findViewById(R.id.sizeLabel)
        fuzzySwitch = findViewById(R.id.fuzzySwitch)
        holdSwitch = findViewById(R.id.holdSwitch)
        hindiSwitch = findViewById(R.id.hindiSwitch)
        previewButton = findViewById(R.id.previewButton)
        startButton = findViewById(R.id.startButton)
        cancelButton = findViewById(R.id.cancelButton)
        progressBar = findViewById(R.id.progressBar)
        statusText = findViewById(R.id.statusText)
        resultRow = findViewById(R.id.resultRow)

        buildSwatches(findViewById(R.id.textSwatches), textColorInput)
        buildSwatches(findViewById(R.id.bgSwatches), bgColorInput)
        loadPrefs()

        textColorInput.doAfterTextChanged { updateSample() }
        bgColorInput.doAfterTextChanged { updateSample() }
        replaceInput.doAfterTextChanged { updateSample() }
        cornerSlider.addOnChangeListener { _, _, _ -> updateSample() }
        paddingSlider.addOnChangeListener { _, _, _ -> updateSample() }
        sizeSlider.addOnChangeListener { _, _, _ -> updateSample() }
        updateSample()

        pickButton.setOnClickListener {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
        }
        previewButton.setOnClickListener { runPreview() }
        startButton.setOnClickListener { onStartClicked() }
        cancelButton.setOnClickListener {
            videoProcessor?.cancelled = true
            statusText.text = "Cancelling…"
        }
        findViewById<Button>(R.id.openButton).setOnClickListener { openResult() }
        findViewById<Button>(R.id.shareButton).setOnClickListener { shareResult() }
    }

    override fun onDestroy() {
        videoProcessor?.cancelled = true
        super.onDestroy()
    }

    // ---------------------------------------------------------------- picking

    private fun onPicked(uri: Uri) {
        sourceUri = uri
        val mime = contentResolver.getType(uri) ?: ""
        sourceIsVideo = mime.startsWith("video") || (mime.isEmpty() && hasVideo(uri))
        val name = displayName(uri) ?: uri.lastPathSegment ?: "file"
        fileLabel.text = (if (sourceIsVideo) "Video: " else "Image: ") + name
        resultRow.visibility = View.GONE
        statusText.text = "Tip: tap Preview to check the word is found before starting."
        lifecycleScope.launch {
            val thumb = withContext(Dispatchers.IO) { loadThumb(uri, sourceIsVideo) }
            if (thumb != null) preview.setImageBitmap(thumb) else preview.setImageDrawable(null)
        }
    }

    private fun hasVideo(uri: Uri): Boolean {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
        } catch (e: Exception) {
            false
        } finally {
            runCatching { r.release() }
        }
    }

    private fun displayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }

    private fun loadThumb(uri: Uri, video: Boolean): Bitmap? = try {
        if (video) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(this, uri)
                r.getScaledFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 720, 720)
            } finally {
                runCatching { r.release() }
            }
        } else MediaIO.loadImage(this, uri, 1280)
    } catch (e: Exception) {
        null
    }

    // ---------------------------------------------------------------- style

    private fun readStyle(): OverlayStyle? {
        val target = targetInput.text?.toString()?.trim().orEmpty()
        if (target.isEmpty()) {
            targetInput.error = "Type the watermark word"
            targetInput.requestFocus()
            return null
        }
        val textColor = parseColor(textColorInput.text?.toString())
        if (textColor == null) {
            textColorInput.error = "Invalid color"; return null
        }
        val bgColor = parseColor(bgColorInput.text?.toString())
        if (bgColor == null) {
            bgColorInput.error = "Invalid color"; return null
        }
        return OverlayStyle(
            targetText = target,
            replacementText = replaceInput.text?.toString().orEmpty(),
            textColor = textColor,
            bgColor = bgColor,
            cornerPercent = cornerSlider.value,
            paddingPercent = paddingSlider.value,
            textScalePercent = sizeSlider.value,
            fuzzy = fuzzySwitch.isChecked,
            holdWhenMissing = holdSwitch.isChecked,
            devanagari = hindiSwitch.isChecked
        )
    }

    private fun parseColor(s: String?): Int? {
        val t = s?.trim().orEmpty()
        if (t.isEmpty()) return null
        return try {
            Color.parseColor(if (t.startsWith("#")) t else "#$t")
        } catch (e: Exception) {
            null
        }
    }

    private fun toHex(c: Int): String =
        if (Color.alpha(c) == 255) String.format("#%06X", c and 0xFFFFFF)
        else String.format("#%08X", c)

    private fun buildSwatches(row: LinearLayout, input: TextInputEditText) {
        val size = dp(34)
        for (c in palette) {
            val v = View(this)
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(dp(1), 0xFF888888.toInt())
            }
            v.layoutParams = LinearLayout.LayoutParams(size, size).apply { marginEnd = dp(8) }
            v.contentDescription = toHex(c)
            v.setOnClickListener { input.setText(toHex(c)) }
            row.addView(v)
        }
    }

    private fun updateSample() {
        cornerLabel.text = "Corner roundness: ${cornerSlider.value.toInt()}%"
        paddingLabel.text = "Padding around the word: ${paddingSlider.value.toInt()}%"
        sizeLabel.text = "Text size: ${sizeSlider.value.toInt()}% of the word height"
        textColorInput.error = null
        bgColorInput.error = null
        val tc = parseColor(textColorInput.text?.toString()) ?: Color.WHITE
        val bg = parseColor(bgColorInput.text?.toString()) ?: Color.BLACK
        val text = replaceInput.text?.toString().orEmpty()
        sample.text = text.ifEmpty { " " }
        sample.setTextColor(tc)
        sample.background = GradientDrawable().apply {
            setColor(bg)
            cornerRadius = cornerSlider.value / 100f * dp(24)
        }
    }

    // ---------------------------------------------------------------- preview

    private data class PreviewResult(val bitmap: Bitmap, val matches: Int, val seen: String)

    private fun runPreview() {
        val uri = sourceUri ?: return toast("Pick a video or image first")
        val style = readStyle() ?: return
        val video = sourceIsVideo
        setBusy(true, showProgress = false)
        statusText.text = "Scanning the preview frame…"
        lifecycleScope.launch {
            try {
                val r = withContext(Dispatchers.Default) { makePreview(uri, style, video) }
                preview.setImageBitmap(r.bitmap)
                statusText.text = if (r.matches > 0) {
                    "Found \"${style.targetText}\" ${r.matches} time(s) in this frame — covered. Tap Start."
                } else {
                    val seen = r.seen.replace('\n', ' ').take(250).ifBlank { "(no readable text)" }
                    "\"${style.targetText}\" was not found in this frame.\nText the app can read here: $seen"
                }
            } catch (e: Exception) {
                Log.e(TAG, "preview", e)
                statusText.text = "Preview failed: ${e.message}"
            } finally {
                setBusy(false)
            }
        }
    }

    private fun makePreview(uri: Uri, style: OverlayStyle, video: Boolean): PreviewResult {
        val base: Bitmap = if (video) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(this, uri)
                val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val tUs = min(1000L, durMs / 2) * 1000L
                r.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: throw IllegalStateException("Could not read a frame")
            } finally {
                runCatching { r.release() }
            }
        } else MediaIO.loadImage(this, uri, 4096)

        val long = max(base.width, base.height)
        val scaled = if (long > 1920) {
            val f = 1920f / long
            Bitmap.createScaledBitmap(base, (base.width * f).toInt(), (base.height * f).toInt(), true)
        } else base
        val work = scaled.copy(Bitmap.Config.ARGB_8888, true)

        val finder = WatermarkFinder(style.targetText, style.fuzzy, style.devanagari)
        val boxes = try { finder.find(work) } finally { finder.close() }
        OverlayPainter(style).draw(Canvas(work), boxes, work.width, work.height)
        return PreviewResult(work, boxes.size, finder.lastSeenText)
    }

    // ---------------------------------------------------------------- processing

    private data class Output(val uri: Uri, val mime: String, val summary: String)

    private fun onStartClicked() {
        if (busy) return
        val uri = sourceUri ?: return toast("Pick a video or image first")
        val style = readStyle() ?: return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        savePrefs()
        val video = sourceIsVideo
        setBusy(true, showProgress = true)
        progressBar.progress = 0
        resultRow.visibility = View.GONE
        statusText.text = "Starting…"
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        lifecycleScope.launch {
            try {
                val out = withContext(Dispatchers.Default) {
                    if (video) processVideo(uri, style) else processImage(uri, style)
                }
                resultUri = out.uri
                resultMime = out.mime
                statusText.text = out.summary
                resultRow.visibility = View.VISIBLE
            } catch (e: ProcessingCancelled) {
                statusText.text = "Cancelled."
            } catch (e: Throwable) {
                Log.e(TAG, "processing", e)
                statusText.text = "Error: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                setBusy(false)
            }
        }
    }

    private fun processVideo(uri: Uri, style: OverlayStyle): Output {
        val tmp = File(cacheDir, "wc_${System.currentTimeMillis()}.mp4")
        val vp = VideoProcessor(applicationContext, style)
        videoProcessor = vp
        try {
            val startMs = System.currentTimeMillis()
            val res = vp.process(uri, tmp, object : VideoProcessor.Listener {
                override fun onProgress(done: Int, total: Int, framesWithMatch: Int) {
                    val elapsed = (System.currentTimeMillis() - startMs) / 1000.0
                    val eta = if (done > 0) ((total - done) * elapsed / done).toInt() else 0
                    runOnUiThread {
                        progressBar.progress = (done * 1000L / max(total, 1)).toInt()
                        statusText.text = "Frame $done / $total  •  covered in $framesWithMatch  •  ~${eta}s left"
                    }
                }

                override fun onPreview(frame: Bitmap) {
                    runOnUiThread { preview.setImageBitmap(frame) }
                }
            })
            val saved = MediaIO.saveVideo(applicationContext, tmp, "WatermarkCover_${stamp()}.mp4")
            var summary = "Done! ${res.frames} frames processed, watermark covered in ${res.framesWithMatch}.\n" +
                    "Saved to Movies/WatermarkCover."
            if (res.audioSkipped) summary += "\n(Audio format not supported in MP4, saved without sound.)"
            return Output(saved, "video/mp4", summary)
        } finally {
            tmp.delete()
            videoProcessor = null
        }
    }

    private fun processImage(uri: Uri, style: OverlayStyle): Output {
        val bmp = MediaIO.loadImage(applicationContext, uri, 6000)
        val finder = WatermarkFinder(style.targetText, style.fuzzy, style.devanagari)
        val boxes = try { finder.find(bmp) } finally { finder.close() }
        OverlayPainter(style).draw(Canvas(bmp), boxes, bmp.width, bmp.height)
        val saved = MediaIO.saveImage(applicationContext, bmp, "WatermarkCover_${stamp()}.jpg")

        val long = max(bmp.width, bmp.height)
        val shown = if (long > 1600) {
            val f = 1600f / long
            Bitmap.createScaledBitmap(bmp, (bmp.width * f).toInt(), (bmp.height * f).toInt(), true)
        } else bmp
        runOnUiThread { preview.setImageBitmap(shown) }

        val summary = if (boxes.isEmpty())
            "\"${style.targetText}\" was not found, image saved unchanged to Pictures/WatermarkCover."
        else "Done! Covered ${boxes.size} match(es). Saved to Pictures/WatermarkCover."
        return Output(saved, "image/jpeg", summary)
    }

    // ---------------------------------------------------------------- result

    private fun openResult() {
        val uri = resultUri ?: return
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, resultMime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            toast("No app found to open it")
        }
    }

    private fun shareResult() {
        val uri = resultUri ?: return
        val i = Intent(Intent.ACTION_SEND).setType(resultMime)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Share"))
    }

    // ---------------------------------------------------------------- helpers

    private fun setBusy(b: Boolean, showProgress: Boolean = false) {
        busy = b
        pickButton.isEnabled = !b
        startButton.isEnabled = !b
        previewButton.isEnabled = !b
        cancelButton.visibility = if (b && showProgress) View.VISIBLE else View.GONE
        progressBar.visibility = if (b && showProgress) View.VISIBLE else View.GONE
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun loadPrefs() {
        val p = getSharedPreferences("settings", MODE_PRIVATE)
        targetInput.setText(p.getString("target", ""))
        replaceInput.setText(p.getString("text", ""))
        textColorInput.setText(p.getString("tc", "#FFFFFF"))
        bgColorInput.setText(p.getString("bg", "#000000"))
        cornerSlider.value = p.getFloat("corner", 60f).coerceIn(0f, 100f)
        paddingSlider.value = p.getFloat("pad", 25f).coerceIn(0f, 100f)
        sizeSlider.value = p.getFloat("size", 80f).coerceIn(30f, 150f)
        fuzzySwitch.isChecked = p.getBoolean("fuzzy", true)
        holdSwitch.isChecked = p.getBoolean("hold", true)
        hindiSwitch.isChecked = p.getBoolean("hindi", false)
    }

    private fun savePrefs() {
        getSharedPreferences("settings", MODE_PRIVATE).edit()
            .putString("target", targetInput.text?.toString())
            .putString("text", replaceInput.text?.toString())
            .putString("tc", textColorInput.text?.toString())
            .putString("bg", bgColorInput.text?.toString())
            .putFloat("corner", cornerSlider.value)
            .putFloat("pad", paddingSlider.value)
            .putFloat("size", sizeSlider.value)
            .putBoolean("fuzzy", fuzzySwitch.isChecked)
            .putBoolean("hold", holdSwitch.isChecked)
            .putBoolean("hindi", hindiSwitch.isChecked)
            .apply()
    }

    companion object {
        private const val TAG = "WatermarkCover"
    }
}
