package com.textcover.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import com.google.mlkit.vision.common.InputImage
import java.util.Random
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * FAST MODE: decode -> GPU overlay -> hardware encode, using Media3 Transformer.
 * No per-frame CPU pixel work. Audio is passed through untouched.
 */
object FastExporter {

    fun export(
        ctx: Context,
        uri: Uri,
        outPath: String,
        overlays: List<TextureOverlay>,
        bitrate: Int,
        isCancelled: () -> Boolean,
        onProgress: (Int) -> Unit
    ) {
        val main = Handler(Looper.getMainLooper())
        val latch = CountDownLatch(1)
        var error: Throwable? = null
        var transformer: Transformer? = null

        main.post {
            try {
                val encoderFactory = DefaultEncoderFactory.Builder(ctx.applicationContext)
                    .setRequestedVideoEncoderSettings(
                        VideoEncoderSettings.Builder().setBitrate(bitrate).build()
                    )
                    .setEnableFallback(true)
                    .build()
                val t = Transformer.Builder(ctx.applicationContext)
                    .setEncoderFactory(encoderFactory)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            latch.countDown()
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException
                        ) {
                            error = exportException
                            latch.countDown()
                        }
                    })
                    .build()
                transformer = t
                val videoEffects: List<Effect> = listOf(OverlayEffect(ImmutableList.copyOf(overlays)))
                val item = EditedMediaItem.Builder(MediaItem.fromUri(uri))
                    .setEffects(Effects(emptyList<AudioProcessor>(), videoEffects))
                    .build()
                t.start(item, outPath)
            } catch (e: Throwable) {
                error = e
                latch.countDown()
            }
        }

        val holder = ProgressHolder()
        while (!latch.await(400, TimeUnit.MILLISECONDS)) {
            if (isCancelled()) {
                main.post { runCatching { transformer?.cancel() } }
                throw ProcessingCancelled()
            }
            main.post {
                val t = transformer ?: return@post
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(holder.progress)
            }
        }
        error?.let { throw it }
    }
}

// ------------------------------------------------------------------ moving watermark overlay

/** Renders the watermark text (with shadow / background) once, at full opacity. */
fun renderWatermarkBitmap(s: WatermarkStyle, shortSide: Int, frameW: Int): Bitmap {
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        color = s.textColor
        textAlign = Paint.Align.LEFT
        textSize = max(8f, shortSide * s.sizePercent / 100f)
    }
    fun box(): FloatArray {
        val ts = paint.textSize
        val fm = paint.fontMetrics
        val padX = if (s.effect == WatermarkEffect.BACKGROUND) ts * 0.45f else ts * 0.1f
        val padY = if (s.effect == WatermarkEffect.BACKGROUND) ts * 0.25f else ts * 0.05f
        val sh = if (s.effect == WatermarkEffect.SHADOW) ts * 0.25f else 0f
        return floatArrayOf(paint.measureText(s.text) + 2 * padX, fm.descent - fm.ascent + 2 * padY, padX, padY, sh)
    }
    var b = box()
    if (b[0] + 2 * b[4] > frameW * 0.95f) {
        paint.textSize *= (frameW * 0.95f) / (b[0] + 2 * b[4])
        b = box()
    }
    val (boxW, boxH, padX, padY, sh) = b
    val bmp = Bitmap.createBitmap(
        ceil(boxW + 2 * sh).toInt().coerceAtLeast(2),
        ceil(boxH + 2 * sh).toInt().coerceAtLeast(2),
        Bitmap.Config.ARGB_8888
    )
    val c = Canvas(bmp)
    if (s.effect == WatermarkEffect.BACKGROUND) {
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = s.effectColor }
        val r = s.cornerPercent / 100f * min(boxW, boxH) / 2f
        c.drawRoundRect(RectF(sh, sh, sh + boxW, sh + boxH), r, r, bg)
    }
    if (s.effect == WatermarkEffect.SHADOW) {
        val ts = paint.textSize
        paint.setShadowLayer(max(2f, ts * 0.12f), ts * 0.06f, ts * 0.06f, s.effectColor)
    }
    c.drawText(s.text, sh + padX, sh + padY - paint.fontMetrics.ascent, paint)
    return bmp
}

/**
 * Moves the watermark randomly. Positions are "anchors" in -L..L where the same value is used
 * for the overlay's own anchor and the frame anchor, so the watermark always stays fully inside.
 */
class MovingTextOverlay(private val s: WatermarkStyle, private val bitmap: Bitmap) : BitmapOverlay() {
    private val rnd = Random()
    private val limit = 0.94f
    private val alpha = (s.opacityPercent / 100f).coerceIn(0.05f, 1f)
    private var started = false
    private var fromX = 0f
    private var fromY = 0f
    private var toX = 0f
    private var toY = 0f
    private var curX = 0f
    private var curY = 0f
    private var segStart = 0L
    private var segDur = 1L
    private var jumpSlot = Long.MIN_VALUE

    private fun r() = (rnd.nextFloat() * 2f - 1f) * limit

    private fun segDuration(): Long {
        val dx = toX - fromX
        val dy = toY - fromY
        val dist = sqrt(dx * dx + dy * dy)
        val unitsPerSec = 0.06f * s.speed.coerceIn(1f, 10f)
        return ((dist / unitsPerSec) * 1_000_000f).toLong().coerceAtLeast(500_000L)
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap = bitmap

    @Synchronized
    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val t = presentationTimeUs
        if (!started) {
            curX = r(); curY = r()
            fromX = curX; fromY = curY
            toX = r(); toY = r()
            segStart = t
            segDur = segDuration()
            started = true
        }
        when (s.motion) {
            WatermarkMotion.JUMP -> {
                val period = (s.jumpSeconds * 1_000_000f).toLong().coerceAtLeast(200_000L)
                val slot = (t - segStart).coerceAtLeast(0L) / period
                if (slot != jumpSlot) {
                    if (jumpSlot != Long.MIN_VALUE) {
                        curX = r(); curY = r()
                    }
                    jumpSlot = slot
                }
            }
            WatermarkMotion.GLIDE -> {
                var guard = 0
                while (t >= segStart + segDur && guard++ < 10_000) {
                    segStart += segDur
                    fromX = toX; fromY = toY
                    toX = r(); toY = r()
                    segDur = segDuration()
                }
                val p = ((t - segStart).toFloat() / segDur).coerceIn(0f, 1f)
                val e = p * p * (3 - 2 * p)
                curX = fromX + (toX - fromX) * e
                curY = fromY + (toY - fromY) * e
            }
        }
        return OverlaySettings.Builder()
            .setAlphaScale(alpha)
            .setOverlayFrameAnchor(curX, curY)
            .setBackgroundFrameAnchor(curX, curY)
            .build()
    }
}

// ------------------------------------------------------------------ cover: fast scan + overlay

/** Watermark positions found by the scan, as fractions (0..1) of the displayed frame. */
class CoverTrack(private val times: LongArray, private val boxes: List<List<RectF>>) {

    val isEmpty: Boolean get() = boxes.all { it.isEmpty() }
    val maxBoxes: Int get() = boxes.maxOfOrNull { it.size } ?: 0

    /** Center of box [k] at time [t], smoothly interpolated between scanned frames. */
    fun centerAt(t: Long, k: Int): FloatArray? {
        if (times.isEmpty()) return null
        var lo = 0
        var hi = times.size - 1
        if (t <= times[0]) hi = 0
        else {
            while (lo < hi) {
                val mid = (lo + hi + 1) / 2
                if (times[mid] <= t) lo = mid else hi = mid - 1
            }
        }
        val i = hi
        val a = boxes[i].getOrNull(k) ?: return null
        var cx = a.centerX()
        var cy = a.centerY()
        if (i + 1 < times.size && t > times[i]) {
            val next = boxes[i + 1].minByOrNull { d(it, a) }
            if (next != null && d(next, a) < 0.15f) {
                val p = ((t - times[i]).toFloat() / (times[i + 1] - times[i]).coerceAtLeast(1)).coerceIn(0f, 1f)
                cx += (next.centerX() - cx) * p
                cy += (next.centerY() - cy) * p
            }
        }
        return floatArrayOf(cx, cy)
    }

    private fun d(a: RectF, b: RectF): Float {
        val dx = a.centerX() - b.centerX()
        val dy = a.centerY() - b.centerY()
        return sqrt(dx * dx + dy * dy)
    }
}

/** Draws the fixed-size cover box at the watermark's position for each frame (box index [k]). */
class CoverBoxOverlay(
    private val track: CoverTrack,
    private val k: Int,
    private val bitmap: Bitmap,
    private val fracW: Float,
    private val fracH: Float
) : BitmapOverlay() {
    private val hidden = OverlaySettings.Builder().setAlphaScale(0f).build()

    override fun getBitmap(presentationTimeUs: Long): Bitmap = bitmap

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val c = track.centerAt(presentationTimeUs, k) ?: return hidden
        val cx = if (fracW < 1f) c[0].coerceIn(fracW / 2f, 1f - fracW / 2f) else 0.5f
        val cy = if (fracH < 1f) c[1].coerceIn(fracH / 2f, 1f - fracH / 2f) else 0.5f
        return OverlaySettings.Builder()
            .setBackgroundFrameAnchor(cx * 2f - 1f, 1f - cy * 2f)
            .build()
    }
}

/**
 * Pass 1 of fast cover mode: hardware-decodes the video and runs OCR on every N-th frame
 * (grayscale, straight from the decoder - no bitmaps).
 */
class CoverScanner(private val ctx: Context, private val style: OverlayStyle) {

    @Volatile
    var cancelled = false

    class Result(val track: CoverTrack, val wordWFrac: Float, val wordHFrac: Float, val framesWithMatch: Int)

    fun scan(uri: Uri, rotation: Int, durationUs: Long, onProgress: (Float) -> Unit): Result {
        val ex = MediaExtractor()
        var dec: MediaCodec? = null
        val finder = WatermarkFinder(style.targetText, style.fuzzy, style.devanagari)
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("video/")) { track = i; break }
            }
            if (track < 0) throw IllegalArgumentException("This file has no video track")
            val fmt = ex.getTrackFormat(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            val d = MediaCodec.createDecoderByType(mime)
            dec = d
            d.configure(fmt, null, null, 0)
            d.start()
            ex.selectTrack(track)

            val scanEvery = max(1, style.scanEvery)
            val tracker = BoxTracker(if (style.holdWhenMissing) max(1, 12 / scanEvery) else 0)
            val times = ArrayList<Long>()
            val boxes = ArrayList<List<RectF>>()
            val hs = ArrayList<Float>()
            val ws = ArrayList<Float>()
            var matched = 0
            var frameIndex = 0
            var inputDone = false
            val info = MediaCodec.BufferInfo()

            while (true) {
                if (cancelled) throw ProcessingCancelled()
                if (!inputDone) {
                    val inIdx = d.dequeueInputBuffer(5_000L)
                    if (inIdx >= 0) {
                        val buf = d.getInputBuffer(inIdx)!!
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) {
                            d.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            d.queueInputBuffer(inIdx, 0, size, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val outIdx = d.dequeueOutputBuffer(info, 5_000L)
                if (outIdx < 0) continue
                val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                if (info.size > 0) {
                    if (frameIndex % scanEvery == 0) {
                        val image = d.getOutputImage(outIdx)
                        if (image != null) {
                            val g = GrayFrame.from(image)
                            val input = InputImage.fromByteArray(
                                g.nv21, g.width, g.height, rotation, InputImage.IMAGE_FORMAT_NV21
                            )
                            val found = finder.findIn(input)
                            // upright size of the OCR image
                            val upW = if (rotation == 90 || rotation == 270) g.height else g.width
                            val upH = if (rotation == 90 || rotation == 270) g.width else g.height
                            for (r in found) {
                                hs.add(r.height().toFloat() / upH)
                                ws.add(r.width().toFloat() / upW)
                            }
                            val tracked = tracker.update(found)
                            if (tracked.isNotEmpty()) matched += scanEvery
                            times.add(info.presentationTimeUs)
                            boxes.add(
                                tracked.sortedWith(compareBy({ it.top }, { it.left })).map {
                                    RectF(
                                        it.left.toFloat() / upW, it.top.toFloat() / upH,
                                        it.right.toFloat() / upW, it.bottom.toFloat() / upH
                                    )
                                }
                            )
                        }
                    }
                    frameIndex++
                    if (durationUs > 0) onProgress((info.presentationTimeUs.toFloat() / durationUs).coerceIn(0f, 1f))
                }
                d.releaseOutputBuffer(outIdx, false)
                if (eos) break
            }

            hs.sort()
            ws.sort()
            val h = if (hs.isEmpty()) 0f else hs[hs.size / 2]
            val w = if (ws.isEmpty()) 0f else ws[ws.size / 2]
            return Result(CoverTrack(times.toLongArray(), boxes), w, h, min(matched, frameIndex))
        } finally {
            dec?.let { runCatching { it.stop() }; runCatching { it.release() } }
            runCatching { ex.release() }
            runCatching { finder.close() }
        }
    }
}

/** Grayscale copy of a decoder frame (Y plane only), downscaled so the long side is <= 1920. */
class GrayFrame(val nv21: ByteArray, val width: Int, val height: Int) {
    companion object {
        fun from(image: android.media.Image): GrayFrame {
            val crop = image.cropRect
            val w0 = crop.width()
            val h0 = crop.height()
            val step = max(1, ceil(max(w0, h0) / 1920.0).toInt())
            val w = (w0 / step) and 1.inv()
            val h = (h0 / step) and 1.inv()
            val out = ByteArray(w * h * 3 / 2)
            val plane = image.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val pix = plane.pixelStride
            if (step == 1 && pix == 1) {
                for (y in 0 until h) {
                    buf.position((crop.top + y) * rowStride + crop.left)
                    buf.get(out, y * w, w)
                }
            } else {
                for (y in 0 until h) {
                    val row = (crop.top + y * step) * rowStride
                    val o = y * w
                    for (x in 0 until w) out[o + x] = buf.get(row + (crop.left + x * step) * pix)
                }
            }
            java.util.Arrays.fill(out, w * h, out.size, 128.toByte())
            return GrayFrame(out, w, h)
        }
    }
}
