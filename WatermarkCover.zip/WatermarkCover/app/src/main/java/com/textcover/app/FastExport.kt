package com.textcover.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import java.util.Random
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Where to draw the overlay image on one frame: center (fractions of the displayed frame) + alpha. */
class Placement(val cx: Float, val cy: Float, val alpha: Float)

/** An image drawn on every frame at positions that can change over time. */
interface OverlayPlan {
    /** The image, in display orientation. */
    val bitmap: Bitmap
    /** Image size as a fraction of the displayed frame. */
    val fracW: Float
    val fracH: Float
    fun placements(ptsUs: Long): List<Placement>
}

/** Renders the watermark text (with shadow / background) once, at full opacity. */
fun renderWatermarkBitmap(s: WatermarkStyle, shortSide: Int, frameW: Int): Bitmap {
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        color = s.textColor
        textAlign = Paint.Align.LEFT
        textSize = max(8f, shortSide * s.sizePercent / 100f)
    }
    fun box(): FloatArray {
        val ts = paint.textSize
        val fm = paint.fontMetrics
        val padX = if (s.effect == WatermarkEffect.BACKGROUND) ts * 0.45f else ts * 0.1f
        val padY = if (s.effect == WatermarkEffect.BACKGROUND) ts * 0.25f else ts * 0.05f
        val sh = if (s.effect == WatermarkEffect.SHADOW) ts * 0.25f else 0f
        return floatArrayOf(paint.measureText(s.text) + 2 * padX, fm.descent - fm.ascent + 2 * padY, padX, padY, sh)
    }
    var b = box()
    if (b[0] + 2 * b[4] > frameW * 0.95f) {
        paint.textSize *= (frameW * 0.95f) / (b[0] + 2 * b[4])
        b = box()
    }
    val (boxW, boxH, padX, padY, sh) = b
    val bmp = Bitmap.createBitmap(
        ceil(boxW + 2 * sh).toInt().coerceAtLeast(2),
        ceil(boxH + 2 * sh).toInt().coerceAtLeast(2),
        Bitmap.Config.ARGB_8888
    )
    val c = Canvas(bmp)
    if (s.effect == WatermarkEffect.BACKGROUND) {
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = s.effectColor }
        val r = s.cornerPercent / 100f * min(boxW, boxH) / 2f
        c.drawRoundRect(RectF(sh, sh, sh + boxW, sh + boxH), r, r, bg)
    }
    if (s.effect == WatermarkEffect.SHADOW) {
        val ts = paint.textSize
        paint.setShadowLayer(max(2f, ts * 0.12f), ts * 0.06f, ts * 0.06f, s.effectColor)
    }
    c.drawText(s.text, sh + padX, sh + padY - paint.fontMetrics.ascent, paint)
    return bmp
}

/** Moving watermark: glides or jumps randomly, always fully inside the frame. */
class MovingTextPlan(
    private val s: WatermarkStyle,
    override val bitmap: Bitmap,
    override val fracW: Float,
    override val fracH: Float
) : OverlayPlan {
    private val rnd = Random()
    private val alpha = (s.opacityPercent / 100f).coerceIn(0.05f, 1f)
    private val margin = 0.02f
    private var started = false
    private var fromU = 0f
    private var fromV = 0f
    private var toU = 0f
    private var toV = 0f
    private var curU = 0f
    private var curV = 0f
    private var segStart = 0L
    private var segDur = 1L
    private var jumpSlot = Long.MIN_VALUE

    private fun r() = rnd.nextFloat()

    private fun segDuration(): Long {
        val du = toU - fromU
        val dv = toV - fromV
        val dist = sqrt(du * du + dv * dv)
        val unitsPerSec = 0.03f * s.speed.coerceIn(1f, 10f)
        return ((dist / unitsPerSec) * 1_000_000f).toLong().coerceAtLeast(500_000L)
    }

    override fun placements(ptsUs: Long): List<Placement> {
        val t = ptsUs
        if (!started) {
            curU = r(); curV = r()
            fromU = curU; fromV = curV
            toU = r(); toV = r()
            segStart = t
            segDur = segDuration()
            started = true
        }
        when (s.motion) {
            WatermarkMotion.JUMP -> {
                val period = (s.jumpSeconds * 1_000_000f).toLong().coerceAtLeast(200_000L)
                val slot = (t - segStart).coerceAtLeast(0L) / period
                if (slot != jumpSlot) {
                    if (jumpSlot != Long.MIN_VALUE) {
                        curU = r(); curV = r()
                    }
                    jumpSlot = slot
                }
            }
            WatermarkMotion.GLIDE -> {
                var guard = 0
                while (t >= segStart + segDur && guard++ < 10_000) {
                    segStart += segDur
                    fromU = toU; fromV = toV
                    toU = r(); toV = r()
                    segDur = segDuration()
                }
                val p = ((t - segStart).toFloat() / segDur).coerceIn(0f, 1f)
                val e = p * p * (3 - 2 * p)
                curU = fromU + (toU - fromU) * e
                curV = fromV + (toV - fromV) * e
            }
        }
        val freeW = max(0f, 1f - fracW - 2 * margin)
        val freeH = max(0f, 1f - fracH - 2 * margin)
        val left = if (fracW >= 1f - 2 * margin) (1f - fracW) / 2f else margin + curU * freeW
        val top = if (fracH >= 1f - 2 * margin) (1f - fracH) / 2f else margin + curV * freeH
        return listOf(Placement(left + fracW / 2f, top + fracH / 2f, alpha))
    }
}

/** Watermark positions found by the scan, as fractions (0..1) of the displayed frame. */
class CoverTrack(private val times: LongArray, private val boxes: List<List<RectF>>) {

    val isEmpty: Boolean get() = boxes.all { it.isEmpty() }
    val maxBoxes: Int get() = boxes.maxOfOrNull { it.size } ?: 0

    /** Center of box [k] at time [t], smoothly interpolated between scanned frames. */
    fun centerAt(t: Long, k: Int): FloatArray? {
        if (times.isEmpty()) return null
        var lo = 0
        var hi = times.size - 1
        if (t <= times[0]) hi = 0
        else {
            while (lo < hi) {
                val mid = (lo + hi + 1) / 2
                if (times[mid] <= t) lo = mid else hi = mid - 1
            }
        }
        val i = hi
        val a = boxes[i].getOrNull(k) ?: return null
        var cx = a.centerX()
        var cy = a.centerY()
        if (i + 1 < times.size && t > times[i]) {
            val next = boxes[i + 1].minByOrNull { d(it, a) }
            if (next != null && d(next, a) < 0.15f) {
                val p = ((t - times[i]).toFloat() / (times[i + 1] - times[i]).coerceAtLeast(1)).coerceIn(0f, 1f)
                cx += (next.centerX() - cx) * p
                cy += (next.centerY() - cy) * p
            }
        }
        return floatArrayOf(cx, cy)
    }

    private fun d(a: RectF, b: RectF): Float {
        val dx = a.centerX() - b.centerX()
        val dy = a.centerY() - b.centerY()
        return sqrt(dx * dx + dy * dy)
    }
}

/** Cover boxes: follow the positions found by [CoverScanner]. */
class CoverPlan(
    private val track: CoverTrack,
    private val count: Int,
    override val bitmap: Bitmap,
    override val fracW: Float,
    override val fracH: Float
) : OverlayPlan {
    override fun placements(ptsUs: Long): List<Placement> {
        val out = ArrayList<Placement>(count)
        for (k in 0 until count) {
            val c = track.centerAt(ptsUs, k) ?: continue
            val cx = if (fracW < 1f) c[0].coerceIn(fracW / 2f, 1f - fracW / 2f) else 0.5f
            val cy = if (fracH < 1f) c[1].coerceIn(fracH / 2f, 1f - fracH / 2f) else 0.5f
            out.add(Placement(cx, cy, 1f))
        }
        return out
    }
}

/**
 * Pass 1 of fast cover mode: hardware-decodes the video and reads text a few times per second
 * (grayscale, straight from the decoder - no bitmaps). OCR runs while decoding continues.
 */
class CoverScanner(private val ctx: Context, private val style: OverlayStyle) {

    @Volatile
    var cancelled = false

    class Result(val track: CoverTrack, val wordWFrac: Float, val wordHFrac: Float, val scans: Int)

    private class Pending(
        val pts: Long,
        val task: com.google.android.gms.tasks.Task<com.google.mlkit.vision.text.Text>,
        val upW: Int,
        val upH: Int
    )

    fun scan(uri: Uri, rotation: Int, durationUs: Long, onProgress: (Float) -> Unit): Result {
        val ex = MediaExtractor()
        var dec: MediaCodec? = null
        val finder = WatermarkFinder(style.targetText, style.fuzzy, style.devanagari)
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("video/")) { track = i; break }
            }
            if (track < 0) throw IllegalArgumentException("This file has no video track")
            val fmt = ex.getTrackFormat(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            fmt.setInteger(MediaFormat.KEY_PRIORITY, 1) // background priority: don't get reclaimed
            val d = MediaCodec.createDecoderByType(mime)
            dec = d
            d.configure(fmt, null, null, 0)
            d.start()
            ex.selectTrack(track)

            val sps = style.scansPerSecond.coerceIn(1, 60)
            val intervalUs = 1_000_000L / sps
            val tracker = BoxTracker(if (style.holdWhenMissing) max(1, sps / 2) else 0)
            val times = ArrayList<Long>()
            val boxes = ArrayList<List<RectF>>()
            val hs = ArrayList<Float>()
            val ws = ArrayList<Float>()
            val pending = ArrayDeque<Pending>()
            var nextScanUs = Long.MIN_VALUE
            var inputDone = false
            val info = MediaCodec.BufferInfo()

            fun collect(p: Pending) {
                val found = finder.match(com.google.android.gms.tasks.Tasks.await(p.task))
                for (r in found) {
                    hs.add(r.height().toFloat() / p.upH)
                    ws.add(r.width().toFloat() / p.upW)
                }
                val tracked = tracker.update(found)
                times.add(p.pts)
                boxes.add(
                    tracked.sortedWith(compareBy({ it.top }, { it.left })).map {
                        RectF(
                            it.left.toFloat() / p.upW, it.top.toFloat() / p.upH,
                            it.right.toFloat() / p.upW, it.bottom.toFloat() / p.upH
                        )
                    }
                )
            }

            while (true) {
                if (cancelled) throw ProcessingCancelled()
                if (!inputDone) {
                    val inIdx = d.dequeueInputBuffer(2_000L)
                    if (inIdx >= 0) {
                        val buf = d.getInputBuffer(inIdx)!!
                        val size = ex.readSampleData(buf, 0)
                        if (size < 0) {
                            d.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            d.queueInputBuffer(inIdx, 0, size, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val outIdx = d.dequeueOutputBuffer(info, 2_000L)
                if (outIdx < 0) continue
                val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                if (info.size > 0) {
                    val pts = info.presentationTimeUs
                    if (nextScanUs == Long.MIN_VALUE || pts >= nextScanUs) {
                        nextScanUs = pts + intervalUs
                        val image = d.getOutputImage(outIdx)
                        if (image != null) {
                            val g = GrayFrame.from(image)
                            val input = InputImage.fromByteArray(
                                g.nv21, g.width, g.height, rotation, InputImage.IMAGE_FORMAT_NV21
                            )
                            val upW = if (rotation == 90 || rotation == 270) g.height else g.width
                            val upH = if (rotation == 90 || rotation == 270) g.width else g.height
                            pending.addLast(Pending(pts, finder.submit(input), upW, upH))
                            // keep a few OCR jobs in flight while decoding continues
                            while (pending.size > 3) collect(pending.removeFirst())
                        }
                    }
                    if (durationUs > 0) onProgress((pts.toFloat() / durationUs).coerceIn(0f, 1f))
                }
                d.releaseOutputBuffer(outIdx, false)
                if (eos) break
            }
            while (pending.isNotEmpty()) collect(pending.removeFirst())

            hs.sort()
            ws.sort()
            val h = if (hs.isEmpty()) 0f else hs[hs.size / 2]
            val w = if (ws.isEmpty()) 0f else ws[ws.size / 2]
            return Result(CoverTrack(times.toLongArray(), boxes), w, h, times.size)
        } finally {
            dec?.let { runCatching { it.stop() }; runCatching { it.release() } }
            runCatching { ex.release() }
            runCatching { finder.close() }
        }
    }
}

/** Grayscale copy of a decoder frame (Y plane only), downscaled so the long side is <= 1920. */
class GrayFrame(val nv21: ByteArray, val width: Int, val height: Int) {
    companion object {
        fun from(image: android.media.Image): GrayFrame {
            val crop = image.cropRect
            val w0 = crop.width()
            val h0 = crop.height()
            val step = max(1, ceil(max(w0, h0) / 1920.0).toInt())
            val w = (w0 / step) and 1.inv()
            val h = (h0 / step) and 1.inv()
            val out = ByteArray(w * h * 3 / 2)
            val plane = image.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val pix = plane.pixelStride
            if (step == 1 && pix == 1) {
                for (y in 0 until h) {
                    buf.position((crop.top + y) * rowStride + crop.left)
                    buf.get(out, y * w, w)
                }
            } else {
                for (y in 0 until h) {
                    val row = (crop.top + y * step) * rowStride
                    val o = y * w
                    for (x in 0 until w) out[o + x] = buf.get(row + (crop.left + x * step) * pix)
                }
            }
            java.util.Arrays.fill(out, w * h, out.size, 128.toByte())
            return GrayFrame(out, w, h)
        }
    }
}
